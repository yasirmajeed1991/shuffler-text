<?php
/*
Plugin Name: Shuffler Text
Description: Shuffler Text to play with your text
Version: 1.2
Author: Yasir Majeed
*/


// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Enqueue scripts and styles
function text_shuffler_enqueue_scripts() {
    wp_enqueue_style('text-shuffler-style', plugins_url('css/text-shuffler.css', __FILE__));
    wp_enqueue_script('text-shuffler-script', plugins_url('js/text-shuffler.js', __FILE__), array('jquery'), '1.0', true);
    wp_localize_script('text-shuffler-script', 'textShufflerAjax', array('ajax_url' => admin_url('admin-ajax.php')));
}
add_action('wp_enqueue_scripts', 'text_shuffler_enqueue_scripts');



//Files to be included
require_once dirname(__FILE__) . '/main-form-elements.php';
require_once dirname(__FILE__) . '/required-form-elements.php';
require_once dirname(__FILE__) . '/convert-button.php';


/**************************************************************************************************/
// A.1 SHUFFLE WORDS word_shuffler
/**************************************************************************************************/

// Handle file upload and get content
function handle_file_upload($file) {
    if ($file['error'] == UPLOAD_ERR_OK && is_uploaded_file($file['tmp_name'])) {
        return file_get_contents($file['tmp_name']);
    }
    return '';
}


function word_shuffler_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_form_shuffle_words_text();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('word_shuffler', 'word_shuffler_shortcode');

function word_shuffler_shuffle_words($text) {
    $words = explode(' ', $text);
    shuffle($words);
    return implode(' ', $words);
}

function word_shuffler_ajax() {
    $text = '';
    if (!empty($_FILES['file'])) {
        $text = handle_file_upload($_FILES['file']);
    } else {
        $text = sanitize_text_field($_POST['text']);
    }
    
    $shuffled_text = word_shuffler_shuffle_words($text);
    echo $shuffled_text;
    wp_die();
}
add_action('wp_ajax_word_shuffler', 'word_shuffler_ajax');
add_action('wp_ajax_nopriv_word_shuffler', 'word_shuffler_ajax');


/**************************************************************************************************/
// A2. SHUFFLE LETTERS  letter_shuffler
/**************************************************************************************************/


function letter_shuffler_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_form_shuffle_letter_text();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('letter_shuffler', 'letter_shuffler_shortcode');

function letter_shuffler_shuffle_letters($text) {
    $characters = preg_split('//u', $text, -1, PREG_SPLIT_NO_EMPTY);
    shuffle($characters);
    return implode('', $characters);
}

function letter_shuffler_ajax() {
    $text = '';
    if (!empty($_FILES['file'])) {
        $text = handle_file_upload($_FILES['file']);
    } else {
        $text = sanitize_text_field($_POST['text']);
    }

    $shuffled_text = letter_shuffler_shuffle_letters($text);
    echo $shuffled_text;
    wp_die();
}
add_action('wp_ajax_letter_shuffler', 'letter_shuffler_ajax');
add_action('wp_ajax_nopriv_letter_shuffler', 'letter_shuffler_ajax');



/**************************************************************************************************/
// A3. SHUFFLE PARAGRAPH paragraph_shuffler
/**************************************************************************************************/

function paragraph_shuffler_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_form_shuffle_text();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('paragraph_shuffler', 'paragraph_shuffler_shortcode');

function paragraph_shuffler_shuffle_paragraphs($text) {
    $paragraphs = preg_split('/\R+/', $text);
    $paragraphs = array_filter($paragraphs, function($paragraph) {
        return !empty(trim($paragraph));
    });
    shuffle($paragraphs);
    return implode("\n\n", $paragraphs);
}

function paragraph_shuffler_ajax() {
    $text = '';
    if (!empty($_FILES['file'])) {
        $text = handle_file_upload($_FILES['file']);
    } else {
        $text = sanitize_textarea_field($_POST['text']);
    }

    $shuffled_text = paragraph_shuffler_shuffle_paragraphs($text);
    echo $shuffled_text;
    wp_die();
}
add_action('wp_ajax_paragraph_shuffler', 'paragraph_shuffler_ajax');
add_action('wp_ajax_nopriv_paragraph_shuffler', 'paragraph_shuffler_ajax');


/**************************************************************************************************/
// B1 TEXT GENERATOR text_generator
/**************************************************************************************************/
// Function to generate random text

// Render page for text generator
function text_generator_render_page() {
    ?>
    <div class="wrap">
        <h1 id="operationMessage" style="text-align: center;"><?php echo esc_html(get_the_title()); ?></h1>
        <form id="textGeneratorForm">
            
<!--new -->

<div class="text-area" style="margin-bottom:20px;">
                    <label class="textLableBold">Result:</label>
                    <textarea id="shuffledText" placeholder="Your result will appear here" rows="10" cols="40"></textarea><br>
                    <button type="button" id="downloadBtn" disabled>Download</button>
                    <button type="button" id="copyBtn" disabled>Copy</button>
                    <button type="button" id="clearBtn" >Clean</button>
                </div>
                <div class="custom-round-box">
                 <div class="custom-row">
                        <div class="custom-column">
                            <label class="textLableBold">Content Type:</label>
                              <select id="contentSelect" name="content_type" class="custom-input">
                        <option value="lorem" selected>Lorem Ipsum</option>
                        <option value="english">English</option>
                    </select>
                            <label class="textLableBold">Content</label>
                            <select id="typeSelect" name="type" class="custom-input">
                                <option value="word" selected>Word</option>
                                <option value="paragraph">Paragraph</option>
                                <option value="sentence">Sentence</option>
                              </select>

                              <label class="textLableBold">Count</label>
                              <input type="number" id="count" name="count" value="10" min="1" required class="custom-input">

                        </div>
                        <div class="custom-column">
                        </div>
                        <div class="custom-column">
                        </div>
                    </div>
                    
    
                </div>


            <input type="button" id="generate" value="Generate" style="display: block; margin: 20px auto;"  class="ajax-generate">
        </form>
    </div>
    <?php
}

// Shortcode for text generator
function text_generator_shortcode() {
    ob_start();
    text_generator_render_page();
    return ob_get_clean();
}
add_shortcode('text_generator', 'text_generator_shortcode');

// AJAX handler for text generator
function ajax_generate_text() {
    $type = sanitize_text_field($_POST['type']);
    $count = intval($_POST['count']);

    if ($count < 1) {
        $count = 1;
    }

    $generated_text = generate_random_text($type, $count);
    echo $generated_text;
    wp_die();
}
// Hook AJAX action for logged-in users and non-logged-in users
add_action('wp_ajax_generate_text', 'generate_text_callback');
add_action('wp_ajax_nopriv_generate_text', 'generate_text_callback');

function generate_text_callback() {
    $type = isset($_POST['type']) ? sanitize_text_field($_POST['type']) : 'word';
    $count = isset($_POST['count']) ? intval($_POST['count']) : 10;
    $content_type = isset($_POST['content_type']) ? sanitize_text_field($_POST['content_type']) : 'lorem';

    if ($count < 1) {
        $count = 1;
    }

    $generated_text = '';

    // Generate text based on type and content_type
    if ($content_type === 'english') {
        // English text generation
        if ($type === 'word') {
            $words = [
               
    'apple', 'banana', 'cherry', 'date', 'elderberry', 'fig', 'grape', 'honeydew', 'kiwi', 'lemon',
    'mango', 'nectarine', 'orange', 'pear', 'quince', 'raspberry', 'strawberry', 'tangerine', 'watermelon',
    'apricot', 'blueberry', 'coconut', 'dragonfruit', 'guava', 'jackfruit', 'kumquat', 'lime', 'lychee',
    'papaya', 'passionfruit', 'pomegranate', 'rhubarb', 'starfruit', 'blackberry', 'boysenberry', 'cranberry',
    'gooseberry', 'melon', 'plum', 'pineapple', 'avocado', 'peach', 'plum', 'blackcurrant', 'redcurrant',
    'greengage', 'logans', 'marionberry', 'mulberry', 'persimmon', 'plantain', 'quandong', 'salak', 'soursop',
    'tamarillo', 'ugli', 'yuzu', 'acai', 'acerola', 'barberry', 'bilberry', 'buckthorn', 'cherimoya', 'cloudberry',
    'clementine', 'damson', 'feijoa', 'jabuticaba', 'jujube', 'mandarine', 'mirabelle', 'sapodilla', 'saskatoon',
    'salmonberry', 'longan', 'santol', 'surinam cherry', 'cupuacu', 'pawpaw', 'rambutan', 'breadfruit', 'canistel',
    'cherimoya', 'cupuacu', 'durian', 'guanabana', 'tamarind', 'persimmon', 'mangosteen', 'bignay', 'camu camu',
    'chayote', 'feijoa', 'kumquat', 'manzano', 'pomelo', 'sapodilla', 'soursop', 'tamarind', 'betel nut', 'cempedak',
    'cupuacu', 'gac', 'pulasan', 'satsuma', 'ackee', 'cherry plum', 'clementine', 'finger lime', 'indian prune', 'kumquat',
    'mangosteen', 'pepino', 'sapodilla', 'starfruit', 'ackee', 'barberry', 'bilberry', 'cassabanana', 'charichuela', 'chico fruit',
    'chilean hazelnut', 'chupa chupa', 'jabuticaba', 'kaki', 'lucuma', 'marula', 'neem fruit', 'quince', 'salal berry', 'seaberries',
    'shipova', 'sweetsop', 'tamarillo', 'ube', 'wax jambu', 'goumi', 'ilama', 'kakadu plum', 'sapote', 'tayberry', 'ugli fruit',
    'ackee', 'barbados cherry', 'bilberry', 'cempedak', 'cherimoya', 'cornelian cherry', 'dabai', 'elephant apple', 'elderberry',
    'finger lime', 'gabiroba', 'goumi', 'honeyberry', 'huito', 'jabuticaba', 'katuk', 'mamey sapote', 'mangaba', 'native blackcurrant',
    'pepino', 'safou', 'salak', 'sandpaper fig', 'sea grape', 'siberian kiwi', 'wampee', 'bacaba', 'cupuaçu', 'elephant apple', 'garcinia indica',
    'grumichama', 'jaboticaba', 'jackfruit', 'lucuma', 'makrut lime', 'mamoncillo', 'marang', 'monstera deliciosa', 'noni', 'nance',
    'oak nut', 'orangelo', 'pandan', 'pequi', 'pigface', 'pitanga', 'rambutan', 'rollinia', 'salal berry', 'santol', 'sapote', 'thimbleberry',
    'ube', 'yumberry', 'baobab', 'bignay', 'bilimbi', 'black sapote', 'burdekin plum', 'carambola', 'champak', 'cocky apple', 'cotunia', 'cupuaçu',
    'duku', 'feijoa', 'goumi', 'grapefruit', 'guava', 'hala fruit', 'honeyberry', 'illawarra plum', 'jabuticaba', 'kei apple', 'lemon aspen',
    'loganberry', 'lulo', 'mabolo', 'malay apple', 'mammee apple', 'mangaba', 'mango', 'marula', 'miracle fruit', 'muscadine', 'muntingia',
    'olive', 'papaya', 'peanut butter fruit', 'pili nut', 'pineberry', 'pitaya', 'quandong', 'rambutan', 'rose apple', 'salal berry',
    'santol', 'sapodilla', 'soursop', 'strawberry', 'surinam cherry', 'tamarind', 'umeboshi', 'watermelon', 'yuzu', 'durian', 'granadilla',
    'guarana', 'hog plum', 'imbe', 'jabuticaba', 'kei apple', 'kiwano', 'kumquat', 'langsat', 'loganberry', 'longan', 'loquat', 'macadamia',
    'malay apple', 'mamey sapote', 'mangosteen', 'maypop', 'medlar', 'melon', 'mulberry', 'muntries', 'muscadine', 'naartjie', 'nectarine',
    'neem fruit', 'okari nut', 'olallieberry', 'onion', 'opuntia', 'oregon grape', 'papaya'

            ];
            // Generate words
            for ($i = 0; $i < $count; $i++) {
                $generated_text .= $words[array_rand($words)] . ' ';
            }
        } elseif ($type === 'sentence') {
            $sentences = [
                'The quick brown fox jumps over the lazy dog.',
                'She sells seashells by the seashore.',
                'Peter Piper picked a peck of pickled peppers.',
                'How much wood would a woodchuck chuck if a woodchuck could chuck wood?',
                'I scream, you scream, we all scream for ice cream!',
                'An apple a day keeps the doctor away.',
                'The early bird catches the worm.',
                'Practice makes perfect.',
                'Actions speak louder than words.',
                'Beauty is in the eye of the beholder.',
                'Don’t count your chickens before they hatch.',
                'Every cloud has a silver lining.',
                'Fortune favors the bold.',
                'When life gives you lemons, make lemonade.',
                'You reap what you sow.',
                'Two wrongs don’t make a right.',
                'A watched pot never boils.',
                'Better late than never.',
                'Birds of a feather flock together.',
                'Cleanliness is next to godliness.',
                'Curiosity killed the cat.',
                'Don’t put all your eggs in one basket.',
                'Easy come, easy go.',
                'Familiarity breeds contempt.',
                'Haste makes waste.',
                'Ignorance is bliss.',
                'Keep your friends close and your enemies closer.',
                'Let sleeping dogs lie.',
                'Make hay while the sun shines.',
                'No pain, no gain.'
            ];
            
            // Generate sentences
            for ($i = 0; $i < $count; $i++) {
                $generated_text .= $sentences[array_rand($sentences)] . ' ';
            }
        } elseif ($type === 'paragraph') {
            $paragraphs = [
                "Information technology (IT) is a rapidly evolving field that encompasses a wide range of technologies and practices. From software development to network administration, IT professionals play a crucial role in shaping the digital landscape of today's world. With advancements in cloud computing, artificial intelligence, and cybersecurity, IT continues to push the boundaries of innovation and efficiency.",
                
                "Software development is at the core of IT, driving the creation of applications and systems that power businesses and everyday life. Programmers and developers use languages like Java, Python, and JavaScript to design and build software solutions tailored to specific needs. Agile and DevOps methodologies have revolutionized how software is developed, allowing for rapid iteration and deployment.",
                
                "Data analytics is another critical aspect of IT, leveraging big data to derive insights and inform decision-making. Data scientists and analysts use tools like SQL, R, and Python to extract, transform, and analyze data from diverse sources. Machine learning algorithms enable predictive analytics, enhancing business intelligence and optimizing operational efficiency.",
                
                "Cloud computing has transformed IT infrastructure, offering scalable and flexible computing resources on-demand. Platforms like Amazon Web Services (AWS), Microsoft Azure, and Google Cloud provide virtualized servers, storage, and networking capabilities, enabling organizations to innovate without the constraints of physical hardware.",
                
                "Cybersecurity is paramount in the digital age, protecting data, networks, and systems from cyber threats. Security engineers and analysts employ techniques such as encryption, intrusion detection, and vulnerability assessment to safeguard sensitive information and mitigate risks. With the rise of remote work and digital transactions, cybersecurity has become a top priority for businesses and governments alike.",
                
                "The Internet of Things (IoT) is revolutionizing industries by connecting devices and enabling real-time data exchange. IoT applications span smart homes, healthcare, transportation, and manufacturing, improving efficiency and enhancing user experiences. IoT platforms integrate sensors, actuators, and cloud services to enable seamless connectivity and automation.",
                
                "Artificial intelligence (AI) and machine learning (ML) are driving innovation across various domains within IT. AI-powered chatbots streamline customer service, while ML algorithms optimize supply chain management and predictive maintenance. Natural language processing (NLP) enables voice assistants and sentiment analysis, transforming how humans interact with technology.",
                
                "Blockchain technology has emerged as a secure and transparent way to conduct transactions and store data. Originally developed for cryptocurrencies like Bitcoin, blockchain now finds applications in supply chain management, voting systems, and digital identity verification. Its decentralized nature ensures tamper-proof records and enhances trust in digital transactions.",
                
                "IT infrastructure management ensures the seamless operation of networks, servers, and storage systems. System administrators and network engineers monitor performance, troubleshoot issues, and implement upgrades to maintain optimal functionality. Automation tools and virtualization technologies streamline IT operations, reducing costs and enhancing scalability.",
                
                "User experience (UX) design focuses on creating intuitive and engaging interfaces for software applications and websites. UX designers conduct user research, prototype designs, and conduct usability testing to optimize user interactions. By prioritizing user needs and preferences, UX design enhances satisfaction and drives adoption of digital products.",
                
                "E-commerce platforms have revolutionized retail and commerce, enabling businesses to reach global markets and streamline transactions. Online marketplaces like Amazon and eBay connect buyers and sellers worldwide, while payment gateways and digital wallets facilitate secure and convenient transactions. Mobile commerce and omnichannel strategies are reshaping the retail landscape.",
                
                "Digital transformation is driving organizational change by integrating digital technologies into all aspects of business operations. Companies leverage cloud computing, AI, and data analytics to improve efficiency, enhance customer experiences, and unlock new revenue streams. Digital natives and established enterprises alike are embracing digital transformation to stay competitive in the digital economy.",
                
                "Health information technology (Health IT) plays a vital role in improving patient care and healthcare delivery. Electronic health records (EHRs), telemedicine platforms, and medical imaging systems enhance communication among healthcare providers and empower patients to manage their health. Health IT solutions ensure data security and compliance with healthcare regulations.",
                
                "Mobile app development has expanded the reach of digital services, offering convenience and accessibility to users on smartphones and tablets. Mobile developers design and build apps for iOS and Android platforms, leveraging frameworks like Flutter and React Native. Mobile-first strategies and responsive design principles optimize user experiences across devices.",
                
                "Virtual reality (VR) and augmented reality (AR) are transforming entertainment, education, and training. VR immerses users in virtual environments for gaming and simulations, while AR overlays digital information onto the physical world through smartphones and AR glasses. Industries like education, healthcare, and retail are exploring VR and AR applications for training and visualization.",
                
                "Social media platforms have reshaped communication and connectivity, enabling users to share content, connect with peers, and discover new trends. Brands leverage social media marketing to engage audiences, build communities, and drive brand awareness. Influencer marketing and social commerce are emerging trends that capitalize on social media's influence and reach.",
                
                "Remote work technologies have facilitated flexible work arrangements and global collaboration. Virtual meeting platforms like Zoom and Microsoft Teams enable real-time communication and collaboration, while project management tools like Asana and Trello streamline workflow management. Remote work trends are shaping the future of work, emphasizing digital skills and work-life balance.",
                
                "Video streaming services have revolutionized entertainment consumption, offering on-demand access to movies, TV shows, and live events. Platforms like Netflix, Disney+, and YouTube dominate the streaming landscape, providing personalized content recommendations and original programming. Subscription-based models and ad-supported platforms cater to diverse viewer preferences.",
                
                "Supply chain management (SCM) relies on IT systems to optimize inventory, logistics, and distribution processes. SCM software integrates data from suppliers, manufacturers, and distributors to enhance visibility and reduce operational costs. Real-time analytics and predictive modeling improve demand forecasting and supply chain resilience in global markets.",
                
                "Digital advertising leverages data-driven strategies to target audiences and measure campaign performance. Advertisers use programmatic advertising platforms to automate ad placements and optimize ad spend. Search engine marketing (SEM), display advertising, and social media ads enable brands to reach consumers across digital channels and drive conversions.",
                
                "Cloud-native architecture enables developers to build and deploy scalable applications using cloud services and microservices architecture. Containers like Docker and orchestration tools like Kubernetes simplify application management and ensure portability across different cloud environments. Cloud-native development accelerates innovation and enhances scalability for modern applications.",
            ];
            // Generate paragraphs
            for ($i = 0; $i < $count; $i++) {
                $generated_text .= $paragraphs[array_rand($paragraphs)] . "\n\n";
            }
        }
    } else {
        // Lorem Ipsum text generation
        if ($type === 'word') {
            $words = [
                'lorem', 'ipsum', 'dolor', 'sit', 'amet', 'consectetur', 'adipiscing', 'elit', 'sed', 'do', 'eiusmod', 'tempor', 'incididunt', 'ut', 'labore', 'et', 'dolore', 'magna', 'aliqua', 'Ut', 'enim', 'ad', 'minim', 'veniam', 'quis', 'nostrud', 'exercitation', 'ullamco', 'laboris', 'nisi', 'ut', 'aliquip', 'ex', 'ea', 'commodo', 'consequat', 'Duis', 'aute', 'irure', 'dolor', 'in', 'reprehenderit', 'in', 'voluptate', 'velit', 'esse', 'cillum', 'dolore', 'eu', 'fugiat', 'nulla', 'pariatur', 'Excepteur', 'sint', 'occaecat', 'cupidatat', 'non', 'proident', 'sunt', 'in', 'culpa', 'qui', 'officia', 'deserunt', 'mollit', 'anim', 'id', 'est', 'laborum', 
                'Sed', 'ut', 'perspiciatis', 'unde', 'omnis', 'iste', 'natus', 'error', 'sit', 'voluptatem', 'accusantium', 'doloremque', 'laudantium', 'totam', 'rem', 'aperiam', 'eaque', 'ipsa', 'quae', 'ab', 'illo', 'inventore', 'veritatis', 'et', 'quasi', 'architecto', 'beatae', 'vitae', 'dicta', 'sunt', 'explicabo', 'Nemo', 'enim', 'ipsam', 'voluptatem', 'quia', 'voluptas', 'sit', 'aspernatur', 'aut', 'odit', 'aut', 'fugit', 'sed', 'quia', 'consequuntur', 'magni', 'dolores', 'eos', 'qui', 'ratione', 'voluptatem', 'sequi', 'nesciunt', 
                'Neque', 'porro', 'quisquam', 'est', 'qui', 'dolorem', 'ipsum', 'quia', 'dolor', 'sit', 'amet', 'consectetur', 'adipisci', 'velit', 'sed', 'quia', 'non', 'numquam', 'eius', 'modi', 'tempora', 'incidunt', 'ut', 'labore', 'et', 'dolore', 'magnam', 'aliquam', 'quaerat', 'voluptatem', 'Ut', 'enim', 'ad', 'minima', 'veniam', 'quis', 'nostrum', 'exercitationem', 'ullam', 'corporis', 'suscipit', 'laboriosam', 'nisi', 'ut', 'aliquid', 'ex', 'ea', 'commodi', 'consequatur', 'quis', 'autem', 'vel', 'eum', 'iure', 'reprehenderit', 'qui', 'in', 'ea', 'voluptate', 'velit', 'esse', 'quam', 'nihil', 'molestiae', 'et', 'iusto', 'odio', 'dignissimos', 'ducimus', 'qui', 'blanditiis', 'praesentium', 'voluptatum', 'deleniti', 'atque', 'corrupti', 'quos', 'dolores', 'et', 'quas', 'molestias', 'excepturi', 'sint', 'occaecati', 'cupiditate', 'non', 'provident', 'similique', 'sunt', 'in', 'culpa', 'qui', 'officia', 'deserunt', 'mollitia', 'animi', 'id', 'est', 'laborum'
            ];
            // Generate words
            for ($i = 0; $i < $count; $i++) {
                $generated_text .= $words[array_rand($words)] . ' ';
            }
        } elseif ($type === 'sentence') {
            $sentences = [
                'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
                'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.',
                'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae;',
                'Sed id mauris ullamcorper, scelerisque justo sed, ultrices sapien.',
                'Cras sit amet risus et dolor fringilla mollis a eget sapien.',
                'Duis eget ipsum ac arcu luctus tempor.',
                'Aliquam a mi nec risus rutrum ullamcorper.',
                'Proin varius a ex id placerat.',
                'Ut semper lacus quis elit molestie auctor.',
                'Phasellus at nisi ac est varius convallis.',
                'In hac habitasse platea dictumst.',
                'Suspendisse potenti.',
                'Nulla et sollicitudin sem.',
                'Maecenas scelerisque libero nec quam tempor auctor.',
                'Donec vel augue ac libero ultricies rhoncus.',
                'Integer scelerisque ipsum non est sagittis, vel lacinia risus pellentesque.',
                'Ut sed turpis ut nisi ullamcorper faucibus.',
                'Nulla id velit vel ligula fringilla consectetur.',
                'Fusce nec sapien mi.',
                'Vivamus auctor magna sit amet lectus varius, nec tincidunt purus consequat.',
                'Aliquam ultricies arcu a nunc ultrices varius.',
                'Suspendisse eu congue libero.',
                'Ut elementum lacus id purus maximus, sed tristique nisl malesuada.',
                'Nulla facilisi.',
                'Pellentesque eget ligula faucibus, fermentum metus at, ultrices erat.',
                'Sed condimentum malesuada magna non bibendum.',
                'Quisque nec eros vitae nunc bibendum rutrum.',
                'Fusce maximus lorem et ante fringilla, vitae bibendum quam blandit.',
                'Nam interdum varius metus, in varius leo sodales eget.',
                'Pellentesque ac lectus quis elit blandit fringilla a ut turpis.',
                'Vestibulum viverra, eros at rhoncus posuere, felis libero lacinia ipsum, nec ultricies odio nunc vitae neque.',
                'Sed euismod ligula ut velit iaculis tristique.',
                'Morbi eu lorem id nunc faucibus posuere.',
                'Vivamus fringilla nulla et vestibulum euismod.',
                'Pellentesque eget ligula faucibus, fermentum metus at, ultrices erat.',
                'Nunc dignissim eros non efficitur suscipit.',
                'Duis elementum tincidunt velit, nec convallis odio tempus et.',
                'Sed ut congue libero.',
                'Maecenas vel tellus vitae elit ullamcorper ultrices.',
                'Cras sit amet risus et dolor fringilla mollis a eget sapien.',
                'Sed in nunc a metus posuere sodales.',
                'Vestibulum fringilla justo ac risus ullamcorper, nec posuere tortor feugiat.',
                'Aliquam erat volutpat.',
                'Donec vitae risus ac felis viverra pellentesque.',
                'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.',
                'Proin dignissim enim nec tortor iaculis luctus.',
                'Nam efficitur velit quis risus dictum, eget ullamcorper neque consectetur.',
                'Fusce nec sapien mi.',
                'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae;',
                'Integer at neque feugiat, fringilla lorem et, varius tellus.',
                'Sed euismod ligula ut velit iaculis tristique.',
                'Aenean accumsan nisi sit amet justo pharetra, et volutpat odio tincidunt.',
                'Duis eget ipsum ac arcu luctus tempor.',
                'Ut luctus mi sed velit malesuada, a ultricies lacus ultricies.',
            ];
            // Generate sentences
            for ($i = 0; $i < $count; $i++) {
                $generated_text .= $sentences[array_rand($sentences)] . ' ';
            }
        } elseif ($type === 'paragraph') {
            $paragraphs = [
                'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla facilisi. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Mauris semper tortor in lorem ultricies, vel suscipit justo scelerisque. Nulla facilisi. Donec vel augue ac libero ultricies rhoncus. Suspendisse potenti. Aliquam ultricies arcu a nunc ultrices varius. Nulla facilisi.',
                'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Ut luctus mi sed velit malesuada, a ultricies lacus ultricies. Proin varius a ex id placerat. Morbi eu lorem id nunc faucibus posuere. Mauris non dui lobortis, consectetur turpis at, tincidunt ipsum. Integer scelerisque ipsum non est sagittis, vel lacinia risus pellentesque.',
                'Duis eget ipsum ac arcu luctus tempor. Mauris id est dapibus, efficitur lacus eget, tincidunt felis. Vestibulum viverra, eros at rhoncus posuere, felis libero lacinia ipsum, nec ultricies odio nunc vitae neque. Suspendisse eu congue libero. Nulla facilisi. Nam efficitur velit quis risus dictum, eget ullamcorper neque consectetur.',
                'Cras sit amet risus et dolor fringilla mollis a eget sapien. Nunc dignissim eros non efficitur suscipit. Sed in nunc a metus posuere sodales. Sed condimentum malesuada magna non bibendum. Quisque nec eros vitae nunc bibendum rutrum. Ut semper lacus quis elit molestie auctor.',
                'Sed euismod ligula ut velit iaculis tristique. Donec interdum efficitur magna, vitae volutpat orci faucibus vitae. Nunc fringilla, nisi non fermentum scelerisque, turpis augue varius nisi, eget consequat orci nulla in augue. Aliquam erat volutpat. Integer at neque feugiat, fringilla lorem et, varius tellus.',
                'Phasellus at nisi ac est varius convallis. Aliquam a mi nec risus rutrum ullamcorper. Nulla id velit vel ligula fringilla consectetur. Proin eu lacinia elit, sed faucibus arcu. In hac habitasse platea dictumst. Nulla facilisi. Ut elementum lacus id purus maximus, sed tristique nisl malesuada.',
                'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Sed id mauris ullamcorper, scelerisque justo sed, ultrices sapien. Ut sed turpis ut nisi ullamcorper faucibus. Nulla et sollicitudin sem. Maecenas vel tellus vitae elit ullamcorper ultrices. Donec vitae risus ac felis viverra pellentesque.',
                'Pellentesque eget ligula faucibus, fermentum metus at, ultrices erat. Nunc ultricies ligula a nulla suscipit consequat. Suspendisse tempor nulla sit amet odio fermentum, in facilisis sem fringilla. Phasellus vel interdum risus. Fusce nec sapien mi. Vivamus fringilla nulla et vestibulum euismod.',
                'Fusce maximus lorem et ante fringilla, vitae bibendum quam blandit. Sed ut congue libero. Aenean accumsan nisi sit amet justo pharetra, et volutpat odio tincidunt. Proin consectetur risus vitae odio vehicula, quis dictum mauris gravida. Nam interdum varius metus, in varius leo sodales eget.',
                'Maecenas scelerisque libero nec quam tempor auctor. Vestibulum fringilla justo ac risus ullamcorper, nec posuere tortor feugiat. Proin dignissim enim nec tortor iaculis luctus. Duis elementum tincidunt velit, nec convallis odio tempus et. Vivamus auctor magna sit amet lectus varius, nec tincidunt purus consequat.'
            ];
            // Generate paragraphs
            for ($i = 0; $i < $count; $i++) {
                $generated_text .= $paragraphs[array_rand($paragraphs)] . "\n\n";
            }
        }
    }

    // Output generated text
    echo trim($generated_text);

    // Always exit to avoid extra output
    wp_die();
}



/**************************************************************************************************/
// B2 WORD GENERATOR word_generator
/**************************************************************************************************/
// Function to generate random words
function generate_random_words($count) {
    $words = [
        "technology", "innovation", "software", "hardware", "internet", "network", "data", "system", "programming", "security",
        "cloud", "computing", "application", "database", "digital", "information", "interface", "algorithm", "automation", "AI",
        "machine", "learning", "cybersecurity", "virtual", "reality", "augmented", "blockchain", "cryptocurrency", "IoT", "analytics",
        "abandoned", "ability", "abortion", "about", "above", "abroad", "absence", "absolute", "absorption", "abstract",
    "abundance", "abuse", "academic", "academy", "acceleration", "accent", "acceptance", "access", "accident", "accommodation",
    "accompaniment", "accomplishment", "accordance", "account", "accountability", "accountant", "accumulation", "accuracy", "accusation", "achievement",
    "acid", "acquisition", "acre", "act", "action", "activity", "actor", "actress", "adaptation", "addiction",
    "addition", "address", "adequacy", "administration", "admission", "adoption", "adult", "advance", "advancement", "adventure",
    "advertisement", "advice", "advocate", "affair", "affect", "affection", "affinity", "affirmation", "afterlife", "aftermath",
    "afternoon", "age", "agency", "agenda", "agent", "aggression", "agreement", "agriculture", "aid", "aim",
    "air", "aircraft", "airline", "airport", "aisle", "alarm", "album", "alcohol", "allegation", "alley",
    "alliance", "allocation", "allowance", "ally", "alphabet", "alternative", "altitude", "aluminum", "amateur", "amazement",
    "ambassador", "amber", "ambiguity", "ambition", "ambulance", "amendment", "amount", "amusement", "analog", "analogy",
    "analysis", "analyst", "anatomy", "ancestor", "anchor", "angle", "angst", "animal", "animation", "ankle",
    "anniversary", "announcement", "annual", "anomaly", "anonymous", "answer", "ant", "antagonist", "antenna", "anthem",
    "anthropology", "antibody", "anticipation", "anticlimax", "antique", "antonym", "apartment", "apology", "apparatus", "apparel",
    "appeal", "appearance", "appendix", "appetite", "applause", "apple", "appliance", "application", "appointment", "appreciation",
    "apprehension", "approach", "appropriation", "approval", "apron", "aptitude", "aquarium", "arc", "arch", "archaeology",
    "archbishop", "architecture", "archive", "area", "arena", "argument", "aristocrat", "arm", "armchair", "army",
    "arrangement", "array", "arrest", "arrival", "arrow", "art", "artery", "article", "articulation", "artifact",
    "artificial", "artist", "ascent", "ash", "aside", "aspect", "asphalt", "aspiration", "assault", "assembly",
    "assertion", "assessment", "asset", "assignment", "assist", "assistance", "assistant", "associate", "association", "assumption",
    "assurance", "asteroid", "astonishment", "astrophysics", "athlete", "atmosphere", "atom", "atrocity", "attachment", "attack",
    "attacker", "attainment", "attempt", "attendance", "attention", "attic", "attitude", "attorney", "attraction", "attribute",
    "auction", "audience", "audio", "audit", "audition", "augmentation", "august", "aunt", "aura", "authenticity",
    "author", "authority", "authorization", "auto", "automation", "automobile", "autonomy", "availability", "avenue", "average",
    "aviation", "avocado", "award", "awareness", "axis", "axle", "baby", "back", "backbone", "background",
    "backpack", "bacon", "badge", "bag", "baggage", "bait", "bake", "balance", "balcony", "ball",
    "ballet", "balloon", "ballot", "ban", "banana", "band", "bandwidth", "bang", "bank", "banker",
    "bankruptcy", "banner", "bar", "barbecue", "barber", "barge", "bark", "barn", "barrier", "base",
    "baseball", "basement", "basics", "basin", "basis", "basket", "basketball", "bat", "bath", "bathroom",
    "bathtub", "battery", "battle", "bay", "beach", "bead", "beam", "bean", "bear", "beard",
    "beast", "beat", "beauty", "bed", "bedroom", "bee", "beef", "beer", "beetle", "beginning",
    "behavior", "being", "belief", "bell", "belly", "belt", "bench", "bend", "beneficiary", "benefit",
    "berry", "bet", "betrayal", "beyond", "bias", "bible", "bicycle", "bid", "big", "bike",
    "bill", "billing", "billion", "bin", "biology", "biopsy", "bird", "birth", "birthday", "bit",
    "bitch", "bite", "black", "blade", "blanket", "blast", "blaze", "blend", "blessing", "blind",
    "block", "blood", "bloom", "blouse", "blow", "blue", "board", "boat", "body", "boil",
    "bold", "bolt", "bomb", "bond", "bone", "bonus", "book", "boom", "boost", "boot",
    "border", "boss", "botany", "bother", "bottle", "bottom", "boundary", "bow", "bowl", "box",
    "boy", "brace", "bracket", "brain", "brake", "branch", "brand", "brass", "brave", "bread",
    "break", "breakfast", "breast", "breath", "breeze", "brick", "bridge", "brief", "brilliance", "brink",
    "broad", "brochure", "broccoli", "brother", "brush", "bubble", "bucket", "buckle", "bud", "budget",
    "buffet", "bug", "build", "builder", "building", "bulb", "bulk", "bull", "bullet", "bunch",
    "bunny", "burden", "bureau", "burn", "burst", "bus", "bush", "business", "bust", "butter",
    "button", "buy", "buyer", "buzz", "cabin", "cabinet", "cable", "cactus", "cafeteria", "cage",
    "cake", "calculation", "calendar", "calf", "call", "calm", "calorie", "camel", "camera", "camp",
    "campaign", "campus", "can", "canal", "cancel", "cancer", "candidacy", "candidate", "candle", "cane",
    "cannon", "canoe", "canon", "canyon", "capability", "capacity", "capital", "captain", "caption", "car",
    "caravan", "carbon", "card", "care", "career", "cargo", "carpet", "carriage", "carrier", "carrot",
    "cart", "cartoon", "case", "cash", "cassette", "cast", "castle", "cat", "catalog", "category",
    "cattle", "cause", "caution", "cave", "ceiling", "celebration", "celebrity", "cell", "cellar", "cemetery",
    "census", "cent", "center", "century", "ceremony", "certainty", "certificate", "chain", "chair", "chairman",
    "challenge", "chamber", "champion", "championship", "chance", "change", "channel", "chaos", "chapter", "character",
    "charge", "charity", "charm", "chart", "chase", "chassis", "cheek", "cheese", "chef", "chemical",
    "chemistry", "chest", "chicken", "chief", "child", "childhood", "chip", "chocolate", "choice", "church",
    "cigarette", "circle", "circuit", "circulation", "circumstance", "citizen", "citizenship", "city", "civilian", "civilization",
    "claim", "clarity", "clash", "class", "classic", "classification", "classroom", "clause", "clay", "cleaning",
    "clearance", "clergy", "climate", "climb", "clinic", "clip", "clock", "closet", "cloth", "clothes",
    "clothing", "cloud", "club", "clue", "cluster", "clutch", "coach", "coal", "coast", "coat",
    "code", "coffee", "coffin", "coherence", "coin", "coincidence", "cold", "collaboration", "collapse", "collar",
    "collection", "college", "collision", "colon", "colony", "color", "column", "combination", "comedy", "comfort",
    "comic", "comma", "command", "comment", "commerce", "commission", "commitment", "committee", "commodity", "common",
    "communication", "community", "compact", "company", "companion", "comparison", "compensation", "competition", "competitor", "complaint",
    "complement", "completion", "complex", "complexity", "compliance", "complication", "component", "composition", "comprehension", "compression",
    "compromise", "computer", "concentration", "concept", "conception", "concern", "concert", "concession", "concierge", "conclusion",
    "concrete", "condition", "conduct", "conference", "confidence", "configuration", "conflict", "confrontation", "confusion", "congress",
    "connection", "conscience", "consciousness", "consensus", "consent", "consequence", "conservation", "consideration", "consistency", "console",
    "conspiracy", "constant", "constellation", "constitution", "constraint", "construction", "consultation", "consumer", "consumption", "contact",
    "container", "contamination", "content", "contest", "context", "continent", "contingency", "continuation", "contract", "contraction",
    "contractor", "contradiction", "contrast", "contribution", "control", "convenience", "convention", "conversation", "conversion", "conviction",
    "cook", "cookie", "cooking", "cooperation", "coordination", "cop", "copper", "copy", "cord", "core",
    "corner", "corporation", "correction", "correlation", "correspondence", "corruption", "cosmos", "cost", "cottage", "cotton",
    "couch", "council", "counseling", "countryside", "county", "coup", "coupon", "course", "court", "courtesy",
    "cousin", "cover", "coverage", "cow", "crack", "craft", "crash", "crawl", "crazy", "cream",
    "creation", "creative", "creativity", "creature", "credential", "credibility", "credit", "creed", "creek", "crew",
    "cricket", "crime", "crisis", "criteria", "critic", "criticism", "crop", "cross", "crowd", "crown",
    "crucifixion", "crusade", "crush", "cry", "crystal", "cuisine", "culture", "cup", "cure", "curiosity",
    "currency", "current", "curriculum", "curtain", "curve", "cushion", "custody", "customer", "cut", "cycle",
    "cylinder", "dad", "damage", "dance", "dancer", "dancing", "danger", "dark", "data", "database",
    "date", "daughter", "dawn", "day", "dead", "deadline", "deal", "dealer", "dealing", "dear",
    "death", "debate", "debt", "decade", "decay", "deceased", "deception", "decibel", "decision", "deck",
    "declaration", "decline", "decoration", "dedication", "deduction", "deep", "defeat", "defect", "defense", "deficit",
    "definition", "degree", "delay", "delegate", "delegation", "delicacy", "delight", "delivery", "demand", "democracy",
    "demolition", "demon", "demonstration", "den", "denial", "density", "dentist", "departure", "dependency", "deposit",
    "depot", "depth", "deputy", "derby", "derivation", "derivative", "descent", "description", "desert", "design",
    "designation", "desire", "desk", "desktop", "despair", "dessert", "destination", "destiny", "destruction", "detail",
    "detention", "determination", "deterrence", "developer", "development", "device", "devil", "diagnosis", "diagram", "dial",
    "dialogue", "diamond", "diaper", "diary", "dictation", "dictionary", "diet", "difference", "differentiation", "difficulty",
    "dig", "digestion", "dimension", "dinner", "dinosaur", "diploma", "diplomacy", "direction", "directive", "director",
    "directory", "dirt", "disability", "disadvantage", "disagreement", "disappointment", "disaster", "disc", "discard", "discharge",
    "discipline", "disclosure", "discomfort", "disconnect", "discount", "discourse", "discovery", "discretion", "discrimination", "discussion",
    "disease", "disguise", "dish", "disk", "disparity", "dispatch", "display", "disposal", "disposition", "dispute",
    "disruption", "dissection", "dissemination", "dissertation", "dissonance", "distance", "distinction", "distortion", "distribution", "district",
    "disturbance", "diversity", "dividend", "division", "divorce", "doc", "dock", "doctor", "doctrine", "document",
    "dog", "doll", "dollar", "dolphin", "domain", "donation", "donor", "door", "doorway", "dose",
    "dot", "double", "doubt", "dough", "down", "downtown", "draft", "drag", "dragon", "drama",
    "draw", "drawer", "drawing", "dream", "dress", "drill", "drink", "drive", "driver", "driveway",
    "drop", "drum", "duck", "dump", "dust", "duty", "dwarf", "dynamics", "eagle", "ear",
    "earnings", "earring", "earth", "ease", "east", "eat", "echo", "eclipse", "ecology", "economics",
    "economy", "ecosystem", "edge", "edit", "edition", "editor", "education", "effect", "efficiency", "effort",
    "egg", "ego", "elbow", "elder", "election", "electricity", "electron", "electronics", "element", "elephant",
    "elevation", "elevator", "elimination", "elite", "ellipse", "email", "embarrassment", "embassy", "embodiment", "embrace",
    "emergence", "emergency", "emotion", "emphasis", "empire", "employee", "employer", "employment", "empowerment", "emptiness",
    "encounter", "encouragement", "encyclopedia", "end", "endeavor", "ending", "enemy", "energy", "enforcement", "engagement",
    "engine", "engineer", "engineering", "enigma", "enjoyment", "enquiry", "enterprise", "entertainment", "enthusiasm", "entirety",
    "entity", "entrance", "entrepreneur", "entry", "envelope", "environment", "envy", "epic", "episode", "equality",
    "equation", "equipment", "equilibrium", "equinox", "era", "error", "escape", "escort", "essence", "essay",
    "establishment", "estate", "estimate", "eternity", "ethics", "ethnicity", "evaluation", "evangelism", "evaporation", "evening",
    "event", "everybody", "evidence", "evil", "evolution", "examination", "example", "excellence", "exception", "excerpt",
    "excess", "exchange", "excitement", "exclamation", "excursion", "excuse", "execution", "executive", "exercise", "exhibition",
    "existence", "exit", "exodus", "expansion", "expectation", "expedition", "expense", "experience", "experiment", "expert",
    "explanation", "exploitation", "exploration", "explosion", "export", "exposure", "expression", "extension", "extent", "external",
    "extinction", "extra", "extravagance", "extreme", "eye", "eyebrow", "eyelash", "eyelid", "fabric", "face",
    "facelift", "facility", "fact", "factor", "factory", "faculty", "failure", "fair", "faith", "faithfulness",
    "fall", "falsehood", "fame", "familiarity", "family", "fan", "fantasy", "farmer", "fascination", "fashion",
    "fat", "fate", "father", "fault", "favor", "favorite", "fear", "feast", "feather", "feature",
    "federation", "fee", "feed", "feedback", "feel", "feeling", "fellow", "fence", "ferry", "festival",
    "fever", "few", "fiber", "fiction", "field", "fight", "fighter", "figure", "file", "fill",
    "film", "filter", "final", "finance", "financing", "finding", "fine", "finger", "finish", "fire",
    "fireplace", "firework", "firm", "fish", "fishing", "fist", "fitness", "fix", "fixture", "flag",
    "flame", "flank", "flare", "flash", "flat", "flavor", "fleet", "flesh", "flexibility", "flight",
    "flock", "flood", "floor", "flour", "flow", "flower", "flu", "fluid", "flute", "fly",
    "focus", "fog", "fold", "folk", "following", "food", "foot", "football", "footprint", "force",
    "ford", "forearm", "forecast", "forehead", "foreigner", "forest", "forestry", "fork", "form", "formation",
    "former", "formula", "fort", "fortune", "forum", "foundation", "fountain", "fox", "fraction", "fragment",
    "frame", "framework", "franchise", "frank", "fraud", "free", "freedom", "freezer", "frequency", "freshman",
    "friend", "friendship", "fringe", "frog", "front", "frost", "fruit", "fuel", "fulfillment", "full",
    "function", "fund", "funeral", "funnel", "fur", "furniture", "fury", "fusion", "future", "gadget",
    "gain", "galaxy", "gallery", "game", "gang", "gap", "garage", "garbage", "garden", "garlic",
    "gas", "gate", "gather", "gathering", "gauge", "gaze", "gear", "gender", "gene", "general",
    "generation", "generator", "genius", "genre", "gentleman", "geography", "geology", "geometry", "germ", "gesture",
    "ghost", "giant", "gift", "gig", "ginger", "girl", "glance", "glass", "gleam", "glimpse",
    "globe", "glory", "glove", "glow", "glue", "goal", "goat", "god", "gold", "golf",
    "good", "goodbye", "government", "gown", "grab", "grace", "grade", "gradient", "graduate", "grain",
    "grammar", "grand", "grandfather", "grandmother", "grant", "grape", "graphic", "grasp", "grass", "gratitude",
    "gravity", "gray", "greed", "green", "greeting", "grief", "grill", "grin", "grip", "grocery",
    "groove", "ground", "group", "growth", "guarantee", "guard", "guess"
    ];

    $generated_text = '';
    for ($i = 0; $i < $count; $i++) {
        $generated_text .= $words[array_rand($words)] . ' ';
    }

    return trim($generated_text);
}

// Render page for word generator
function word_generator_render_page() {
    ?>
    <div class="wrap">
        <h1 id="operationMessage" style="text-align: center;"><?php echo esc_html(get_the_title()); ?></h1>
        <form id="wordGeneratorForm">
                <div class="text-area" style="margin-bottom:20px;">
                    <label class="textLableBold">Result:</label>
                    <textarea id="shuffledText" placeholder="Your result will appear here" rows="10" cols="40"></textarea><br>
                    <button type="button" id="downloadBtn" disabled>Download</button>
                    <button type="button" id="copyBtn" disabled>Copy</button>
                    <button type="button" id="clearBtn" >Clean</button>
                </div>
                <div class="custom-round-box">
                 <div class="custom-row">
                        <div class="custom-column">
                            <label class="textLableBold">Count</label>
                              <input type="number" id="wordCount" name="count" value="10" min="1" required class="custom-input">
                            
                        </div>
                        <div class="custom-column">
                        </div>
                        <div class="custom-column">
                        </div>
                    </div>
                    </div>
            <input type="button" id="generateWords" style="display: block; margin: 20px auto;"  value="Generate" class="ajax-generate">
        </form>

    </div>
    <?php
}

// Shortcode for word generator
function word_generator_shortcode() {
    ob_start();
    word_generator_render_page();
    return ob_get_clean();
}
add_shortcode('word_generator', 'word_generator_shortcode');

// AJAX handler for word generator
function ajax_generate_words() {
    $count = intval($_POST['count']);

    if ($count < 1) {
        $count = 1;
    }

    $generated_text = generate_random_words($count);
    echo $generated_text;
    wp_die();
}
// Hook AJAX action for logged-in users and non-logged-in users
add_action('wp_ajax_generate_words', 'generate_words_callback');
add_action('wp_ajax_nopriv_generate_words', 'generate_words_callback');

function generate_words_callback() {
    $count = isset($_POST['count']) ? intval($_POST['count']) : 10;
    $generated_text = generate_random_words($count);
    echo $generated_text;
    wp_die();
}



/**************************************************************************************************/
// B3 LETTER GENERATOR letter_generator
/**************************************************************************************************/
// Function to generate random letters
function generate_random_letters($count) {
    $letters = 'abcdefghijklmnopqrstuvwxyz';
    $generated_text = '';

    for ($i = 0; $i < $count; $i++) {
        $generated_text .= $letters[rand(0, strlen($letters) - 1)];
    }

    return $generated_text;
}

// Render page for letter generator
function letter_generator_render_page() {
    ?>
    <div class="wrap">
        <h1 id="operationMessage" style="text-align: center;"><?php echo esc_html(get_the_title()); ?></h1>
        <form id="letterGeneratorForm">
        <div class="text-area" style="margin-bottom:20px;">
                    <label class="textLableBold">Result:</label>
                    <textarea id="shuffledText" placeholder="Your result will appear here" rows="10" cols="40"></textarea><br>
                    <button type="button" id="downloadBtn" disabled>Download</button>
                    <button type="button" id="copyBtn" disabled>Copy</button>
                    <button type="button" id="clearBtn" >Clean</button>
                </div>
                <div class="custom-round-box">
                 <div class="custom-row">
                        <div class="custom-column">
                            <label class="textLableBold">Count</label>
                              <input type="number" id="letterCount" name="count" value="10" min="1" required class="custom-input">
                            
                        </div>
                        <div class="custom-column">
                        </div>
                        <div class="custom-column">
                        </div>
                    </div>
                    </div>
            <input type="button" id="generateLetters" value="Generate letters"  style="display: block; margin: 20px auto;"  class="ajax-generate">
        </form>
    </div>
    <?php
}
 
// Shortcode for letter generator
function letter_generator_shortcode() {
    ob_start();
    letter_generator_render_page();
    return ob_get_clean();
}
add_shortcode('letter_generator', 'letter_generator_shortcode');

// AJAX handler for letter generator
function ajax_generate_letters() {
    $count = intval($_POST['count']);

    if ($count < 1) {
        $count = 1;
    }

    $generated_text = generate_random_letters($count);
    echo $generated_text;
    wp_die();
}

// Hook AJAX action for logged-in users and non-logged-in users
add_action('wp_ajax_generate_letters', 'ajax_generate_letters');
add_action('wp_ajax_nopriv_generate_letters', 'ajax_generate_letters');

// Enqueue scripts and localize
function enqueue_letter_generator_scripts() {
    wp_enqueue_script('letter-generator-script', plugin_dir_url(__FILE__) . 'js/text-shuffler.js', array('jquery'), null, true);
    wp_localize_script('letter-generator-script', 'letterGeneratorAjax', array('ajax_url' => admin_url('admin-ajax.php')));
}
add_action('wp_enqueue_scripts', 'enqueue_letter_generator_scripts');



/**************************************************************************************************/
// B4 Name Generator  name_generator
/**************************************************************************************************/
// Function to generate random names
function generate_random_names($count, $gender) {
    $male_names = [
        "James", "John", "Robert", "Michael", "William", "David", "Richard", "Joseph", "Charles", "Thomas",
        "Christopher", "Daniel", "Matthew", "Anthony", "Mark", "Donald", "Steven", "Paul", "Andrew", "Joshua",
        "Kenneth", "Kevin", "Brian", "George", "Edward", "Ronald", "Timothy", "Jason", "Jeffrey", "Ryan",
        "Jacob", "Gary", "Nicholas", "Eric", "Jonathan", "Stephen", "Larry", "Justin", "Scott", "Brandon",
        "Benjamin", "Samuel", "Gregory", "Frank", "Alexander", "Raymond", "Patrick", "Jack", "Dennis", "Jerry",
        "Tyler", "Aaron", "Jose", "Adam", "Nathan", "Henry", "Douglas", "Zachary", "Peter", "Kyle",
        "Walter", "Ethan", "Jeremy", "Harold", "Keith", "Christian", "Roger", "Noah", "Gerald", "Carl",
        "Terry", "Sean", "Austin", "Arthur", "Lawrence", "Jesse", "Dylan", "Bryan", "Joe", "Jordan",
        "Billy", "Bruce", "Albert", "Willie", "Gabriel", "Logan", "Alan", "Juan", "Wayne", "Roy",
        "Ralph", "Randy", "Eugene", "Vincent", "Russell", "Elijah", "Louis", "Bobby", "Philip", "Johnny",
        "Bradley", "Jayden", "Israel", "Lucas", "Mitchell", "Brody", "Bryce", "Mason", "Owen", "Derek",
        "Connor", "Oliver", "Cole", "Miles", "Gavin", "Zane", "Caleb", "Nolan", "Nathaniel", "Seth",
        "Trevor", "Evan", "Dean", "Spencer", "Parker", "Roman", "Max", "Ashton", "Jace", "Maddox",
        "Chase", "Grayson", "Gage", "Sawyer", "Ryder", "Axel", "Emmett", "Kingston", "Jameson", "Ryker",
        "Bennett", "Graham", "Silas", "Weston", "Knox", "Zayden", "Milo", "August", "Finn", "Ace",
        "Beckett", "Anderson", "Cameron", "Zachariah", "Ezekiel", "Hayden", "Tucker", "Hudson", "Archer", "Bentley",
        "Ronan", "Rhett", "Cash", "Dallas", "Griffin", "Kade", "Kane", "Knox", "Cruz", "Cohen",
        "Hendrix", "Sullivan", "Flynn", "Elliott", "Crew", "Gunnar", "Dash", "Reid", "Gideon", "Tristan",
        "Orion", "Jasper", "Landon", "Colt", "Kai", "Enzo", "Zander", "Atlas", "Harrison", "Blaine",
        "Barrett", "Carter", "Wilder", "Caden", "Holden", "Maddox", "Beau", "Rocco", "Nash", "Keegan",
        "Arlo", "Kyrie", "Hugo", "Cyrus", "Lennox", "Kyler", "Rowan", "Jensen", "Dante", "Bo",
        "Brooks", "Matteo", "Luka", "Caspian", "Duke", "Ford", "Lyle", "Reuben", "Tate", "Vaughn"
    ];
    $female_names = [
        "Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Barbara", "Susan", "Jessica", "Sarah", "Karen",
        "Nancy", "Lisa", "Betty", "Margaret", "Sandra", "Ashley", "Kimberly", "Emily", "Donna", "Michelle",
        "Dorothy", "Carol", "Amanda", "Melissa", "Deborah", "Stephanie", "Rebecca", "Sharon", "Laura", "Cynthia",
        "Kathleen", "Amy", "Shirley", "Angela", "Helen", "Anna", "Brenda", "Pamela", "Nicole", "Samantha",
        "Katherine", "Emma", "Ruth", "Christine", "Catherine", "Debra", "Rachel", "Carolyn", "Janet", "Virginia",
        "Maria", "Heather", "Diane", "Julie", "Joyce", "Victoria", "Kelly", "Christina", "Lauren", "Joan",
        "Evelyn", "Olivia", "Judith", "Megan", "Cheryl", "Andrea", "Hannah", "Martha", "Jacqueline", "Frances",
        "Gloria", "Ann", "Teresa", "Kathryn", "Sara", "Janice", "Jean", "Alice", "Madison", "Doris",
        "Abigail", "Julia", "Judy", "Grace", "Denise", "Amber", "Marilyn", "Beverly", "Danielle", "Theresa",
        "Sophia", "Marie", "Diana", "Brittany", "Natalie", "Isabella", "Charlotte", "Rose", "Alexis", "Kayla",
        "Anne", "Lillian", "Hailey", "Gabriella", "Clara", "Violet", "Stella", "Lucy", "Eleanor", "Savannah",
        "Aria", "Penelope", "Hazel", "Aurora", "Nora", "Skylar", "Paisley", "Everly", "Anna", "Caroline",
        "Genesis", "Emilia", "Kennedy", "Maya", "Melanie", "Naomi", "Ariana", "Valentina", "Peyton", "Mila",
        "Sophie", "Ivy", "Delilah", "Willow", "Bella", "Aubrey", "Luna", "Ruby", "Quinn", "Piper",
        "Aaliyah", "Eva", "Arianna", "Sienna", "Jasmine", "Elena", "Sadie", "Eliana", "Mckenzie", "Layla",
        "Lyla", "Faith", "Rachel", "Lydia", "Liliana", "Paige", "Kylie", "Ellie", "Madeline", "Avery",
        "Clara", "Brooke", "Makayla", "Amelia", "Natalia", "Reagan", "Isabelle", "Madelyn", "Eliza", "Reese",
        "Adeline", "Lila", "Serenity", "Kimberly", "Hadley", "Keira", "Gabrielle", "Kinsley", "Lola", "Remi",
        "Cora", "Adalynn", "Bailey", "Emery", "Sydney", "Ryleigh", "Margaret", "Allison", "Isla", "Jordyn",
        "Morgan", "Eloise", "Athena", "Leilani", "Phoebe", "Adriana", "Jocelyn", "Gianna", "Blakely", "Summer",
        "Melody", "Alexandra", "Alaina", "Brielle", "Jade", "Kaitlyn", "Brooklyn", "Haley", "Savanna", "Giselle",
        "Harmony", "Maddison", "Vivian", "Delaney", "Elsie", "Adelaide", "Hope", "Rosemary", "Gemma", "Willa"
    ];
    

    $names = ($gender == 'male') ? $male_names : $female_names;
    $generated_names = '';

    for ($i = 0; $i < $count; $i++) {
        
        $generated_names .= $names[array_rand($names)] . "\n";
    }

    return trim($generated_names);
}

// Render page for name generator
function name_generator_render_page() {
    ?>
    <div class="wrap">
        <h1 id="operationMessage" style="text-align: center;"><?php echo esc_html(get_the_title()); ?></h1>
        <form id="nameGeneratorForm">
                
                <div class="text-area" style="margin-bottom:20px;">
                    <label class="textLableBold">Result:</label>
                    <textarea id="shuffledText" placeholder="Your result will appear here" rows="10" cols="40"></textarea><br>
                    <button type="button" id="downloadBtn" disabled>Download</button>
                    <button type="button" id="copyBtn" disabled>Copy</button>
                    <button type="button" id="clearBtn" >Clean</button>
                </div>
                <div class="custom-round-box">
                 <div class="custom-row">
                        <div class="custom-column">
                            <label class="textLableBold">Count</label>
                              <input type="number" id="nameCount" name="count" value="10" min="1" required class="custom-input">
                            <label class="textLableBold">Gender</label>
                            <select id="gender" name="gender" required class="custom-input">
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                            </select>
                        </div>
                        <div class="custom-column">
                        </div>
                        <div class="custom-column">
                        </div>
                    </div>
                    
    
                </div>
                
            <input type="button" id="generateNames" value="Generate names" style="display: block; margin: 20px auto;" class="ajax-generate">
        </form>
    </div>
    <?php
}

// Shortcode for name generator
function name_generator_shortcode() {
    ob_start();
    name_generator_render_page();
    return ob_get_clean();
}
add_shortcode('name_generator', 'name_generator_shortcode');

// AJAX handler for name generator
function ajax_generate_names() {
    $count = intval($_POST['count']);
    $gender = sanitize_text_field($_POST['gender']);

    if ($count < 1) {
        $count = 1;
    }

    $generated_names = generate_random_names($count, $gender);
    echo $generated_names;
    wp_die();
}

// Hook AJAX action for logged-in users and non-logged-in users
add_action('wp_ajax_generate_names', 'ajax_generate_names');
add_action('wp_ajax_nopriv_generate_names', 'ajax_generate_names');

// Enqueue scripts and localize
function enqueue_name_generator_scripts() {
    wp_enqueue_script('name-generator-script', plugin_dir_url(__FILE__) . 'js/text-shuffler.js', array('jquery'), null, true);
    wp_localize_script('name-generator-script', 'nameGeneratorAjax', array('ajax_url' => admin_url('admin-ajax.php')));
}
add_action('wp_enqueue_scripts', 'enqueue_name_generator_scripts');



/**************************************************************************************************/
// C1 SPLIT TEXT text_splitter
/**************************************************************************************************/

function text_splitter_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_round_box_text_splitter();
    $output .= render_form_text_splitter();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('text_splitter', 'text_splitter_shortcode');

function split_text_ajax() {
    if (!isset($_POST['text'])) {
        wp_send_json_error('No text provided');
        wp_die();
    }

    $text = sanitize_textarea_field($_POST['text']);
    $symbol_type = isset($_POST['symbolType']) ? sanitize_text_field($_POST['symbolType']) : '';
    $split_symbol = isset($_POST['splitSymbol']) ? sanitize_text_field($_POST['splitSymbol']) : '';
    $use_regex = isset($_POST['useRegex']) ? sanitize_text_field($_POST['useRegex']) : '';
    $chunk_length = isset($_POST['chunkLength']) ? intval($_POST['chunkLength']) : 0;
    $new_line_after = isset($_POST['newLineAfter']) ? $_POST['newLineAfter'] === 'true' : false;
    $char_between = isset($_POST['charBetween']) ? sanitize_text_field($_POST['charBetween']) : '';

    if ($symbol_type === 'splitSymbol' && !$split_symbol) {
        wp_send_json_error('Split symbol is required.');
        wp_die();
    } else if ($symbol_type === 'useRegex' && !$use_regex) {
        wp_send_json_error('Regex is required.');
        wp_die();
    } else if ($symbol_type === 'chunkLength' && !$chunk_length) {
        wp_send_json_error('Chunk length is required.');
        wp_die();
    }

    $result = '';

    switch ($symbol_type) {
        case 'splitSymbol':
            $parts = explode($split_symbol, $text);
            $result = implode($new_line_after ? "\n" : $char_between, $parts);
            break;

        case 'useRegex':
            if ($use_regex) {
                $parts = preg_split('/' . preg_quote($use_regex, '/') . '/', $text);
                if (is_array($parts)) {
                    $result = implode($new_line_after ? "\n" : $char_between, $parts);
                } else {
                    $result = ''; // Handle case where no splitting occurs
                }
            } else {
                wp_send_json_error('Regex pattern not provided.');
                wp_die();
            }
            break;

        case 'chunkLength':
            $parts = str_split($text, $chunk_length);
            $result = implode($new_line_after ? "\n" : $char_between, $parts);
            break;

        default:
            wp_send_json_error('Invalid symbol type');
            wp_die();
    }

    wp_send_json_success($result);
    wp_die();
}


add_action('wp_ajax_split_text_ajax', 'split_text_ajax');
add_action('wp_ajax_nopriv_split_text_ajax', 'split_text_ajax');


// Enqueue your script and localize the AJAX object
function enqueue_text_splitter_script() {
    wp_enqueue_script('text-shuffler', get_template_directory_uri() . 'js/text-shuffler.js', array('jquery'), '1.0', true);
    
    wp_localize_script('text-shuffler', 'textSplitterAjax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
    ));
}
add_action('wp_enqueue_scripts', 'enqueue_text_splitter_script');

/**************************************************************************************************/
//C2 SPLIT TEXT INTO PARAGRAPH  split_text_into_paragraph
/**************************************************************************************************/

// Shortcode function to display the form on a WordPress page
function split_text_into_paragraph_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_round_box_split_text_into_paragraph();
    $output .= render_form_split_text_into_paragraph();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('split_text_into_paragraph', 'split_text_into_paragraph_shortcode');

function split_text_into_paragraph_ajax() {
    if (!isset($_POST['text'])) {
        wp_send_json_error('No text provided');
        wp_die();
    }

    $text = sanitize_textarea_field($_POST['text']);
    $paragraph_spacing = isset($_POST['paragraphSpacing']) ? sanitize_text_field($_POST['paragraphSpacing']) : 1;
    $remove_punctuation = isset($_POST['removePunctuation']) && $_POST['removePunctuation'] === 'true';
    $remove_spaces_left = isset($_POST['removeSpacesLeft']) && $_POST['removeSpacesLeft'] === 'true';
    $remove_spaces_right = isset($_POST['removeSpacesRight']) && $_POST['removeSpacesRight'] === 'true';

    // Function to remove punctuation marks
    if ($remove_punctuation) {
        $text = preg_replace('/[^\w\s]/', '', $text);
    }

    // Function to trim spaces from left and right
    if ($remove_spaces_left) {
        $text = preg_replace('/^\s+/', '', $text);
    }
    if ($remove_spaces_right) {
        $text = preg_replace('/\s+$/', '', $text);
    }

    // Determine the splitting method based on symbolType
    if (isset($_POST['symbolType'])) {
        $symbol_type = $_POST['symbolType'];
        switch ($symbol_type) {
            case 'numParagraphs':
                $num_paragraphs = isset($_POST['numParagraphs']) ? intval($_POST['numParagraphs']) : 1;
                $paragraphs = preg_split('/\n+/', $text);
                $total_paragraphs = count($paragraphs);
                $paragraphs_per_group = ceil($total_paragraphs / $num_paragraphs);
                $paragraphs = array_chunk($paragraphs, $paragraphs_per_group);
                $result = array_map(function ($paragraph) {
                    return implode("\n", $paragraph);
                }, $paragraphs);
                $spacing_string = str_repeat("\n", intval($paragraph_spacing));
                $result = implode($spacing_string, $result);
                break;

            case 'numSentences':
                $num_sentences = isset($_POST['numSentences']) ? intval($_POST['numSentences']) : 1;
                $sentences = preg_split('/(?<=[.?!])\s+(?=[a-zA-Z])/', $text);
                $paragraphs = array_chunk($sentences, $num_sentences);
                $result = array_map(function ($paragraph) {
                    return implode(' ', $paragraph);
                }, $paragraphs);
                $spacing_string = str_repeat("\n", intval($paragraph_spacing));
                $result = implode($spacing_string, $result);
                break;

            case 'chunkLength':
                $chunk_length = isset($_POST['chunkLength']) ? intval($_POST['chunkLength']) : 100;
                $words = preg_split('/\s+/', $text);
                $paragraphs = array_chunk($words, $chunk_length);
                $result = array_map(function ($paragraph) {
                    return implode(' ', $paragraph);
                }, $paragraphs);
                $spacing_string = str_repeat("\n", intval($paragraph_spacing));
                $result = implode($spacing_string, $result);
                break;

            default:
                wp_send_json_error('Invalid symbolType');
                wp_die();
        }

        wp_send_json_success($result);
    } else {
        wp_send_json_error('No symbolType provided');
    }

    wp_die();
}


add_action('wp_ajax_split_text_into_paragraph', 'split_text_into_paragraph_ajax');
add_action('wp_ajax_nopriv_split_text_into_paragraph', 'split_text_into_paragraph_ajax');



// Enqueue script for the shortcode page
function enqueue_split_text_into_paragraph_script() {
    wp_enqueue_script('split-text-into-paragraph-script', plugin_dir_url(__FILE__) . 'js/text-shuffler.js', array('jquery'), null, true);
    wp_localize_script('split-text-into-paragraph-script', 'splitTextIntoParagraphAjax', array(
        'ajax_url' => admin_url('admin-ajax.php')
    ));
}
add_action('wp_enqueue_scripts', 'enqueue_split_text_into_paragraph_script');


/**************************************************************************************************/
//C3 JOIN TEXT join_text_into_paragraph
/**************************************************************************************************/

// Shortcode function to display the form on a WordPress page
function join_text_into_paragraph_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_round_box_join_text_into_paragraph();
    $output .= render_form_join_text_into_paragraph();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('join_text_into_paragraph', 'join_text_into_paragraph_shortcode');

// Ajax handler function to join text into paragraphs
function join_text_into_paragraph_ajax() {
    if (!isset($_POST['words']) || !is_array($_POST['words'])) {
        wp_send_json_error('No words provided or invalid format');
        wp_die();
    }

    $words = $_POST['words'];
    $joiner = isset($_POST['joiner']) ? sanitize_text_field($_POST['joiner']) : ' ';

    // If no joiner is provided or it's empty, default to a single space
    if (empty($joiner)) {
        $joiner = ' ';
    }

    // Trim each line to ensure no extra spaces interfere with the joining
    $words = array_map('trim', $words);

    // Handle paragraphs
    foreach ($words as &$word) {
        // Split each line into words
        $paragraph_words = explode(' ', $word);
        // Join words with the joiner
        $word = implode($joiner, $paragraph_words);
    }

    // Join lines with paragraph spacing
    $result = implode("\n", $words);

    wp_send_json_success($result);
    wp_die();
}
add_action('wp_ajax_join_text_into_paragraph', 'join_text_into_paragraph_ajax');
add_action('wp_ajax_nopriv_join_text_into_paragraph', 'join_text_into_paragraph_ajax');




/**************************************************************************************************/
// C4 TRIM TEXT trim_text
/**************************************************************************************************/


// Shortcode function to display the form on a WordPress page
function trim_text_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_form_trim_text();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('trim_text', 'trim_text_shortcode');

// AJAX handler function to trim spaces from each line
function trim_text_ajax() {
    if (!isset($_POST['text'])) {
        wp_send_json_error('No text provided');
        wp_die();
    }

    $text = sanitize_textarea_field($_POST['text']);

    // Split the text into lines
    $lines = explode("\n", $text);

    // Trim spaces from the left and right of each line
    $trimmed_lines = array_map('trim', $lines);

    // Reconstruct the trimmed text
    $trimmed_text = implode("\n", $trimmed_lines);

    wp_send_json_success($trimmed_text);
    wp_die();
}

add_action('wp_ajax_trim_text', 'trim_text_ajax');
add_action('wp_ajax_nopriv_trim_text', 'trim_text_ajax');


/**************************************************************************************************/
//C5 Repeatition Text repeat_text
/**************************************************************************************************/

// Shortcode function to display the form on a WordPress page
function repeat_text_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_round_box_repeat_text();
    $output .= render_form_repeat_text();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}

add_shortcode('repeat_text', 'repeat_text_shortcode');
function repeat_text_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('No input text provided');
        wp_die();
    }

    $text = sanitize_textarea_field($_POST['inputText']);
    $numRepetitions = isset($_POST['numRepetitions']) ? intval($_POST['numRepetitions']) : 100;
    $symbolType = isset($_POST['symbolType']) ? sanitize_text_field($_POST['symbolType']) : 'space';
    $customSymbol = isset($_POST['customSymbol']) ? sanitize_text_field($_POST['customSymbol']) : ' ';

    // Validate number of repetitions
    if ($numRepetitions < 1) {
        $numRepetitions = 1;
    }

    // Choose symbol based on user selection
    switch ($symbolType) {
        case 'space':
            $symbol = ' ';
            break;
        case 'comma':
            $symbol = ', ';
            break;
        case 'newline':
            $symbol = "\n";
            break;
        case 'custom':
            $symbol = $customSymbol;
            break;
        default:
            $symbol = ' ';
            break;
    }

    // Repeat text with chosen symbol
    $result = str_repeat($text . $symbol, $numRepetitions - 1) . $text;

    wp_send_json_success($result);
    wp_die();
}
add_action('wp_ajax_repeat_text_splitter', 'repeat_text_ajax');
add_action('wp_ajax_nopriv_repeat_text_splitter', 'repeat_text_ajax');


/**************************************************************************************************/
// C6 Reverse Text reverse_text
/**************************************************************************************************/

// Shortcode function to display the form on a WordPress page
function reverse_text_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);

    $output .= render_form_reverse_text();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('reverse_text', 'reverse_text_shortcode');

function reverse_text_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('No input text provided');
        wp_die();
    }

    $text = sanitize_textarea_field($_POST['inputText']);

    // Reverse the input text
    $reversedText = strrev($text);

    wp_send_json_success($reversedText);
    wp_die();
}
add_action('wp_ajax_reverse_text_splitter', 'reverse_text_ajax');
add_action('wp_ajax_nopriv_reverse_text_splitter', 'reverse_text_ajax');


/**************************************************************************************************/
//C7 CUT TEXT cut_text
/**************************************************************************************************/
function cut_text_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_round_box_cut_text();
    $output .= render_form_cut_text();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('cut_text', 'cut_text_shortcode');


function cut_text_ajax() {
    if (!isset($_POST['inputText']) || !isset($_POST['cutLength']) || !isset($_POST['cutType'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }
    $text = sanitize_textarea_field($_POST['inputText']);
    $cutLength = intval($_POST['cutLength']);
    $cutType = $_POST['cutType'];

    switch ($cutType) {
        case 'word':
            $words = explode(' ', $text);
            $cutText = implode(' ', array_slice($words, 0, $cutLength));
            break;
        case 'character':
            $cutText = mb_substr($text, 0, $cutLength);
            break;
        case 'sentence':
            preg_match_all('/[^.!?]+[.!?]+/', $text, $sentences);
            $cutText = implode('', array_slice($sentences[0], 0, $cutLength));
            break;
        default:
            wp_send_json_error('Invalid cut type');
            wp_die();
    }

    wp_send_json_success($cutText);
    wp_die();
}
add_action('wp_ajax_cut_text_splitter', 'cut_text_ajax');
add_action('wp_ajax_nopriv_cut_text_splitter', 'cut_text_ajax');



/**************************************************************************************************/
//C8 add-text-prefix add_prefix
/**************************************************************************************************/
// Shortcode function to display the form on a WordPress page
function add_prefix_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_round_box_add_prefix();
    $output .= render_form_add_prefix();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('add_prefix', 'add_prefix_shortcode');


// AJAX handler for adding prefix
function add_prefix_ajax() {
    if (!isset($_POST['inputText']) || !isset($_POST['prefix']) || !isset($_POST['prefixType'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }
    $text = sanitize_textarea_field($_POST['inputText']);
    $prefix = sanitize_text_field($_POST['prefix']);
    $prefixType = $_POST['prefixType'];

    switch ($prefixType) {
        case 'whole':
            $modifiedText = $prefix . ' ' . $text;
            break;
        case 'line':
            $lines = explode("\n", $text);
            $modifiedText = implode("\n", array_map(function($line) use ($prefix) {
                return $prefix . ' ' . $line;
            }, $lines));
            break;
        case 'paragraph':
            $paragraphs = explode("\n\n", $text);
            $modifiedText = implode("\n\n", array_map(function($paragraph) use ($prefix) {
                return $prefix . ' ' . $paragraph;
            }, $paragraphs));
            break;
        default:
            wp_send_json_error('Invalid prefix type');
            wp_die();
    }

    wp_send_json_success($modifiedText);
    wp_die();
}
add_action('wp_ajax_add_prefix_splitter', 'add_prefix_ajax');
add_action('wp_ajax_nopriv_add_prefix_splitter', 'add_prefix_ajax');



/**************************************************************************************************/
//C9 add-text-suffix add_suffix
/**************************************************************************************************/
// Shortcode function to display the form on a WordPress page
function add_suffix_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_round_box_add_suffix();
    $output .= render_form_add_suffix();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('add_suffix', 'add_suffix_shortcode');

// Function to render the form
function add_suffix_render_page() {
    ?>
    <div class="wrap">
        <h1 id="operationMessage" style="text-align: center;">Add Suffix</h1>
        <form id="addSuffixForm" method="post" enctype="multipart/form-data">
            <div class="text-area-container" style="margin-top: 60px;">
                <div class="text-area">
                    <label>Input Text:</label>
                    <textarea id="text" name="inputText" rows="10" cols="40" placeholder="Enter the text"></textarea><br>
                    <input type="file" id="file" name="file"><br><br>
                </div>
                <div class="text-area">
                    <label>Result:</label>
                    <textarea id="shuffledText" rows="10" cols="40"></textarea><br>
                    <button type="button" id="downloadBtn" disabled>Download</button>
                    <button type="button" id="copyBtn" disabled>Copy</button>
                    <button type="button" id="clearBtn">Clear</button>
                </div>
            </div>
            <div class="suffix-area" style="margin-top: 60px;">
                <label style="display: block;">Suffix:</label>
                <input type="text" id="suffix" name="suffix" placeholder="Enter the suffix" style="width: 100%; margin-bottom: 10px;"><br>
                <label style="display: block;">Apply Suffix To:</label>
                <input type="radio" id="suffixWholeText" name="suffixType" value="whole" checked style="margin-right: 10px;">
                <label for="suffixWholeText" style="display: inline-block; margin-right: 20px;">Whole Text</label>
                <input type="radio" id="suffixLineByLine" name="suffixType" value="line" style="margin-right: 10px;">
                <label for="suffixLineByLine" style="display: inline-block; margin-right: 20px;">Line by Line</label>
                <input type="radio" id="suffixParagraph" name="suffixType" value="paragraph">
                <label for="suffixParagraph" style="display: inline-block;">Each Paragraph</label><br>
            </div>
            <button type="button" id="addSuffixBtn" class="ajax-add-suffix" style="display: block; margin: 20px auto;">Add Suffix</button>
        </form>
    </div>
    <?php
}

// AJAX handler for adding suffix
function add_suffix_ajax() {
    if (!isset($_POST['inputText']) || !isset($_POST['suffix']) || !isset($_POST['suffixType'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }
    $text = sanitize_textarea_field($_POST['inputText']);
    $suffix = sanitize_text_field($_POST['suffix']);
    $suffixType = $_POST['suffixType'];

    switch ($suffixType) {
        case 'whole':
            $modifiedText = $text . ' ' . $suffix;
            break;
        case 'line':
            $lines = explode("\n", $text);
            $modifiedText = implode("\n", array_map(function($line) use ($suffix) {
                return $line . ' ' . $suffix;
            }, $lines));
            break;
        case 'paragraph':
            $paragraphs = explode("\n\n", $text);
            $modifiedText = implode("\n\n", array_map(function($paragraph) use ($suffix) {
                return $paragraph . ' ' . $suffix;
            }, $paragraphs));
            break;
        default:
            wp_send_json_error('Invalid suffix type');
            wp_die();
    }

    wp_send_json_success($modifiedText);
    wp_die();
}
add_action('wp_ajax_add_suffix_splitter', 'add_suffix_ajax');
add_action('wp_ajax_nopriv_add_suffix_splitter', 'add_suffix_ajax');



/**************************************************************************************************/
//C10 remove blank lines remove_blank_lines
/**************************************************************************************************/
// Shortcode function to display the form on a WordPress page
function remove_blank_lines_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
   
    $output .= render_form_remove_blank_lines();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('remove_blank_lines', 'remove_blank_lines_shortcode');


// AJAX handler for removing blank lines
function remove_blank_lines_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }
    $text = sanitize_textarea_field($_POST['inputText']);
    $modifiedText = preg_replace('/^\s*[\r\n]/m', '', $text);

    wp_send_json_success($modifiedText);
    wp_die();
}
add_action('wp_ajax_remove_blank_lines', 'remove_blank_lines_ajax');
add_action('wp_ajax_nopriv_remove_blank_lines', 'remove_blank_lines_ajax');




/**************************************************************************************************/
//C11 Remove Duplicate Lines remove_duplicate_lines
/**************************************************************************************************/
// Shortcode function to display the form on a WordPress page

function remove_duplicate_lines_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
   
    $output .= render_form_remove_duplicate_lines();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('remove_duplicate_lines', 'remove_duplicate_lines_shortcode');


// AJAX handler for removing duplicate lines
function remove_duplicate_lines_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }
    $text = sanitize_textarea_field($_POST['inputText']);
    $lines = explode("\n", $text);
    $uniqueLines = array_unique($lines);
    $modifiedText = implode("\n", $uniqueLines);

    wp_send_json_success($modifiedText);
    wp_die();
}
add_action('wp_ajax_remove_duplicate_lines', 'remove_duplicate_lines_ajax');
add_action('wp_ajax_nopriv_remove_duplicate_lines', 'remove_duplicate_lines_ajax');


/**************************************************************************************************/
//C12 Replace Space With Line Break replace_space_with_line_break
/**************************************************************************************************/
// Shortcode function to display the form on a WordPress page
function replace_space_with_line_break_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
   
    $output .= render_form_replace_space_with_line_break();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('replace_space_with_line_break', 'replace_space_with_line_break_shortcode');


// AJAX handler for replacing spaces with line breaks
function replace_space_with_line_break_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }
    $text = sanitize_textarea_field($_POST['inputText']);
    $modifiedText = str_replace(' ', "\n", $text);

    wp_send_json_success($modifiedText);
    wp_die();
}
add_action('wp_ajax_replace_space_with_line_break', 'replace_space_with_line_break_ajax');
add_action('wp_ajax_nopriv_replace_space_with_line_break', 'replace_space_with_line_break_ajax');


/**************************************************************************************************/
//C13 Replace new lines with spaces replace_newline_with_space
/**************************************************************************************************/
// Shortcode function to display the form on a WordPress page
function replace_newline_with_space_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
   
    $output .= render_form_replace_newline_with_space();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('replace_newline_with_space', 'replace_newline_with_space_shortcode');


// AJAX handler for replacing new lines with spaces
function replace_newline_with_space_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }
    $text = sanitize_textarea_field($_POST['inputText']);
    $modifiedText = str_replace(array("\r\n", "\r", "\n"), ' ', $text);

    wp_send_json_success($modifiedText);
    wp_die();
}
add_action('wp_ajax_replace_newline_with_space', 'replace_newline_with_space_ajax');
add_action('wp_ajax_nopriv_replace_newline_with_space', 'replace_newline_with_space_ajax');



/**************************************************************************************************/
//C14 List Numbering Online add_line_numbers
/**************************************************************************************************/
// Shortcode function to display the form
function add_line_numbers_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_round_box_add_line_numbers();
    $output .= render_form_replace_add_line_numbers();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('add_line_numbers', 'add_line_numbers_shortcode');

// Function to render the form
function add_line_numbers_render_page() {
    ?>
    <div class="wrap">
        <h1 id="operationMessage" style="text-align: center;">Add Line Numbers</h1>
        <form id="addLineNumbersForm" method="post" enctype="multipart/form-data">
            <div class="text-area-container" style="margin-top: 60px;">
                <div class="text-area">
                    <label>Input Text:</label>
                    <textarea id="text" name="inputText" rows="10" cols="40" placeholder="Enter the text to add line numbers"></textarea><br>
                    <input type="file" id="file" name="file"><br><br>
                </div>
                <div class="text-area">
                    <label>Result:</label>
                    <textarea id="shuffledText" rows="10" cols="40"></textarea><br>
                    <button type="button" id="downloadBtn" disabled>Download</button>
                    <button type="button" id="copyBtn" disabled>Copy</button>
                    <button type="button" id="clearBtn">Clear</button>
                </div>
            </div>
            <div class="text-area" style="margin-top: 60px;">
    <label style="display: inline-block;">Row Mode:</label>
    <input type="radio" id="allLines" name="rowMode" value="all" checked style="margin-right: 10px;">
    <label for="allLines" style="display: inline-block; margin-right: 20px;">All Lines</label>

    <input type="radio" id="notEmptyLines" name="rowMode" value="notEmpty" style="margin-right: 10px;">
    <label for="notEmptyLines" style="display: inline-block;">Not Empty Lines</label><br>

    <label style="display: inline-block;">Line Number Format:</label>
    <input type="radio" id="justNumber" name="lineNumberFormat" value="number" checked style="margin-right: 10px;">
    <label for="justNumber" style="display: inline-block; margin-right: 20px;">Just a number: 1 2 3</label>

    <input type="radio" id="withBrackets" name="lineNumberFormat" value="brackets" style="margin-right: 10px;">
    <label for="withBrackets" style="display: inline-block; margin-right: 20px;">With brackets: 1) 2) 3)</label>

    <input type="radio" id="customNumbering" name="lineNumberFormat" value="custom" style="margin-right: 10px;">
    <label for="customNumbering" style="display: inline-block;">Custom numbering</label><br>

    <input type="text" id="customNumberingText" name="customNumberingText" placeholder="Enter custom format" style="width: 100%; margin-top: 10px;">
</div>

            <button type="button" id="simpleBtn" class="ajax-add-line-numbers" style="display: block; margin: 20px auto;">Add Line Numbers</button>
        </form>
    </div>
    <?php
}

// AJAX handler function
function add_line_numbers_ajax() {
    if (!isset($_POST['inputText']) || !isset($_POST['rowMode']) || !isset($_POST['lineNumberFormat'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }
    
    $text = sanitize_textarea_field($_POST['inputText']);
    $rowMode = $_POST['rowMode'];
    $lineNumberFormat = $_POST['lineNumberFormat'];
    $customNumberingText = sanitize_text_field($_POST['customNumberingText']);

    $lines = explode("\n", $text);
    $numberedLines = [];
    $lineNumber = 1;

    foreach ($lines as $line) {
        if ($rowMode == 'notEmpty' && trim($line) == '') {
            $numberedLines[] = $line;
            continue;
        }

        switch ($lineNumberFormat) {
            case 'number':
                $numberedLines[] = $lineNumber . ' ' . $line;
                break;
            case 'brackets':
                $numberedLines[] = $lineNumber . ') ' . $line;
                break;
            case 'custom':
                $numberedLines[] = str_replace('%d', $lineNumber, $customNumberingText) . ' ' . $line;
                break;
            default:
                wp_send_json_error('Invalid line number format');
                wp_die();
        }

        $lineNumber++;
    }

    $result = implode("\n", $numberedLines);
    wp_send_json_success($result);
    wp_die();
}
add_action('wp_ajax_add_line_numbers', 'add_line_numbers_ajax');
add_action('wp_ajax_nopriv_add_line_numbers', 'add_line_numbers_ajax');


/**************************************************************************************************/
//C15 remove all white spaces remove_white_spaces
/**************************************************************************************************/
// Function to render the shortcode for removing white spaces
// Shortcode function to display the form on a WordPress page
function remove_white_spaces_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_form_replace_remove_white_spaces();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('remove_white_spaces', 'remove_white_spaces_shortcode');



// AJAX handler for removing white spaces
function remove_white_spaces_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('No input text provided');
        wp_die();
    }

    $text = sanitize_textarea_field($_POST['inputText']);
    $processed_text = preg_replace('/\s+/', '', $text); // Remove all white spaces

    wp_send_json_success($processed_text);
    wp_die();
}
add_action('wp_ajax_remove_white_spaces', 'remove_white_spaces_ajax');
add_action('wp_ajax_nopriv_remove_white_spaces', 'remove_white_spaces_ajax');



/**************************************************************************************************/
//C16 Remove ALl Punctuations Marks
/**************************************************************************************************/
// Shortcode function to display the form on a WordPress page
function remove_punctuations_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_form_replace_remove_punctuations();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('remove_punctuations', 'remove_punctuations_shortcode');

// AJAX handler for removing punctuations
function remove_punctuations_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('No input text provided');
        wp_die();
    }

    $text = sanitize_textarea_field($_POST['inputText']);
    $processed_text = preg_replace('/[^\w\s]/', '', $text); // Remove all punctuations except letters and spaces

    wp_send_json_success($processed_text);
    wp_die();
}
add_action('wp_ajax_remove_punctuations', 'remove_punctuations_ajax');
add_action('wp_ajax_nopriv_remove_punctuations', 'remove_punctuations_ajax');


/**************************************************************************************************/
//C17 Replaces Spaces with Tabs replace_spaces_with_tab
/**************************************************************************************************/
// Shortcode function to display the form on a WordPress page
function replace_spaces_with_tab_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_form_replace_spaces_with_tab();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('replace_spaces_with_tab', 'replace_spaces_with_tab_shortcode');


// AJAX handler for replacing spaces with tab
function replace_spaces_with_tab_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('No input text provided');
        wp_die();
    }

    $text = sanitize_textarea_field($_POST['inputText']);
    $processed_text = preg_replace('/\s+/', "\t", $text); // Replace all spaces with tabs

    wp_send_json_success($processed_text);
    wp_die();
}
add_action('wp_ajax_replace_spaces_with_tab', 'replace_spaces_with_tab_ajax');
add_action('wp_ajax_nopriv_replace_spaces_with_tab', 'replace_spaces_with_tab_ajax');



/**************************************************************************************************/
//C18 Replace Tabs with Spaces replace_tabs
/**************************************************************************************************/
// Function to render the shortcode for replacing text tabs with spaces
function replace_tabs_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .=render_custom_round_box_replace_tabs();
    $output .= render_form_replace_tabs();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('replace_tabs', 'replace_tabs_shortcode');

// AJAX handler for replacing tabs and adjusting spaces
function replace_tabs_ajax() {
    if (!isset($_POST['inputText']) || !isset($_POST['spacesPerTab'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }

    $text = sanitize_textarea_field($_POST['inputText']);
    $spaces_after_word = intval($_POST['spacesPerTab']);

    // Replace multiple spaces between words with specified number of spaces
    $spaces_between_words = str_repeat(' ', $spaces_after_word);
    $result = preg_replace('/\s+/', $spaces_between_words, $text);

    wp_send_json_success($result);
    wp_die();
}



add_action('wp_ajax_replace_tabs_with_spaces', 'replace_tabs_ajax');
add_action('wp_ajax_nopriv_replace_tabs_with_spaces', 'replace_tabs_ajax');



/**************************************************************************************************/
//D1 Online converter Case inversion  invert_text_case
/**************************************************************************************************/
// Function to render the shortcode for inverting text case
function invert_text_case_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    
    $output .= render_form_invert_text_case();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('invert_text_case', 'invert_text_case_shortcode');

// Function to render the HTML form for the shortcode
function render_invert_text_case_form() {
    ?>
    <div class="wrap">
        <h1 id="operationMessage" style="text-align: center;">Invert Text Case Conversion</h1>
        <form id="invertTextCaseForm" method="post" enctype="multipart/form-data">
            <div class="text-area-container" style="margin-top: 60px;">
                <div class="text-area">
                    <label>Input Text:</label>
                    <textarea id="text" name="inputText" rows="10" cols="40" placeholder="Enter the text"></textarea><br>
                    <input type="file" id="file" name="file"><br><br>
                </div>
                <div class="text-area">
                    <label>Result:</label>
                    <textarea id="shuffledText" rows="10" cols="40"></textarea><br>
                    <button type="button" id="downloadBtn" disabled>Download</button>
                    <button type="button" id="copyBtn" disabled>Copy</button>
                    <button type="button" id="clearBtn">Clear</button>
                </div>
            </div>
            <button type="button" id="simpleBtn" class="ajax-invert-case" style="display: block; margin: 20px auto;">Invert Case</button>
        </form>
    </div>
    <?php
}

// AJAX function to invert text case
function invert_text_case_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('Missing input text');
        wp_die();
    }

    $text = sanitize_textarea_field($_POST['inputText']);
    $inverted_text = '';

    // Invert case for each character
    for ($i = 0; $i < strlen($text); $i++) {
        $char = $text[$i];
        if (ctype_upper($char)) {
            $inverted_text .= strtolower($char);
        } elseif (ctype_lower($char)) {
            $inverted_text .= strtoupper($char);
        } else {
            $inverted_text .= $char; // Keep non-alphabetical characters unchanged
        }
    }

    wp_send_json_success($inverted_text);
    wp_die();
}
add_action('wp_ajax_invert_text_case', 'invert_text_case_ajax');
add_action('wp_ajax_nopriv_invert_text_case', 'invert_text_case_ajax');




/**************************************************************************************************/
//D2 Change Case of Text Online change_text_case
/**************************************************************************************************/
// Function to render the shortcode for changing text case
function change_text_case_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_round_box_change_text_case();
    $output .= render_form_change_text_case();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('change_text_case', 'change_text_case_shortcode');


// AJAX function to change text case
function change_text_case_ajax() {
    if (!isset($_POST['inputText']) || !isset($_POST['caseOption'])) {
        wp_send_json_error('Missing input text or case option');
        wp_die();
    }

    $text = sanitize_textarea_field($_POST['inputText']);
    $case_option = $_POST['caseOption'];
    $converted_text = '';

    switch ($case_option) {
        case 'lowercase':
            $converted_text = strtolower($text);
            break;
        case 'uppercase':
            $converted_text = strtoupper($text);
            break;
        case 'randomRegister':
            $converted_text = random_register_case($text);
            break;
        case 'headerRegister':
            $converted_text = ucwords(strtolower($text));
            break;
        case 'sentenceFormat':
            $converted_text = sentence_case_format($text);
            break;
        case 'camelCase':
            $converted_text = camel_case($text);
            break;
        case 'reverseRegister1':
            $converted_text = reverse_register1_case($text);
            break;
        case 'reverseRegister2':
            $converted_text = reverse_register2_case($text);
            break;
        case 'reverseCase':
            $converted_text = reverse_case($text);
            break;
        case 'titleCase':
            $converted_text = title_case($text);
            break;
        case 'reverseRegisterR':
            $converted_text = reverse_registerR_case($text);
            break;
        default:
            wp_send_json_error('Invalid case option');
            wp_die();
    }

    wp_send_json_success($converted_text);
    wp_die();
}

// Helper function for Random Register Case
function random_register_case($text) {
    $converted_text = '';
    $length = strlen($text);

    for ($i = 0; $i < $length; $i++) {
        $char = $text[$i];
        if (rand(0, 1)) {
            $converted_text .= strtoupper($char);
        } else {
            $converted_text .= strtolower($char);
        }
    }

    return $converted_text;
}

// Helper function for Sentence Case Format
function sentence_case_format($text) {
    // Ensure first letter of the text is capitalized
    $text = ucfirst($text);

    // Capitalize the first letter of each sentence
    return preg_replace_callback('/[.!?] *+([^ ])/', function($matches) {
        return strtoupper($matches[0]);
    }, $text);
}

// Helper function for Camel Case
function camel_case($text) {
    // Remove spaces and make first letter lowercase
    $text = strtolower(str_replace(' ', '', $text));
    // Make first letter uppercase
    return ucfirst($text);
}

// Helper function for Reverse Register -1 Case
function reverse_register1_case($text) {
    $converted_text = '';
    $length = strlen($text);
    $to_upper = true; // Start with uppercase

    for ($i = 0; $i < $length; $i++) {
        $char = $text[$i];
        if (ctype_alpha($char)) {
            if ($to_upper) {
                $converted_text .= strtoupper($char);
            } else {
                $converted_text .= strtolower($char);
            }
            $to_upper = !$to_upper; // Toggle case
        } else {
            $converted_text .= $char;
        }
    }

    return $converted_text;
}

// Helper function for Reverse Register -2 Case
function reverse_register2_case($text) {
    $converted_text = '';
    $length = strlen($text);
    $to_upper = false; // Start with lowercase

    for ($i = 0; $i < $length; $i++) {
        $char = $text[$i];
        if (ctype_alpha($char)) {
            if ($to_upper) {
                $converted_text .= strtoupper($char);
            } else {
                $converted_text .= strtolower($char);
            }
            $to_upper = !$to_upper; // Toggle case
        } else {
            $converted_text .= $char;
        }
    }

    return $converted_text;
}

// Helper function for Reverse Case
function reverse_case($text) {
    return strtr($text, 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz', 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');
}

// Helper function for Title Case
function title_case($text) {
    return ucwords(strtolower($text));
}

// Helper function for Reverse RegisterR Case
function reverse_registerR_case($text) {
    $words = explode(' ', $text);
    foreach ($words as &$word) {
        $last_char = substr($word, -1);
        $word = substr_replace($word, strtoupper($last_char), -1);
    }
    return implode(' ', $words);
}

add_action('wp_ajax_change_text_case', 'change_text_case_ajax');
add_action('wp_ajax_nopriv_change_text_case', 'change_text_case_ajax');



/**************************************************************************************************/
//D3 Convert characters to Uppercase uppercase_converter
/**************************************************************************************************/
// AJAX handler function for converting text to uppercase
add_action('wp_ajax_characters_to_uppercase', 'characters_to_uppercase_callback');
add_action('wp_ajax_nopriv_characters_to_uppercase', 'characters_to_uppercase_callback');
function characters_to_uppercase_callback() {
    if (isset($_POST['inputText'])) {
        $text = sanitize_textarea_field($_POST['inputText']);
        $uppercase_text = strtoupper($text);
        wp_send_json_success($uppercase_text);
    } else {
        wp_send_json_error('Missing input text');
    }
    wp_die();
}

// Shortcode for the uppercase converter
function uppercase_converter_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_form_upper_case_converter();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('uppercase_converter', 'uppercase_converter_shortcode');


/**************************************************************************************************/
//D4 Random Case Text Converter random_case_converter
/**************************************************************************************************/

// AJAX handler function for converting text to random case
add_action('wp_ajax_random_case_text_converter', 'random_case_text_converter_callback');
add_action('wp_ajax_nopriv_random_case_text_converter', 'random_case_text_converter_callback');
function random_case_text_converter_callback() {
    if (isset($_POST['inputText'])) {
        $text = sanitize_textarea_field($_POST['inputText']);
        $random_case_text = toggle_random_case($text);
        wp_send_json_success($random_case_text);
    } else {
        wp_send_json_error('Missing input text');
    }
    wp_die();
}

// Function to toggle characters to random case
function toggle_random_case($text) {
    $random_case_text = '';
    $length = mb_strlen($text, 'UTF-8');
    for ($i = 0; $i < $length; $i++) {
        $char = mb_substr($text, $i, 1, 'UTF-8');
        $random_case_text .= mt_rand(0, 1) ? mb_strtoupper($char, 'UTF-8') : mb_strtolower($char, 'UTF-8');
    }
    return $random_case_text;
}

// Shortcode for the random case text converter
function random_case_converter_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_form_random_case_converter();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('random_case_converter', 'random_case_converter_shortcode');



/**************************************************************************************************/
//D5 Convert Characters to Lowercase
/**************************************************************************************************/
// AJAX handler function for converting text to lowercase

// Shortcode for the lowercase text converter
function lowercase_converter_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_form_lowercase_converter();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('lowercase_converter', 'lowercase_converter_shortcode');

function lowercase_text_converter_callback() {
    if (isset($_POST['inputText'])) {
        $text = sanitize_textarea_field($_POST['inputText']);
        $lowercase_text = mb_strtolower($text, 'UTF-8');
        wp_send_json_success($lowercase_text);
    } else {
        wp_send_json_error('Missing input text');
    }
    wp_die();
}
add_action('wp_ajax_lowercase_text_converter', 'lowercase_text_converter_callback');
add_action('wp_ajax_nopriv_lowercase_text_converter', 'lowercase_text_converter_callback');

/**************************************************************************************************/
//E1 Text Sorting, Online Text Filter filter_text
/**************************************************************************************************/
// Shortcode function to display the Filter Text tool on a WordPress page
function filter_text_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
   
    $output .= render_custom_round_box_filter_text();
    $output .= render_form_sort_filter_text();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('filter_text', 'filter_text_shortcode');
// AJAX handler for filtering text
// AJAX handler for filtering text
function filter_text_ajax() {
    if (!isset($_POST['inputText']) || !isset($_POST['filterKeyword'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }

    // Sanitize input text and filter keyword
    $text = sanitize_textarea_field($_POST['inputText']);
    $filterKeyword = sanitize_text_field($_POST['filterKeyword']);

    // Split text into lines and remove empty lines
    $lines = array_filter(array_map('trim', explode("\n", $text)), 'strlen');

    // Filter lines based on callback function
    $filteredLines = array_filter($lines, function($line) use ($filterKeyword) {
        return filter_callback($line, $filterKeyword);
    });

    // Optionally reverse the order if requested
    if (isset($_POST['reverseOrder']) && $_POST['reverseOrder'] == 1) {
        $filteredLines = array_reverse($filteredLines);
    }

    // Reconstruct filtered text
    $filteredText = implode("\n", $filteredLines);

    // Send JSON response with filtered text
    wp_send_json_success($filteredText);
    wp_die();
}

// Callback function for filtering lines
function filter_callback($line, $filterKeyword) {
    // Filter out lines that contain the filter keyword
    return strpos($line, $filterKeyword) === false;
}


// Hook AJAX action for logged-in users
add_action('wp_ajax_filter_text', 'filter_text_ajax');
// Hook AJAX action for non-logged-in users
add_action('wp_ajax_nopriv_filter_text', 'filter_text_ajax');


/**************************************************************************************************/
//E2 Sort Words in Alphabetical order sort_words
/**************************************************************************************************/
// Shortcode function to display the Sort Words tool on a WordPress page
function sort_words_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
   
    $output .= render_custom_round_box_words_string();
    $output .= render_form_sort_words_string();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('sort_words', 'sort_words_shortcode');

// Function to render the Sort Words tool form
function sort_words_render_page() {
    ?>
    <div class="wrap">
        <h1 id="operationMessage" style="text-align: center;">Sort Words Tool</h1>
        <form id="sortWordsForm" method="post" enctype="multipart/form-data">
            <div class="text-area-container" style="margin-top: 60px;">
                <div class="text-area">
                    <label>Input Text:</label>
                    <textarea id="text" name="inputText" rows="10" cols="40" placeholder="Enter the text"></textarea><br>
                    <input type="file" id="file" name="file"><br><br>
                </div>
                <div class="text-area">
                    <label>Sorted Result:</label>
                    <textarea id="shuffledText" rows="10" cols="40"></textarea><br>
                    <button type="button" id="downloadBtn" disabled>Download</button>
                    <button type="button" id="copyBtn" disabled>Copy</button>
                    <button type="button" id="clearBtn">Clear</button>
                </div>
            </div>
            <label style="display: block; margin-top: 20px;">
                
                Words in alphabetical order (FROM A TO Z)
            </label>
            <label style="display: block;">
                <input type="radio" id="sortOrderZA" name="sortOrder" value="za">
                Words in reverse alphabetical order (FROM Z TO A)
            </label>
            <button type="button" id="simpleBtn" class="ajax-sort-words" style="display: block; margin: 20px auto;">Sort Words</button>
        </form>
    </div>
    <?php
}

// AJAX handler for sorting words
function sort_words_ajax() {
    if (!isset($_POST['inputText']) || !isset($_POST['sortOrder'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }
    
    // Sanitize input text
    $text = sanitize_textarea_field($_POST['inputText']);
    $sortOrder = sanitize_text_field($_POST['sortOrder']);
    
    // Split text into words
    $words = preg_split('/\s+/', $text, -1, PREG_SPLIT_NO_EMPTY);
    
    // Sort words based on selected order
    if ($sortOrder == 'az') {
        sort($words, SORT_STRING | SORT_FLAG_CASE);
    } else {
        rsort($words, SORT_STRING | SORT_FLAG_CASE);
    }

    // Reconstruct sorted text
    $sortedText = implode(' ', $words);

    // Send JSON response with sorted text
    wp_send_json_success($sortedText);
    wp_die();
}

// Hook AJAX action for logged-in users
add_action('wp_ajax_sort_words', 'sort_words_ajax');
// Hook AJAX action for non-logged-in users
add_action('wp_ajax_nopriv_sort_words', 'sort_words_ajax');



/**************************************************************************************************/
//E3 Sort Letters in Text sort_letters
/**************************************************************************************************/
// Shortcode function to display the Sort Letters tool on a WordPress page
function sort_letters_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
   
    $output .= render_custom_round_box_letter_string();
    $output .= render_form_sort_letter_string();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('sort_letters', 'sort_letters_shortcode');



// Function to shuffle letters randomly
function shuffle_letters($string) {
    $letters = str_split($string);
    shuffle($letters);
    return implode('', $letters);
}

// AJAX handler for sorting letters
function sort_letters_ajax() {
    if (!isset($_POST['inputText']) || !isset($_POST['sortOrder'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }

    // Sanitize input text
    $text = sanitize_textarea_field($_POST['inputText']);
    $sortOrder = sanitize_text_field($_POST['sortOrder']);
    $separateWords = isset($_POST['separateWords']) ? true : false;
    $caseSensitive = isset($_POST['caseSensitive']) ? true : false;

    // Sort letters based on selected order
    $sortedText = '';
    if ($separateWords) {
        $words = preg_split('/\s+/', $text, -1, PREG_SPLIT_NO_EMPTY);
        foreach ($words as $word) {
            if (!$caseSensitive) {
                $letters = str_split(strtolower($word));
            } else {
                $letters = str_split($word);
            }
            
            if ($sortOrder == 'az') {
                sort($letters);
            } elseif ($sortOrder == 'za') {
                rsort($letters);
            } else {
                $letters = str_split(shuffle_letters($word));
            }
            $sortedText .= implode('', $letters) . ' ';
        }
    } else {
        if (!$caseSensitive) {
            $letters = str_split(strtolower($text));
        } else {
            $letters = str_split($text);
        }

        if ($sortOrder == 'az') {
            sort($letters);
        } elseif ($sortOrder == 'za') {
            rsort($letters);
        } else {
            $letters = str_split(shuffle_letters($text));
        }
        $sortedText = implode('', $letters);
    }

    // Send JSON response with sorted text
    wp_send_json_success(trim($sortedText));
    wp_die();
}

// Hook AJAX action for logged-in users
add_action('wp_ajax_sort_letters', 'sort_letters_ajax');
// Hook AJAX action for non-logged-in users
add_action('wp_ajax_nopriv_sort_letters', 'sort_letters_ajax');




/**************************************************************************************************/
//E4 Sort Text Strings Online sort_text_strings
/**************************************************************************************************/
// Shortcode function to display the Sort Text Strings tool on a WordPress page
function sort_text_strings_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
   
    $output .= render_custom_round_box_text_string();
    $output .= render_form_sort_text_string();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('sort_text_strings', 'sort_text_strings_shortcode');

// AJAX handler for sorting text strings
function sort_text_strings_ajax() {
    // Verify required parameters
    if (!isset($_POST['inputText']) || !isset($_POST['sortOrder'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }

    // Sanitize input
    $text = sanitize_textarea_field($_POST['inputText']);
    $sortOrder = sanitize_text_field($_POST['sortOrder']);
    $removeDuplicates = isset($_POST['removeDuplicates']) && $_POST['removeDuplicates'] === 'true' ? true : false;
    $separateWords = isset($_POST['separateWords']) && $_POST['separateWords'] === 'true' ? true : false;
    $caseSensitive = isset($_POST['caseSensitive']) && $_POST['caseSensitive'] === 'true' ? true : false;

    // Split text into lines
    $lines = explode("\n", $text);

    // Remove empty lines and trim whitespace
    $lines = array_map('trim', array_filter($lines));

    // Apply removal of duplicate lines if requested
    if ($removeDuplicates) {
        $lines = array_unique($lines);
    }

    // Define custom sorting functions
    $lengthComparator = function($a, $b) {
        return strlen($b) - strlen($a); // Sort by length descending
    };

    $alphabeticalComparator = function($a, $b) {
        return strcmp($a, $b); // Sort alphabetically
    };

    $reverseAlphabeticalComparator = function($a, $b) {
        return strcmp($b, $a); // Sort reverse alphabetically
    };

    // Apply sorting based on selected order
    switch ($sortOrder) {
        case 'alphabetical':
            usort($lines, $alphabeticalComparator);
            break;
        case 'reverseAlphabetical':
            usort($lines, $reverseAlphabeticalComparator);
            break;
        case 'lengthHighToLow':
            usort($lines, $lengthComparator);
            break;
        case 'lengthLowToHigh':
            usort($lines, function($a, $b) {
                return strlen($a) - strlen($b); // Sort by length ascending
            });
            break;
        case 'randomOrder':
            shuffle($lines);
            break;
        default:
            // If invalid sort order, return original text
            $lines = explode("\n", $text);
            break;
    }

    // If separateWords is checked, split each line into words and sort accordingly
    if ($separateWords) {
        $sortedLines = [];
        foreach ($lines as $line) {
            $words = explode(' ', $line);
            switch ($sortOrder) {
                case 'alphabetical':
                    if ($caseSensitive) {
                        sort($words);
                    } else {
                        sort($words, SORT_STRING | SORT_FLAG_CASE);
                    }
                    break;
                case 'reverseAlphabetical':
                    if ($caseSensitive) {
                        rsort($words);
                    } else {
                        rsort($words, SORT_STRING | SORT_FLAG_CASE);
                    }
                    break;
                case 'lengthHighToLow':
                    usort($words, $lengthComparator);
                    break;
                case 'lengthLowToHigh':
                    usort($words, function($a, $b) {
                        return strlen($a) - strlen($b); // Sort by word length ascending
                    });
                    break;
                case 'randomOrder':
                    shuffle($words);
                    break;
                default:
                    // If invalid sort order, keep words as is
                    break;
            }
            $sortedLines[] = implode(' ', $words);
        }
        $sortedText = implode("\n", $sortedLines);
    } else {
        // Reconstruct sorted text
        $sortedText = implode("\n", $lines);
    }

    // Send JSON response with sorted text
    wp_send_json_success($sortedText);
    wp_die();
}

add_action('wp_ajax_sort_text_strings', 'sort_text_strings_ajax');
add_action('wp_ajax_nopriv_sort_text_strings', 'sort_text_strings_ajax');



/**************************************************************************************************/
//E5 Sort List Online sort_list
/**************************************************************************************************/
// Shortcode function to display the Sort List tool on a WordPress page
function sort_list_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_round_box_sort_list();
    $output .= render_form_sort_list();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('sort_list', 'sort_list_shortcode');


// AJAX handler for sorting list
function sort_list_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }
    
    // Sanitize input text
    $text = sanitize_textarea_field($_POST['inputText']);
    
    // Split text into lines and trim whitespace
    $lines = array_map('trim', explode("\n", $text));
    
    // Remove empty lines (lines with only whitespace)
    $lines = array_filter($lines, function($line) {
        return !empty($line);
    });

    // Determine sorting order based on checkboxes
    $reverseOrder = isset($_POST['reverseOrder']) && $_POST['reverseOrder'] === 'true';
    $numericSort = isset($_POST['numericSort']) && $_POST['numericSort'] === 'true';

    // Separate lines into numeric and non-numeric categories
    $numericLines = [];
    $nonNumericLines = [];

    foreach ($lines as $line) {
        if ($numericSort && is_numeric($line)) {
            $numericLines[] = $line;
        } else {
            $nonNumericLines[] = $line;
        }
    }

    // Sort numeric lines numerically
    sort($numericLines, SORT_NUMERIC);

    // Concatenate sorted lines based on sorting order
    if ($numericSort && $reverseOrder) {
        $sortedLines = array_merge(array_reverse($numericLines), array_reverse($nonNumericLines));
    } elseif ($numericSort && !$reverseOrder) {
        $sortedLines = array_merge($numericLines, $nonNumericLines);
    } elseif (!$numericSort && $reverseOrder) {
        $sortedLines = array_merge(array_reverse($lines));
    } else {
        $sortedLines = $lines;
    }

    // Reconstruct sorted text
    $sortedText = implode("\n", $sortedLines);

    // Send JSON response with sorted text
    wp_send_json_success($sortedText);
    wp_die();
}

add_action('wp_ajax_sort_list', 'sort_list_ajax');
add_action('wp_ajax_nopriv_sort_list', 'sort_list_ajax');


/**************************************************************************************************/
//F1 Extract Text  extract_text_fragment
/**************************************************************************************************/
// Shortcode function to display the Extract Text Fragment tool on a WordPress page
function extract_text_fragment_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_round_box_extract_text_fragment();
    $output .= render_form_extract_text_fragment();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('extract_text_fragment', 'extract_text_fragment_shortcode');


// AJAX handler for extracting text fragment
function extract_text_fragment_ajax() {
    if (!isset($_POST['inputText']) || !isset($_POST['startPos']) || !isset($_POST['fragmentLength'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }

    // Sanitize input
    $text = sanitize_textarea_field($_POST['inputText']);
    $startPos = intval($_POST['startPos']);
    $fragmentLength = intval($_POST['fragmentLength']);
    $multiLineMode = isset($_POST['multiLineMode']) && $_POST['multiLineMode'] === 'true';

    if ($multiLineMode) {
        // Apply extraction to each line
        $lines = explode("\n", $text);
        $extractedLines = array_map(function($line) use ($startPos, $fragmentLength) {
            return substr($line, $startPos, $fragmentLength);
        }, $lines);
        $extractedText = implode("\n", $extractedLines);
    } else {
        // Apply extraction to the entire text
        $extractedText = substr($text, $startPos, $fragmentLength);
    }

    wp_send_json_success($extractedText);
    wp_die();
}

add_action('wp_ajax_extract_text_fragment', 'extract_text_fragment_ajax');
add_action('wp_ajax_nopriv_extract_text_fragment', 'extract_text_fragment_ajax');



/**************************************************************************************************/
//F2 sort-with-delimiter Sort words with seprator sort_words_by_separator
/**************************************************************************************************/
// Shortcode function to display the Sort Words by Separator tool on a WordPress page
function sort_words_by_separator_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_round_box_sort_words_by_separator();
    $output .= render_form_sort_words_by_separator();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('sort_words_by_separator', 'sort_words_by_separator_shortcode');

// AJAX handler for sorting words by separator
function sort_words_by_separator_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }
    
    // Sanitize input text
    $text = sanitize_textarea_field($_POST['inputText']);
    
    // Get separator from input
    $separator = $_POST['separator'];
    $customSeparator = isset($_POST['customSeparator']) ? sanitize_text_field($_POST['customSeparator']) : ' ';

    // Replace space with custom separator if selected
    if ($separator === 'custom') {
        $text = str_replace(' ', $customSeparator, $text);
    } else {
        $text = str_replace($separator, ' ', $text); // Convert other separators to space for consistent processing
    }
    
    // Split text into words based on space
    $words = explode(' ', $text);
    
    // Remove spaces from left to right if selected
    if (isset($_POST['removeSpaces']) && $_POST['removeSpaces'] === 'true') {
        $words = array_map('trim', $words);
    }

    // Remove duplicate words if selected
    if (isset($_POST['removeDuplicates']) && $_POST['removeDuplicates'] === 'true') {
        $words = array_unique($words);
    }
    
    // Determine sorting option based on radio buttons
    $sortingOption = sanitize_text_field($_POST['sortingOption']);
    switch ($sortingOption) {
        case 'reverse':
            rsort($words, SORT_STRING);
            break;
        case 'length_desc':
            usort($words, function($a, $b) {
                return strlen($b) - strlen($a);
            });
            break;
        case 'length_asc':
            usort($words, function($a, $b) {
                return strlen($a) - strlen($b);
            });
            break;
        case 'alphabet':
        default:
            sort($words, SORT_STRING);
            break;
    }

    // Reconstruct sorted text
    $sortedText = implode(' ', $words);

    // Send JSON response with sorted text
    wp_send_json_success($sortedText);
    wp_die();
}



add_action('wp_ajax_sort_words_by_separator', 'sort_words_by_separator_ajax');
add_action('wp_ajax_nopriv_sort_words_by_separator', 'sort_words_by_separator_ajax');


/**************************************************************************************************/
//F3 Extract regex matches from text extract_regex_matches
/**************************************************************************************************/
// Shortcode function to display the Extract Regex Matches tool on a WordPress page
function extract_regex_matches_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_round_box_regex_matches();
    $output .= render_form_regex_matches();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('extract_regex_matches', 'extract_regex_matches_shortcode');

// AJAX handler for extracting regex matches
function extract_regex_matches_ajax() {
    if (!isset($_POST['inputText']) || !isset($_POST['regex']) || !isset($_POST['separator'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }

    // Sanitize input text and regex
    $text = sanitize_textarea_field($_POST['inputText']);
    $regex = $_POST['regex'];
    $separator = sanitize_text_field($_POST['separator']);

    // Perform regex match
    preg_match_all('/' . $regex . '/', $text, $matches);

    // Check if no matches found
    if (empty($matches[0])) {
        wp_send_json_error('No matches found');
        wp_die();
    }

    // Join matches with separator
    $extractedText = implode($separator, $matches[0]);

    // Send JSON response with extracted text
    wp_send_json_success($extractedText);
    wp_die();
}

add_action('wp_ajax_extract_regex_matches', 'extract_regex_matches_ajax');
add_action('wp_ajax_nopriv_extract_regex_matches', 'extract_regex_matches_ajax');



/**************************************************************************************************/
//F4 Removing HTML Tags in Text remove_html_tags
/**************************************************************************************************/
// Shortcode function to display the HTML tags removal tool on a WordPress page
function remove_html_tags_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    
    $output .= render_form_remove_html_tags();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('remove_html_tags', 'remove_html_tags_shortcode');


// AJAX handler for removing HTML tags from text
function remove_html_tags_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }
    
    // Sanitize input text
    $text = wp_strip_all_tags($_POST['inputText']);

    // Send JSON response with filtered text
    wp_send_json_success($text);
    wp_die();
}

add_action('wp_ajax_remove_html_tags', 'remove_html_tags_ajax');
add_action('wp_ajax_nopriv_remove_html_tags', 'remove_html_tags_ajax');



/**************************************************************************************************/
//F5 Extract Text from XML extract_text_from_xml
/**************************************************************************************************/
// Shortcode function to display the Extract Text from XML tool on a WordPress page
function extract_text_from_xml_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    
    $output .= render_form_extract_xml_text();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('extract_text_from_xml', 'extract_text_from_xml_shortcode');


// AJAX handler for extracting text from XML
function extract_xml_text_ajax() {
    if (!isset($_POST['xmlText']) && empty($_FILES['xmlFile']['tmp_name'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }

    if (!empty($_FILES['xmlFile']['tmp_name'])) {
        $xml_content = file_get_contents($_FILES['xmlFile']['tmp_name']);
    } else {
        $xml_content = sanitize_textarea_field($_POST['xmlText']);
    }

    // Extract text from XML content
    $extracted_text = strip_tags($xml_content);

    wp_send_json_success($extracted_text);
    wp_die();
}

add_action('wp_ajax_extract_xml_text', 'extract_xml_text_ajax');
add_action('wp_ajax_nopriv_extract_xml_text', 'extract_xml_text_ajax');



/**************************************************************************************************/
//F6 Extract Text from BBCode extract_bbcode_text
/**************************************************************************************************/
// Shortcode function to display the Extract BBCode Text tool on a WordPress page
function extract_bbcode_text_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    
    $output .= render_form_extract_bbcode_text();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('extract_bbcode_text', 'extract_bbcode_text_shortcode');


// AJAX handler for extracting text from BBCode
function extract_bbcode_text_ajax() {
    if (!isset($_POST['inputBBCode'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }
    
    // Sanitize input BBCode
    $bbcode = sanitize_textarea_field($_POST['inputBBCode']);
    
    // Remove unwanted BBCode-like tags while keeping content within
    $extractedText = preg_replace('/\[(\/?)(?:quote|b|i|u|list|code|img|url)\b[^]]*\]/', '', $bbcode);
    
    // Send JSON response with extracted text
    wp_send_json_success($extractedText);
    wp_die();
}

add_action('wp_ajax_extract_bbcode_text', 'extract_bbcode_text_ajax');
add_action('wp_ajax_nopriv_extract_bbcode_text', 'extract_bbcode_text_ajax');


/**************************************************************************************************/
//F7  Extract Text from JSON file extract_text_from_json
/**************************************************************************************************/
// Shortcode function to display the Extract Text from JSON tool on a WordPress page
function extract_text_from_json_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    
    $output .= render_form_extract_text_from_json();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('extract_text_from_json', 'extract_text_from_json_shortcode');

// AJAX handler for extracting text from JSON
function extract_text_from_json_ajax() {
    if (!isset($_POST['jsonText'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }
    
    // Sanitize input JSON text
    $json_text = wp_unslash($_POST['jsonText']);
    
    // Attempt to decode JSON
    $decoded_json = json_decode($json_text, true);
    
    // Check if JSON decoding was successful
    if ($decoded_json === null) {
        wp_send_json_error('Invalid JSON format');
        wp_die();
    }
    
    // Extract text from JSON data
    $extracted_text = extract_text_from_json_recursive($decoded_json);
    
    // Send JSON response with extracted text
    wp_send_json_success($extracted_text);
    wp_die();
}

// Recursive function to extract text from nested JSON with each value on a new line
function extract_text_from_json_recursive($json_data) {
    $extracted_text = '';
    
    foreach ($json_data as $key => $value) {
        if (is_array($value)) {
            $extracted_text .= extract_text_from_json_recursive($value) . "\n";
        } else {
            $extracted_text .= $value . "\n";
        }
    }
    
    return trim($extracted_text);
}


// Register AJAX actions for logged-in users and guests
add_action('wp_ajax_extract_text_from_json', 'extract_text_from_json_ajax');
add_action('wp_ajax_nopriv_extract_text_from_json', 'extract_text_from_json_ajax');



/**************************************************************************************************/
//F8 Extract all Email Addresses in Text
/**************************************************************************************************/
// Shortcode function to display the Extract Email Addresses tool on a WordPress page
function extract_emails_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    
    $output .= render_form_extract_emails();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('extract_emails', 'extract_emails_shortcode');


// AJAX handler for extracting email addresses
function extract_emails_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }
    
    // Sanitize input text
    $text = sanitize_textarea_field($_POST['inputText']);
    
    // Regular expression to match email addresses
    $pattern = '/[\w\.-]+@[\w\.-]+\.[\w\.-]+/';
    preg_match_all($pattern, $text, $matches);
    
    // Extracted email addresses
    $extractedEmails = implode("\n", $matches[0]);
    
    // Send JSON response with extracted emails
    wp_send_json_success($extractedEmails);
    wp_die();
}

add_action('wp_ajax_extract_emails', 'extract_emails_ajax');
add_action('wp_ajax_nopriv_extract_emails', 'extract_emails_ajax');


/**************************************************************************************************/
//F9 Extract URLs Online extract_urls
/**************************************************************************************************/
// Shortcode function to display the Extract URLs tool on a WordPress page
function extract_urls_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    
    $output .= render_form_extract_urls();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('extract_urls', 'extract_urls_shortcode');

// AJAX handler for extracting URLs from text
function extract_urls_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }
    
    // Sanitize input text
    $text = sanitize_textarea_field($_POST['inputText']);
    
    // Use regex to find URLs in the input text
    preg_match_all('/(https?|ftp):\/\/[^\s\/$.?#].[^\s]*/', $text, $matches);
    
    // Extract URLs found
    $extractedUrls = implode("\n", $matches[0]);

    // Send JSON response with extracted URLs
    wp_send_json_success($extractedUrls);
    wp_die();
}

// Hooking the AJAX handler to both logged-in and non-logged-in users
add_action('wp_ajax_extract_urls', 'extract_urls_ajax');
add_action('wp_ajax_nopriv_extract_urls', 'extract_urls_ajax');


/**************************************************************************************************/
//F10 Extract Number from Text Online
/**************************************************************************************************/
// Shortcode function to display the Extract Numbers tool on a WordPress page
function extract_numbers_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    
    $output .= render_form_extract_numbers();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('extract_numbers', 'extract_numbers_shortcode');

// AJAX handler for extracting numbers from text
function extract_numbers_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }
    
    // Sanitize input text
    $text = sanitize_textarea_field($_POST['inputText']);
    
    // Extract numbers using regex
    preg_match_all('/\d+/', $text, $matches);
    $extractedNumbers = implode("\n", $matches[0]);

    // Send JSON response with extracted numbers
    wp_send_json_success($extractedNumbers);
    wp_die();
}

add_action('wp_ajax_extract_numbers', 'extract_numbers_ajax');
add_action('wp_ajax_nopriv_extract_numbers', 'extract_numbers_ajax');


/**************************************************************************************************/
//F11 Extract Phone Numbers in Text
/**************************************************************************************************/
// Shortcode function to display the Extract Phone Numbers tool on a WordPress page
function extract_phone_numbers_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    
    $output .= render_form_extract_phone_numbers();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('extract_phone_numbers', 'extract_phone_numbers_shortcode');

// AJAX handler for extracting phone numbers
function extract_phone_numbers_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }

    $text = $_POST['inputText'];
    $phone_numbers = extract_phone_numbers_from_text($text);

    wp_send_json_success($phone_numbers);
    wp_die();
}

// Function to extract phone numbers from text
function extract_phone_numbers_from_text($text) {
    preg_match_all('/\b(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b/', $text, $matches);
    $phone_numbers = isset($matches[0]) ? array_unique($matches[0]) : array();
    return $phone_numbers;
}

add_action('wp_ajax_extract_phone_numbers', 'extract_phone_numbers_ajax');
add_action('wp_ajax_nopriv_extract_phone_numbers', 'extract_phone_numbers_ajax');




/**************************************************************************************************/
//F12 Extract Full name from text online
/**************************************************************************************************/
// Shortcode function to display the Extract Full Name tool on a WordPress page
function extract_full_name_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    
    $output .= render_form_extract_full_name();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('extract_full_name', 'extract_full_name_shortcode');

// AJAX handler for extracting full names from text
function extract_full_name_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }

    // Sanitize input text
    $text = sanitize_textarea_field($_POST['inputText']);
    
    // Regex pattern to match names
    $pattern = '/\b((Mr\.|Ms\.|Mrs\.|Dr\.)?\s?[A-Z][a-z]+\s[A-Z][a-z]+)\b/';
    
    preg_match_all($pattern, $text, $matches);
    
    $names = implode("\n", $matches[0]);

    // Send JSON response with extracted names
    wp_send_json_success($names);
    wp_die();
}

add_action('wp_ajax_extract_full_name', 'extract_full_name_ajax');
add_action('wp_ajax_nopriv_extract_full_name', 'extract_full_name_ajax');


/**************************************************************************************************/
//F13 Replacing Words, Spaces in the Text Online
/**************************************************************************************************/
// Shortcode function to display the Replace Words tool on a WordPress page
function replace_words_shortcode() {
    ob_start();
    $atts='';
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_round_box_replace_words();
    $output .= render_form_replace_words();

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('replace_words', 'replace_words_shortcode');

function replace_words_ajax() {
    // Check if all required POST parameters are set
    if (!isset($_POST['inputText']) || !isset($_POST['textTemplate']) || !isset($_POST['replaceText'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }

    $text = stripslashes($_POST['inputText']);
    $textTemplate = stripslashes($_POST['textTemplate']);
    $replaceText = stripslashes($_POST['replaceText']);
    $replacedText = '';

    // Perform the replacement if all fields are not empty
    if (!empty($text) && !empty($textTemplate) && !empty($replaceText)) {
        $replacedText = str_replace($textTemplate, $replaceText, $text);
    } else {
        wp_send_json_error('All fields must be filled');
        wp_die();
    }

    // Send the response back
    wp_send_json_success($replacedText);
    wp_die();
}

add_action('wp_ajax_replace_words', 'replace_words_ajax');
add_action('wp_ajax_nopriv_replace_words', 'replace_words_ajax');


/**************************************************************************************************/
//F14 Convert text to number
/**************************************************************************************************/
// Shortcode function to display the Text to Number tool on a WordPress page
function text_to_number_shortcode() {
    ob_start();
        $atts='';
        // Render each section and concatenate their output
        $output = render_common_form_structure($atts);
        $output .= render_form_text_to_number($atts);
    
        // End output buffering and return combined HTML
        return ob_get_clean() . $output;
}
add_shortcode('text_to_number', 'text_to_number_shortcode');

function text_to_number_ajax() {
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }

    // Sanitize input text
    $text = wp_unslash($_POST['inputText']); // Unslash to handle escaping

    // Mapping of text numbers to their numeric equivalents
    $numbers = array(
        'zero' => 0,
        'one' => 1,
        'two' => 2,
        'three' => 3,
        'four' => 4,
        'five' => 5,
        'six' => 6,
        'seven' => 7,
        'eight' => 8,
        'nine' => 9,
        'ten' => 10,
        'eleven' => 11,
        'twelve' => 12,
        'thirteen' => 13,
        'fourteen' => 14,
        'fifteen' => 15,
        'sixteen' => 16,
        'seventeen' => 17,
        'eighteen' => 18,
        'nineteen' => 19,
        'twenty' => 20,
        'thirty' => 30,
        'forty' => 40,
        'fifty' => 50,
        'sixty' => 60,
        'seventy' => 70,
        'eighty' => 80,
        'ninety' => 90,
        'hundred' => 100,
        'thousand' => 1000,
        'million' => 1000000,
        'billion' => 1000000000,
    );

    // Function to convert text numbers to numeric values
    function text_to_number($text) {
        global $numbers;
        $words = explode(' ', strtolower($text));
        $result = 0;
        $current = 0;

        foreach ($words as $word) {
            if (isset($numbers[$word])) {
                if ($word == 'hundred' && $current != 0) {
                    $current *= $numbers[$word];
                } elseif ($word == 'thousand' || $word == 'million' || $word == 'billion') {
                    $current *= $numbers[$word];
                    $result += $current;
                    $current = 0;
                } else {
                    $current += $numbers[$word];
                }
            } else {
                if ($current != 0) {
                    $result += $current;
                    $current = 0;
                }
                $result = 0;
                break;
            }
        }

        if ($current != 0) {
            $result += $current;
        }

        return $result;
    }

    // Convert text numbers to numeric values
    foreach ($numbers as $word => $num) {
        $text = preg_replace_callback(
            '/\b' . $word . '\b/i',
            function() use ($num) {
                return $num;
            },
            $text
        );
    }

    // Send JSON response with the converted text
    wp_send_json_success($text);
    wp_die();
}

add_action('wp_ajax_text_to_number', 'text_to_number_ajax');
add_action('wp_ajax_nopriv_text_to_number', 'text_to_number_ajax');


/**************************************************************************************************/
//G1 Find Text Length
/**************************************************************************************************/
// Shortcode function to display the Count Characters tool on a WordPress page
function count_characters_shortcode() {
    ob_start();
    count_characters_render_page();
    return ob_get_clean();
}
add_shortcode('count_characters', 'count_characters_shortcode');

// Function to render the Count Characters tool form
function count_characters_render_page() {
    ?>
    <div class="wrap">
        <h1 style="text-align: center;"><?php echo esc_html(get_the_title()); ?></h1>
        <div class="text-area-container" style="margin-top: 20px;">
        <div class="text-area">
                    <label class="textLableBold">Input Text:</label>
                    <textarea id="text" name="inputText" rows="10" cols="80" placeholder="Enter the text"></textarea><br>
                    <label class="upload-button">
                        <input type="file" id="file" name="file">Upload
                        
                    </label></label><button type="button" id="clearBtn">Clear</button>
                </div>
            
        </div>
        <div id="characterCount" style="text-align: center; margin-top: 10px;"></div>
    </div>

    <script>
    jQuery(document).ready(function($) {
    // Function to update character count
    function updateCharacterCount(text) {
        var characterCount = text.length;
        $('#characterCount').html('<h3>Character Count: ' + characterCount + '</h3>');
        
    }

    // Event handler for input changes in textarea
    $('#text').on('input', function() {
        var text = $(this).val();
        if (text.trim() === '') {
            $('#characterCount').html('<h3>Character Count: 0</h3>');
            $('#clearBtn').prop('disabled', true);
        } else {
            updateCharacterCount(text);
        }
    });

    // Event handler for file upload
    $('#file').on('input', function(event) {
        var file = event.target.files[0];
        var reader = new FileReader();
        reader.onload = function(e) {
            var text = e.target.result;
            $('#text').val(text); // Update textarea with file content
            updateCharacterCount(text);
        };
        reader.readAsText(file);
    });
    // Event handler for clear button
    $('#clearBtn').on('click', function() {
            $('#text').val(''); // Clear textarea
            $('#characterCount').empty(); // Remove character count
            $('#clearBtn').prop('disabled', true);
        });
});

    </script>
    <?php
}


/**************************************************************************************************/
//G2 Count Lines count_lines
/**************************************************************************************************/
// Shortcode function to display the Count Lines tool on a WordPress page
function count_lines_shortcode() {
    ob_start();
    count_lines_render_page();
    return ob_get_clean();
}
add_shortcode('count_lines', 'count_lines_shortcode');

// Function to render the Count Lines tool form
function count_lines_render_page() {
    ?>
    <div class="wrap">
    <h1 id="operationMessage" style="text-align: center;"><?php echo esc_html(get_the_title()); ?></h1>
        <div class="text-area-container" style="margin-top: 20px;">
            <div class="text-area">
                    <label class="textLableBold">Input Text:</label>
                    <textarea id="text" name="inputText" rows="10" cols="80" placeholder="Enter the text"></textarea><br>
                    <label class="upload-button">
                        <input type="file" id="file" name="file">Upload
                        
                    </label></label><button type="button" id="clearBtn">Clear</button>
                </div>
        </div>
        <div id="lineCount" style="text-align: center; margin-top: 10px;"></div>
       
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        // Function to update line count
        function updateLineCount(text) {
            var lineCount = text.split(/\r\n|\r|\n/).length;
            $('#lineCount').html('<h3>Line Count: ' + lineCount + '</h3>');
        }

        // Event handler for input changes in textarea
        $('#text').on('input', function() {
            var text = $(this).val();
            if (text.trim() === '') {
                $('#lineCount').html('<h3>Line Count: 0</h3>');
                $('#clearBtn').prop('disabled', true);
            } else {
                updateLineCount(text);
            }
        });

        // Event handler for file upload
        $('#file').on('input', function(event) {
            var file = event.target.files[0];
            var reader = new FileReader();
            reader.onload = function(e) {
                var text = e.target.result;
                $('#text').val(text); // Update textarea with file content
                updateLineCount(text);
            };
            reader.readAsText(file);
        });

        // Event handler for clear button
        $('#clearBtn').on('click', function() {
            $('#text').val(''); // Clear textarea
            $('#lineCount').empty(); // Remove line count
            $('#clearBtn').prop('disabled', true);
        });
    });
    </script>
    <?php
}


/**************************************************************************************************/
//G3 Word Counter count_words
/**************************************************************************************************/
// Shortcode function to display the Word Counter tool on a WordPress page
function count_words_shortcode() {
    ob_start();
    count_words_render_page();
    return ob_get_clean();
}
add_shortcode('count_words', 'count_words_shortcode');

// Function to render the Word Counter tool form
function count_words_render_page() {
    ?>
    <div class="wrap">
    <h1 id="operationMessage" style="text-align: center;"><?php echo esc_html(get_the_title()); ?></h1>
        <div class="text-area">
                <label class="textLableBold">Input Text:</label>
                <textarea id="text" name="inputText" rows="10" cols="80" placeholder="Enter the text"></textarea><br>
                <label class="upload-button">
                    <input type="file" id="file" name="file">Upload
                    
                </label></label><button type="button" id="clearBtn">Clear</button>
            </div>
        <div id="wordCount" style="text-align: center; margin-top: 10px;"></div>
         
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        // Function to update word count
        function updateWordCount(text) {
            var words = text.trim().split(/\s+/);
            var wordCount = words.length;
            $('#wordCount').html('<h3>Word Count: ' + wordCount + '</h3>');
        }

        // Event handler for input changes in textarea
        $('#text').on('input', function() {
            var text = $(this).val();
            if (text.trim() === '') {
                $('#wordCount').html('<h3>Word Count: 0</h3>');
                $('#clearBtn').prop('disabled', true);
            } else {
                updateWordCount(text);
            }
        });

        // Event handler for file upload
        $('#file').on('input', function(event) {
            var file = event.target.files[0];
            var reader = new FileReader();
            reader.onload = function(e) {
                var text = e.target.result;
                $('#text').val(text); // Update textarea with file content
                updateWordCount(text);
            };
            reader.readAsText(file);
        });

        // Event handler for clear button
        $('#clearBtn').on('click', function() {
            $('#text').val(''); // Clear textarea
            $('#wordCount').empty(); // Remove word count
            $('#clearBtn').prop('disabled', true);
        });
    });
    </script>
    <?php
}


/**************************************************************************************************/
//G4 Sentence Counter count_sentences
/**************************************************************************************************/
// Shortcode function to display the Sentence Counter tool on a WordPress page
function count_sentences_shortcode() {
    ob_start();
    count_sentences_render_page();
    return ob_get_clean();
}
add_shortcode('count_sentences', 'count_sentences_shortcode');

// Function to render the Sentence Counter tool form
function count_sentences_render_page() {
    ?>
    <div class="wrap">
    <h1 id="operationMessage" style="text-align: center;"><?php echo esc_html(get_the_title()); ?></h1>
        <div class="text-area">
                <label class="textLableBold">Input Text:</label>
                <textarea id="text" name="inputText" rows="10" cols="80" placeholder="Enter the text"></textarea><br>
                <label class="upload-button">
                    <input type="file" id="file" name="file">Upload
                    
                </label></label><button type="button" id="clearBtn">Clear</button>
            </div>
        <div id="sentenceCount" style="text-align: center; margin-top: 10px;"></div>
        
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        // Function to update sentence count
        function updateSentenceCount(text) {
            var sentences = text.trim().split(/[.!?]+\s*/);
            var sentenceCount = sentences.length - 1; // Exclude empty last element after split
            $('#sentenceCount').html('<h3>Sentence Count: ' + sentenceCount + '</h3>');
        }

        // Event handler for input changes in textarea
        $('#text').on('input', function() {
            var text = $(this).val();
            if (text.trim() === '') {
                $('#sentenceCount').html('<h3>Sentence Count: 0</h3>');
                $('#clearBtn').prop('disabled', true);
            } else {
                updateSentenceCount(text);
            }
        });

        // Event handler for file upload
        $('#file').on('input', function(event) {
            var file = event.target.files[0];
            var reader = new FileReader();
            reader.onload = function(e) {
                var text = e.target.result;
                $('#text').val(text); // Update textarea with file content
                updateSentenceCount(text);
            };
            reader.readAsText(file);
        });

        // Event handler for clear button
        $('#clearBtn').on('click', function() {
            $('#text').val(''); // Clear textarea
            $('#sentenceCount').empty(); // Remove sentence count
            $('#clearBtn').prop('disabled', true);
        });
    });
    </script>
    <?php
}


/**************************************************************************************************/
//G5 Paragraph counter count_paragraphs
/**************************************************************************************************/
// Shortcode function to display the Paragraph Counter tool on a WordPress page
function count_paragraphs_shortcode() {
    ob_start();
    count_paragraphs_render_page();
    return ob_get_clean();
}
add_shortcode('count_paragraphs', 'count_paragraphs_shortcode');

// Function to render the Paragraph Counter tool form
function count_paragraphs_render_page() {
    ?>
    <div class="wrap">
    <h1 id="operationMessage" style="text-align: center;"><?php echo esc_html(get_the_title()); ?></h1>
        <div class="text-area-container" style="margin-top: 20px;">
            <div class="text-area">
                <label class="textLableBold">Input Text:</label>
                <textarea id="text" name="inputText" rows="10" cols="80" placeholder="Enter the text"></textarea><br>
                <label class="upload-button">
                    <input type="file" id="file" name="file">Upload
                    
                </label></label><button type="button" id="clearBtn">Clear</button>
            </div>
            
        </div>
        <div id="paragraphCount" style="text-align: center; margin-top: 10px;"></div>
        
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        // Function to update paragraph count
        function updateParagraphCount(text) {
            var paragraphs = text.trim().split(/\n\s*\n/);
            var paragraphCount = paragraphs.length; // Count of non-empty paragraphs
            $('#paragraphCount').html('<h3>Paragraph Count: ' + paragraphCount + '</h3>');
        }

        // Event handler for input changes in textarea
        $('#text').on('input', function() {
            var text = $(this).val();
            if (text.trim() === '') {
                $('#paragraphCount').html('<h3>Paragraph Count: 0</h3>');
                $('#clearBtn').prop('disabled', true);
            } else {
                updateParagraphCount(text);
            }
        });

        // Event handler for file upload
        $('#file').on('input', function(event) {
            var file = event.target.files[0];
            var reader = new FileReader();
            reader.onload = function(e) {
                var text = e.target.result;
                $('#text').val(text); // Update textarea with file content
                updateParagraphCount(text);
            };
            reader.readAsText(file);
        });

        // Event handler for clear button
        $('#clearBtn').on('click', function() {
            $('#text').val(''); // Clear textarea
            $('#paragraphCount').empty(); // Remove paragraph count
            $('#clearBtn').prop('disabled', true);
        });
    });
    </script>
    <?php
}



/**************************************************************************************************/
//H1 Fill text to the left fill_text_to_left
/**************************************************************************************************/
// Shortcode function to display the Fill Text to the Left tool on a WordPress page
function fill_text_to_left_shortcode($atts) {
    $atts = shortcode_atts(array(
        'length' => 50,  // Default length of text
        'indent_char' => ' '  // Default indent character
    ), $atts);

    ob_start();
    
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_left_align_text($atts);
    $output .= render_form_left_pad_text($atts);

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('fill_text_to_left', 'fill_text_to_left_shortcode');


// AJAX handler for filling text to the left
function fill_text_to_left_ajax() {
    if (!isset($_POST['inputText']) || !isset($_POST['textLength']) || !isset($_POST['indentChar'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }

    // Sanitize input
    $text = sanitize_textarea_field($_POST['inputText']);
    $length = absint($_POST['textLength']);
    $indent_char = sanitize_text_field($_POST['indentChar']);

    // Perform text filling
    $filled_text = fill_text_to_left($text, $length, $indent_char);

    // Send JSON response with filled text
    wp_send_json_success($filled_text);
    wp_die();
}

// Function to fill text to the left
function fill_text_to_left($text, $length, $indent_char) {
    $lines = explode("\n", $text);
    $filled_lines = array_map(function($line) use ($length, $indent_char) {
        $line = trim($line);
        if (strlen($line) < $length) {
            $indent = str_repeat($indent_char, $length - strlen($line));
            return $indent . $line;
        } else {
            return $line;
        }
    }, $lines);

    return implode("\n", $filled_lines);
}

add_action('wp_ajax_fill_text_to_left', 'fill_text_to_left_ajax');
add_action('wp_ajax_nopriv_fill_text_to_left', 'fill_text_to_left_ajax');



/**************************************************************************************************/
//H2 Right align-Text right_align_text
/**************************************************************************************************/
// Shortcode function to display the Right Align Text tool on a WordPress page
function right_align_text_shortcode($atts) {
    $atts = shortcode_atts(array(
        'length' => 50,  // Default length of text
        'indent_char' => ' '  // Default indent character
    ), $atts);

    ob_start();
 
    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_right_align_text($atts);
    $output .= render_form_right_align_text($atts);

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('right_align_text', 'right_align_text_shortcode');

// AJAX handler for right aligning text
function right_align_text_ajax() {
    if (!isset($_POST['inputText']) || !isset($_POST['textLength']) || !isset($_POST['indentChar'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }

    // Sanitize input
    $text = sanitize_textarea_field($_POST['inputText']);
    $length = absint($_POST['textLength']);
    $indent_char = sanitize_text_field($_POST['indentChar']);

    // Perform text right alignment
    $aligned_text = right_align_text($text, $length, $indent_char);

    // Send JSON response with right aligned text
    wp_send_json_success($aligned_text);
    wp_die();
}

// Function to right align text
function right_align_text($text, $length, $indent_char) {
    $lines = explode("\n", $text);
    $aligned_lines = array_map(function($line) use ($length, $indent_char) {
        $line = trim($line);
        if (strlen($line) < $length) {
            $indent = str_repeat($indent_char, $length - strlen($line));
            return $indent . $line;
        } else {
            return $line;
        }
    }, $lines);

    return implode("\n", $aligned_lines);
}

add_action('wp_ajax_right_align_text', 'right_align_text_ajax');
add_action('wp_ajax_nopriv_right_align_text', 'right_align_text_ajax');


/**************************************************************************************************/
//H3 Fill the Text on the Right Side
/**************************************************************************************************/
// Shortcode function to display the Right Indent Text tool on a WordPress page
function right_indent_text_shortcode($atts) {
    $atts = shortcode_atts(array(
        'length' => 50,  // Default length of text
        'indent_char' => ' '  // Default indent character
    ), $atts);

    ob_start();

    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_right_pad_text($atts);
    $output .= render_form_right_pad_text($atts);

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('right_indent_text', 'right_indent_text_shortcode');

// AJAX handler for right indenting text
function right_indent_text_ajax() {
    if (!isset($_POST['inputText']) || !isset($_POST['textLength']) || !isset($_POST['indentChar'])) {
        wp_send_json_error('Missing required parameters');
        wp_die();
    }

    // Sanitize input
    $text = sanitize_textarea_field($_POST['inputText']);
    $length = absint($_POST['textLength']);
    $indent_char = sanitize_text_field($_POST['indentChar']);

    // Perform text right indenting
    $indented_text = right_indent_text($text, $length, $indent_char);

    // Send JSON response with indented text
    wp_send_json_success($indented_text);
    wp_die();
}

// Function to right indent text
function right_indent_text($text, $length, $indent_char) {
    // Check if the text has line breaks
    if (strpos($text, "\n") !== false) {
        // Text has line breaks
        $lines = explode("\n", $text);
        $indented_lines = array_map(function($line) use ($length, $indent_char) {
            $line = trim($line);
            $indent = str_repeat($indent_char, max(0, $length - mb_strlen($line))); // Using mb_strlen for multi-byte characters
            return $line . $indent; // Append indent to the end of the line
        }, $lines);
        
        return implode("\n", $indented_lines);
    } else {
        // Text does not have line breaks
        $text = trim($text);
        $indent = str_repeat($indent_char, max(0, $length)); // Using mb_strlen for multi-byte characters
        return $text . $indent; // Append indent to the whole text
    }
}

add_action('wp_ajax_right_indent_text', 'right_indent_text_ajax');
add_action('wp_ajax_nopriv_right_indent_text', 'right_indent_text_ajax');

/**************************************************************************************************/
//H4 Center Text
/**************************************************************************************************/
// Shortcode function to display the Center Text tool on a WordPress page
function center_text_shortcode($atts) {
    $atts = shortcode_atts(array(
        'text_width' => 'full', // Default to full width
        'indent_char' => ' ' // Default indent character
    ), $atts);

    ob_start();

    // Render each section and concatenate their output
    $output = render_common_form_structure($atts);
    $output .= render_custom_round_box($atts);
    $output .= render_form_center_text($atts);

    // End output buffering and return combined HTML
    return ob_get_clean() . $output;
}
add_shortcode('center_text', 'center_text_shortcode');


// AJAX handler for centering text
function center_text_ajax() {
    // Ensure the request is valid
    if (!isset($_POST['inputText'])) {
        wp_send_json_error('Missing inputText parameter.');
        wp_die();
    }

    // Sanitize input data
    $text = sanitize_textarea_field($_POST['inputText']);
    $textWidth = isset($_POST['textWidth']) ? $_POST['textWidth'] : 'full'; // Default to 'full' if not provided
    $indentChar = isset($_POST['indentChar']) ? sanitize_text_field($_POST['indentChar']) : ' '; // Default to space if not provided
    $extraSpace = isset($_POST['extraSpace']) ? sanitize_text_field($_POST['extraSpace']) : '';

    // Perform text centering logic (replace this with your actual logic)
    $centeredText = center_text_logic($text, $textWidth, $indentChar, $extraSpace);

    // Send JSON response
    wp_send_json_success($centeredText);
    wp_die();
}

// Example function for text centering logic
function center_text_logic($text, $textWidth, $indentChar, $extraSpace) {
    // Example implementation - replace with your own logic
    if ($textWidth === 'full') {
        // Full width logic (adjust as needed)
        $centeredText = str_pad($text, strlen($text) + 2 * strlen($indentChar), $indentChar, STR_PAD_BOTH);
    } else {
        // Specific width logic (adjust as needed)
        $centeredText = str_pad($text, intval($textWidth), $indentChar, STR_PAD_BOTH);
    }

    // Add extra space if selected
    if ($extraSpace === 'right') {
        $centeredText .= ' ';
    } elseif ($extraSpace === 'left') {
        $centeredText = ' ' . $centeredText;
    }

    return $centeredText;
}

add_action('wp_ajax_center_text', 'center_text_ajax');
add_action('wp_ajax_nopriv_center_text', 'center_text_ajax');


/**************************************************************************************************/
//Display Admin Section Page Content
/**************************************************************************************************/

// Add a menu item to the WordPress admin dashboard
function add_shortcodes_menu() {
    add_menu_page(
        'Shortcodes List', // Page title
        'ShufflerText Shortcodes', // Menu title
        'manage_options', // Capability
        'shortcodes-list', // Menu slug
        'display_shortcodes_list', // Callback function
        'dashicons-list-view', // Icon
        6 // Position
    );
}
add_action('admin_menu', 'add_shortcodes_menu');

// Function to display the shortcodes list with status
function display_shortcodes_list() {
    global $wpdb;
    ?>
    <div class="wrap">
        <h1>Available Shortcodes</h1>
        <style>
            .shortcodes-table {
                width: 100%;
                border-collapse: collapse;
                font-family: Arial, sans-serif;
                font-size: 18px;
            }
            .shortcodes-table th, .shortcodes-table td {
                border: 1px solid #ddd;
                padding: 12px;
                text-align: left;
            }
            .shortcodes-table th {
                background-color: #f2f2f2;
                font-weight: bold;
            }
            .shortcodes-table tr:nth-child(even) {
                background-color: #f9f9f9;
            }
            .shortcodes-table tr:hover {
                background-color: #f1f1f1;
            }
            .shortcodes-table th, {
                font-size: 18px;
                font-family: Arial, sans-serif;
            }
			.shortcodes-table td {
				font-size: 14px;
                font-family: Arial, sans-serif;
			}
        </style>
        <table class="shortcodes-table">
            <thead>
                <tr>
                    <th id="serial" class="manage-column column-serial" scope="col">#</th>
                    <th id="shortcode" class="manage-column column-shortcode" scope="col">Shortcode</th>
                    <th id="description" class="manage-column column-description" scope="col">Description</th>
                    <th id="status" class="manage-column column-status" scope="col">Status</th>
                </tr>
            </thead>
            <tbody>
            <?php
// Array of shortcodes and their descriptions
$shortcodes = array(
    '[word_shuffler]' => 'Word Shuffler',
    '[letter_shuffler]' => 'Letter Shuffler',
    '[paragraph_shuffler]' => 'Paragraph Shuffler',
    '[text_generator]' => 'Text Generator',
    '[word_generator]' => 'Word Generator',
    '[letter_generator]' => 'Letter Generator',
    '[name_generator]' => 'Name Generator',
    '[text_splitter]' => 'Text Splitter',
    '[split_text_into_paragraph]' => 'Split Text Into Paragraph',
    '[join_text_into_paragraph]' => 'Join Text Into Paragraph',
    '[trim_text]' => 'Trim Text',
    '[repeat_text]' => 'Repeat Text',
    '[reverse_text]' => 'Reverse Text',
    '[cut_text]' => 'Cut Text',
    '[add_prefix]' => 'Add Prefix',
    '[add_suffix]' => 'Add Suffix',
    '[remove_blank_lines]' => 'Remove Blank Lines',
    '[remove_duplicate_lines]' => 'Remove Duplicate Lines',
    '[replace_space_with_line_break]' => 'Replace Space With Line Break',
    '[replace_newline_with_space]' => 'Replace Newline With Space',
    '[add_line_numbers]' => 'Add Line Numbers',
    '[remove_white_spaces]' => 'Remove White Spaces',
    '[remove_punctuations]' => 'Remove Punctuations',
    '[replace_spaces_with_tab]' => 'Replace Spaces With Tab',
    '[replace_tabs]' => 'Replace Tabs',
    '[invert_text_case]' => 'Invert Text Case',
    '[change_text_case]' => 'Change Text Case',
    '[uppercase_converter]' => 'Uppercase Converter',
    '[random_case_converter]' => 'Random Case Converter',
    '[lowercase_converter]' => 'Lowercase Converter',
    '[filter_text]' => 'Filter Text',
    '[sort_words]' => 'Sort Words',
    '[sort_letters]' => 'Sort Letters',
    '[sort_text_strings]' => 'Sort Text Strings',
    '[sort_list]' => 'Sort List',
    '[extract_text_fragment]' => 'Extract Text Fragment',
    '[sort_words_by_separator]' => 'Sort Words By Separator',
    '[extract_regex_matches]' => 'Extract Regex Matches',
    '[remove_html_tags]' => 'Remove HTML Tags',
    '[extract_text_from_xml]' => 'Extract Text From XML',
    '[extract_bbcode_text]' => 'Extract BBCode Text',
    '[extract_text_from_json]' => 'Extract Text From JSON',
    '[extract_emails]' => 'Extract Emails',
    '[extract_urls]' => 'Extract URLs',
    '[extract_numbers]' => 'Extract Numbers',
    '[extract_phone_numbers]' => 'Extract Phone Numbers',
    '[extract_full_name]' => 'Extract Full Name',
    '[replace_words]' => 'Replace Words',
    '[text_to_number]' => 'Text To Number',
    '[count_characters]' => 'Count Characters',
    '[count_lines]' => 'Count Lines',
    '[count_words]' => 'Count Words',
    '[count_sentences]' => 'Count Sentences',
    '[count_paragraphs]' => 'Count Paragraphs',
    '[fill_text_to_left]' => 'Fill Text To Left',
    '[right_align_text]' => 'Right Align Text',
    '[right_indent_text]' => 'Right Indent Text',
    '[center_text]' => 'Center Text'
    
);

// Sort the shortcodes array by keys (shortcode) in ascending order
ksort($shortcodes);

// Loop through the shortcodes array and display each shortcode, its description, and its status
$serial_number = 1;
foreach ($shortcodes as $shortcode => $description) {
    // Query the database to check if the shortcode is used on any page
    $shortcode_used = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_content LIKE %s AND post_type = 'page' AND post_status = 'publish'",
            '%' . $wpdb->esc_like($shortcode) . '%'
        )
    );

    $status = $shortcode_used > 0 ? 'Used' : 'Not Used';

    echo '<tr>';
    echo '<td>' . esc_html($serial_number) . '</td>';
    echo '<td>' . esc_html($shortcode) . '</td>';
    echo '<td>' . esc_html($description) . '</td>';
    echo '<td>' . esc_html($status) . '</td>';
    echo '</tr>';
    $serial_number++;
}
?>
            </tbody>
        </table>
    </div>
    <?php
}


/**************************************************************************************************/
//Display Front Page Content
/**************************************************************************************************/


//function for the front page display
function shufflertext_front_page_shortcode() {
    ob_start();
    ?>

    <div class="calculator-front-page">
        <h2>Search ShufflerText</h2>
        <!-- Search Bar -->
        <input type="text" id="calculator-search" placeholder="Search">

        <h2>ShufflerText Tools</h2>
        <!-- Calculator Cards -->
        <div class="calculator-cards">
            <?php
            $omit_pages = array(
                'about-us',
                'contact-us',
				'home',
                'privacy-policy',
                'disclaimer',
                'terms-conditions',
				'test-page',
				'blog'
				
                // Add more slugs of pages you want to omit
            );

            $args = array(
                'post_type' => 'page',
                'posts_per_page' => -1, // Get all pages
                'post_status' => 'publish',
                'orderby' => 'title',
                'order' => 'ASC'
            );
            $query = new WP_Query($args);

            if ($query->have_posts()) :
                while ($query->have_posts()) : $query->the_post();
                    $slug = get_post_field('post_name', get_post());
                    if (in_array($slug, $omit_pages)) {
                        continue; // Skip omitted pages
                    }
                    ?>
                    <a href="<?php the_permalink(); ?>" class="calculator-card"  >
                        <h3><?php the_title(); ?></h3>
                        <!-- Additional calculator details can go here -->
                    </a>
                <?php endwhile;
            else :
                echo 'No calculators found.';
            endif;
            wp_reset_postdata();
            ?>
        </div>
    </div>

    <style>
		
		
        .calculator-front-page {
          font-family: 'Courier New', Courier, monospace;
            margin-top: 10vh;
            text-align: center;
        }

        .calculator-front-page h2 {
            margin-top: 20px;
            font-size: 24px;
        }

        #calculator-search {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-family: 'Courier New', Courier, monospace;
        }

        .calculator-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            grid-gap: 20px;
        }

        .calculator-card {
            background-color: #0073aa;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease; /* Added transition for background color */
            text-decoration: none;
            color: #0073aa; /* Default text color */
            display: flex;
            justify-content: center;
            align-items: center;
        }

       .calculator-card:hover {
    color: #0073aa; /* Change text color to blue on hover */
    background-color: #ffffff;
    border-color: #0073aa;
    cursor: pointer;
}

.calculator-card:hover h3 {
    color: #0073aa; /* Change text color to blue on hover */
}



        .calculator-card h3 {
            margin-top: 0;
            font-size: 18px;
            color: #fff;
        }
		
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const searchInput = document.getElementById('calculator-search');
            const calculatorCards = document.querySelectorAll('.calculator-card');

            searchInput.addEventListener('input', function () {
                const searchTerm = this.value.toLowerCase().trim();

                calculatorCards.forEach(card => {
                    const title = card.querySelector('h3').textContent.toLowerCase();
                    if (title.includes(searchTerm)) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    </script>

    <?php
    return ob_get_clean();
}
add_shortcode('shufflertext_front_page', 'shufflertext_front_page_shortcode');



