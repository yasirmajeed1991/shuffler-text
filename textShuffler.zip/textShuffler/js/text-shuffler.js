jQuery(document).ready(function($) {

    // Function to check and highlight empty fields
        function checkAndHighlightEmptyFields(fields) {
            var isValid = true;
            var firstEmptyField = null;

            fields.forEach(function(field) {
                var $element = $(field.selector);
                if ($element.val().trim() === '') {
                    $element.css('border-color', 'red'); // Set border color to red for empty fields
                    if (!firstEmptyField) {
                        firstEmptyField = $element;
                    }
                    isValid = false;
                } else {
                    $element.css('border-color', ''); // Remove border color if not empty
                }
            });

            if (firstEmptyField) {
                firstEmptyField.focus();
            }

            return isValid;
        }
    
        $('.ajax-shuffle').off('click').on('click', function(event) {
            event.preventDefault();
        
            var fields = [
                { selector: '#text' }
            ];
        
            // Validate fields
            if (!checkAndHighlightEmptyFields(fields)) {
                return; // Exit function early if validation fails
            }
        
            var shufflerType = $(this).data('shuffler');
            var text = $('#text').val().trim();
            var file = $('#file').prop('files')[0];
        
            if (!file && text === '') {
                alert('Please enter text or upload a file before shuffling.');
                return;
            }
        
            var formData = new FormData();
            formData.append('action', shufflerType + '_shuffler');
            if (file) {
                formData.append('file', file);
            } else {
                formData.append('text', text);
            }
        
            $.ajax({
                url: textShufflerAjax.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.trim()) { // Ensure response is not empty
                        $('#shuffledText').val(response);
                        $('#downloadBtn, #copyBtn').prop('disabled', false);
                    } else {
                        alert('Empty response received. Please check your input.');
                    }
                },
                error: function(xhr, status, error) {
                    alert('An error occurred while shuffling the text.');
                    console.error('Error:', status, error);
                    console.error(xhr.responseText); // Log detailed error message
                }
            });
        });
        

    // Clear button functionality
    $('#clearBtn').off('click').on('click', function(event) {
        event.preventDefault();
        $('#text').val('');
        $('#shuffledText').val('');
        $('#downloadBtn, #copyBtn').prop('disabled', true);
    });

    // Download button functionality
    $('#downloadBtn').off('click').one('click', function(event) {
        event.preventDefault();
        var textToDownload = $('#shuffledText').val();
        var blob = new Blob([textToDownload], { type: 'text/plain' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'Download_file.txt';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    });

    // Copy button functionality
    $('#copyBtn').off('click').on('click', function(event) {
        event.preventDefault();
        var textToCopy = $('#shuffledText').val();
        navigator.clipboard.writeText(textToCopy)
            .then(function() {
                alert('Text copied to clipboard!');
            })
            .catch(function(error) {
                console.error('Failed to copy text: ', error);
            });
    });

    // Enable/disable download and copy buttons based on text input
    $('#shuffledText').off('input').on('input', function() {
        var shuffledText = $(this).val().trim();
        if (shuffledText !== '') {
            $('#downloadBtn, #copyBtn').prop('disabled', false);
        } else {
            $('#downloadBtn, #copyBtn').prop('disabled', true);
        }
    });

    // Read and display the content of the uploaded file in the input textarea
    $('#file').off('change').on('change', function(event) {
        var file = event.target.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#text').val(e.target.result);
            };
            reader.readAsText(file);
        }
    });

    // Event listener for Generate button
    $('#generate').off('click').on('click', function() {
        var type = $('#typeSelect').val();
        var count = $('#count').val();
        var content_type = $('#contentSelect').val(); // Fetch content type

        // Call AJAX function to generate text based on type, count, and content_type
        generateText(type, count, content_type);
    });
 
 

    // Function to generate text via AJAX
    function generateText(type, count, content_type) {
        var data = {
            action: 'generate_text', // Make sure this matches the PHP action hook
            type: type,
            count: count,
            content_type: content_type // Include content_type in AJAX request
        };

        $.post(textShufflerAjax.ajax_url, data, function(response) {
            $('#shuffledText').val(response); // Display generated text in textarea
            $('#downloadBtn, #copyBtn').prop('disabled', false);
        }).fail(function(xhr, status, error) {
            console.error('AJAX error: ' + status + ' - ' + error);
            alert('An error occurred while generating the text.');
        });
    }

    // Event listener for Generate button in Word Generator section
    $('#generateWords').off('click').on('click', function() {
        var count = $('#wordCount').val();

        // Call AJAX function to generate words based on count
        generateWords(count);
    });

 

    // Function to generate words via AJAX
    function generateWords(count) {
        var data = {
            action: 'generate_words',
            count: count
        };

        $.post(textShufflerAjax.ajax_url, data, function(response) {
            $('#shuffledText').val(response); // Display generated words in textarea
            $('#downloadBtn, #copyBtn').prop('disabled', false);
        }).fail(function(xhr, status, error) {
            console.error('AJAX error: ' + status + ' - ' + error);
            alert('An error occurred while generating the words.');
        });
    }

    // Event listener for Generate button in Letter Generator section
    $('#generateLetters').off('click').on('click', function() {
        var count = $('#letterCount').val();

        // Call AJAX function to generate letters based on count
        generateLetters(count);
    });

    

    // Function to generate letters via AJAX
    function generateLetters(count) {
        var data = {
            action: 'generate_letters',
            count: count
        };

        $.post(letterGeneratorAjax.ajax_url, data, function(response) {
            $('#shuffledText').val(response); // Display generated letters in textarea
            $('#downloadBtn, #copyBtn').prop('disabled', false);
        }).fail(function(xhr, status, error) {
            console.error('AJAX error: ' + status + ' - ' + error);
            alert('An error occurred while generating the letters.');
        });
    }

    // Event listener for Generate button in Name Generator section
    $('#generateNames').off('click').on('click', function() {
        var count = $('#nameCount').val();
        var gender = $('#gender').val();

        // Call AJAX function to generate names based on count and gender
        generateNames(count, gender);
    });

   

    // Function to generate names via AJAX
    function generateNames(count, gender) {
        var data = {
            action: 'generate_names',
            count: count,
            gender: gender
        };

        $.post(nameGeneratorAjax.ajax_url, data, function(response) {
            $('#shuffledText').val(response); // Display generated names in textarea
            $('#downloadBtn, #copyBtn').prop('disabled', false);
        }).fail(function(xhr, status, error) {
            console.error('AJAX error: ' + status + ' - ' + error);
            alert('An error occurred while generating the names.');
        });
    }


    $('.ajax-split').off('click').on('click', function(event) {
        event.preventDefault();
        var fields = [
            { selector: '#text' }
           
        ];
        // Validate fields
        if (!checkAndHighlightEmptyFields(fields)) {
            return; // Exit function early if validation fails
        }
        var symbolType = $('input[name="symbolType"]:checked').val();
        var text = $('#text').val().trim();
        var splitSymbol = $('#splitSymbol').val();
        var useRegex = $('#useRegex').val();
        var chunkLength = $('#chunkLength').val();
        var newLineAfter = $('#newLineRadio').is(':checked');
        var charBetween = $('#charBetween').val();
        // Validate the required input fields based on the selected radio button
        if (symbolType === 'splitSymbol' && !splitSymbol) {
            alert('Please enter the number of paragraphs.');
            return;
        } else if (symbolType === 'useRegex' && !useRegex) {
            alert('Please enter the number of sentences per paragraph.');
            return;
        } else if (symbolType === 'chunkLength' && !chunkLength) {
            alert('Please enter the chunk length.');
            return;
        }
        var formData = {
            action: 'split_text_ajax',
            text: text,
            symbolType: symbolType,
            splitSymbol: splitSymbol,
            useRegex: useRegex,
            chunkLength: chunkLength,
            newLineAfter: newLineAfter,
            charBetween: charBetween
        };

        console.log("Sending formData:", formData);

        $.ajax({
            url: textSplitterAjax.ajax_url,
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    $('#shuffledText').val(response.data);
                    $('#downloadBtn, #copyBtn').prop('disabled', false);
                } else {
                    alert('An error occurred: ' + response.data);
                    console.error(response);
                }
            },
            error: function(xhr, status, error) {
                alert('An error occurred while splitting the text.');
                console.error('Error:', status, error);
                console.error(xhr.responseText);
            }
        });
    });

                // Enable/disable download and copy buttons based on text input in Split Text section
                $('#shuffledText').off('input').on('input', function() {
                        var shuffledText = $(this).val().trim();
                        if (shuffledText !== '') {
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            $('#downloadBtn, #copyBtn').prop('disabled', true);
                        }
                    });



    
                // Event listener for Split Text Into Paragraphs button
                $('.ajax-split-paragraph').off('click').on('click', function(event) {
                    event.preventDefault();
                    var fields = [
                        { selector: '#text' }
                       
                    ];
                    // Validate fields
                    if (!checkAndHighlightEmptyFields(fields)) {
                        return; // Exit function early if validation fails
                    }

                    var symbolType = $('input[name="symbolType"]:checked').val();
                    var text = $('#text').val().trim();
                    var numParagraphs = $('#numParagraphs').val();
                    var paragraphSpacing = $('#paragraphSpacing').val();
                    var removeSpacesLeft = $('#removeSpacesLeft').is(':checked');
                    var removeSpacesRight = $('#removeSpacesRight').is(':checked');
                    var numSentences = $('#numSentences').val();
                    var removePunctuation = $('#removePunctuation').is(':checked');
                    var chunkLength = $('#chunkLength').val();
                    
                    // Validate the required input fields based on the selected radio button
                    if (symbolType === 'numParagraphs' && !numParagraphs) {
                        alert('Please enter the number of paragraphs.');
                        return;
                    } else if (symbolType === 'numSentences' && !numSentences) {
                        alert('Please enter the number of sentences per paragraph.');
                        return;
                    } else if (symbolType === 'chunkLength' && !chunkLength) {
                        alert('Please enter the chunk length.');
                        return;
                    }
                    
                    var formData = {
                        action: 'split_text_into_paragraph',
                        text: text,
                        symbolType: symbolType,
                        numParagraphs: numParagraphs,
                        paragraphSpacing: paragraphSpacing,
                        removeSpacesLeft: removeSpacesLeft,
                        removeSpacesRight: removeSpacesRight,
                        numSentences: numSentences,
                        removePunctuation: removePunctuation,
                        chunkLength: chunkLength
                    };
            
                    console.log("Sending formData:", formData);
            
                    $.ajax({
                        url: splitTextIntoParagraphAjax.ajax_url,
                        type: 'POST',
                        data: formData,
                        success: function(response) {
                            
                            if (response.success) {
                                $('#shuffledText').val(response.data);
                                $('#downloadBtn, #copyBtn').prop('disabled', false);
                            } else {
                                alert('An error occurred: ' + response.data);
                                console.error(response);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('An error occurred while splitting the text into paragraphs.');
                            console.error('Error:', status, error);
                            console.error(xhr.responseText);
                        }
                    });
                });
                
        
        
        





        
        $('.ajax-join-paragraph').off('click').on('click', function(event) {
            event.preventDefault();
            var fields = [
                { selector: '#text' },
                { selector: '#joiner' }
            ];
            // Validate fields
            if (!checkAndHighlightEmptyFields(fields)) {
                return; // Exit function early if validation fails
            }
            var text = $('#text').val().trim();
            var joiner = $('#joiner').val().trim();
        
            var formData = {
                action: 'join_text_into_paragraph',
                words: text.split('\n').map(function(word) {
                    return word.trim();
                }),
                joiner: joiner
            };
        
            $.ajax({
                url: textSplitterAjax.ajax_url,
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        $('#shuffledText').val(response.data);
                        $('#downloadBtn, #copyBtn').prop('disabled', false);
                    } else {
                        alert('An error occurred: ' + response.data);
                    }
                },
                error: function(xhr, status, error) {
                    alert('An error occurred while joining the text into paragraphs.');
                    console.error(xhr, status, error);
                }
            });
        });
        

      
        $('.ajax-trim-text').off('click').on('click', function(event) {
            event.preventDefault();
            var fields = [
                { selector: '#text' }
            ];
            // Validate fields
            if (!checkAndHighlightEmptyFields(fields)) {
                return; // Exit function early if validation fails
            }
            var text = $('#text').val();
            
            var formData = {
                action: 'trim_text',
                text: text
            };
            
            $.ajax({
                url: textSplitterAjax.ajax_url,
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        $('#shuffledText').val(response.data);
                        $('#downloadBtn, #copyBtn').prop('disabled', false);
                    } else {
                        alert('An error occurred: ' + response.data);
                    }
                },
                error: function(xhr, status, error) {
                    alert('An error occurred while trimming the text.');
                    console.error(xhr, status, error);
                }
            });
        });
        
       
            $('.ajax-repeat-text').off('click').on('click', function(event) {
                event.preventDefault();
                var fields = [
                    { selector: '#text' },
                    { selector: '#numRepetitions' }
                    
                    
                ];
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
                var numRepetitions = $('#numRepetitions').val();
                var symbolType = $('input[name="symbolType"]:checked').val();
                var customSymbol = $('#customSymbol').val();
                
                // Set default symbol if custom is selected but no custom symbol is provided
                if (symbolType === 'custom' && customSymbol === '') {
                    customSymbol = ' ';
                }
                
                var formData = {
                    action: 'repeat_text_splitter',
                    inputText: text,
                    numRepetitions: numRepetitions,
                    symbolType: symbolType,
                    customSymbol: customSymbol
                };
                
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while repeating the text.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-reverse-text').off('click').on('click', function(event) {
                event.preventDefault();
                var fields = [
                    { selector: '#text' }
                    
                    
                ];
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
                
                var formData = {
                    action: 'reverse_text_splitter',
                    inputText: text
                };
                
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while reversing the text.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-cut-text').off('click').on('click', function(event) {
                event.preventDefault();
                var fields = [
                    { selector: '#text' },
                    { selector: '#cutLength' },
                    
                ];
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
                var cutLength = $('#cutLength').val();
                var cutType = $('input[name="cutType"]:checked').val();
                
                var formData = {
                    action: 'cut_text_splitter',
                    inputText: text,
                    cutLength: cutLength,
                    cutType: cutType
                };
                
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while cutting the text.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-add-prefix').off('click').on('click', function(event) {
                event.preventDefault();
                
                var fields = [
                    { selector: '#text' },
                    { selector: '#prefix' },
                    
                ];
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
                var prefix = $('#prefix').val();
                var prefixType = $('input[name="prefixType"]:checked').val();
                
                var formData = {
                    action: 'add_prefix_splitter',
                    inputText: text,
                    prefix: prefix,
                    prefixType: prefixType
                };
                
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while adding the prefix.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-add-suffix').off('click').on('click', function(event) {
                event.preventDefault();
                var fields = [
                    { selector: '#text' },
                    { selector: '#suffix' },
                    
                ];
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
                var suffix = $('#suffix').val();
                var suffixType = $('input[name="suffixType"]:checked').val();
                
                var formData = {
                    action: 'add_suffix_splitter',
                    inputText: text,
                    suffix: suffix,
                    suffixType: suffixType
                };
                
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while adding the suffix.');
                        console.error(xhr, status, error);
                    }
                });
            });
            
            $('.ajax-remove-blank-lines').off('click').on('click', function(event) {
                event.preventDefault();
                var fields = [
                    { selector: '#text' },
                    
                ];
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
                
                var formData = {
                    action: 'remove_blank_lines',
                    inputText: text
                };
                
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while removing blank lines.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-remove-duplicate-lines').off('click').on('click', function(event) {
                
                event.preventDefault();
                var fields = [
                    { selector: '#text' },
                    
                ];
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
                
                var formData = {
                    action: 'remove_duplicate_lines',
                    inputText: text
                };
                
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while removing duplicate lines.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-replace-space-with-line-break').off('click').on('click', function(event) {
                 
                event.preventDefault();
                var fields = [
                    { selector: '#text' },
                    
                ];
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
                
                var formData = {
                    action: 'replace_space_with_line_break',
                    inputText: text
                };
                
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while replacing spaces with line breaks.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-replace-newline-with-space').off('click').on('click', function(event) {
                event.preventDefault();
                var fields = [
                    { selector: '#text' },
                    
                ];
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
                
                var formData = {
                    action: 'replace_newline_with_space',
                    inputText: text
                };
                
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while replacing new lines with spaces.');
                        console.error(xhr, status, error);
                    }
                });
            });
            
            $('.ajax-add-line-numbers').off('click').on('click', function(event) {
                event.preventDefault();
                var fields = [
                    { selector: '#text' },
                    
                ];
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
            
                var text = $('#text').val().trim();
                var rowMode = $('input[name="rowMode"]:checked').val();
                var lineNumberFormat = $('input[name="lineNumberFormat"]:checked').val();
                var customNumberingText = $('#customNumberingText').val().trim();
            
                var formData = {
                    action: 'add_line_numbers',
                    inputText: text,
                    rowMode: rowMode,
                    lineNumberFormat: lineNumberFormat,
                    customNumberingText: customNumberingText
                };
            
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while adding line numbers.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-remove-white-spaces').off('click').on('click', function(event) {
                event.preventDefault();
                var fields = [
                    { selector: '#text' },
                    
                ];
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
        
                var formData = {
                    action: 'remove_white_spaces',
                    inputText: text
                };
        
                // Perform AJAX request with formData
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        $('#shuffledText').val(response.data);
                        $('#downloadBtn, #copyBtn').prop('disabled', false);
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while removing white spaces.');
                        console.error(xhr, status, error);
                    }
                });
            });
            
            $('.ajax-remove-punctuations').off('click').on('click', function(event) {
                event.preventDefault();
                var fields = [
                    { selector: '#text' },
                    
                    
                ];
                
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
                
                var formData = {
                    action: 'remove_punctuations',
                    inputText: text
                };
                
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while removing punctuations.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-replace-spaces-with-tab').off('click').on('click', function(event) {
                event.preventDefault();
                var fields = [
                    { selector: '#text' },
                    
                    
                ];
                
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                $('#text').on('keydown', function(event) {
                    if (event.key === 'Tab') {
                        event.preventDefault();
                        var start = this.selectionStart;
                        var end = this.selectionEnd;
            
                        // Insert tab character
                       
                        $(this).val($(this).val().substring(0, start) + "\t" + $(this).val().substring(end));
            
                        // Move the cursor to the right position
                        this.selectionStart = this.selectionEnd = start + 1;
                    }
                });
            
                // AJAX request to replace spaces with tab
               
            
                    var text = $('#text').val().trim();
            
                    var formData = {
                        action: 'replace_spaces_with_tab',
                        inputText: text
                    };
            
                    $.ajax({
                        url: textSplitterAjax.ajax_url,
                        type: 'POST',
                        data: formData,
                        success: function(response) {
                            if (response.success) {
                                $('#shuffledText').val(response.data);
                                $('#downloadBtn, #copyBtn').prop('disabled', false);
                            } else {
                                alert('An error occurred: ' + response.data);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('An error occurred while replacing spaces with tab.');
                            console.error(xhr, status, error);
                        }
                    });
               
            });    

            $('#text').keydown(function(e) {
                if (e.keyCode === 9) { // Tab key code is 9
                    e.preventDefault();
        
                    // Insert four spaces at the current cursor position
                    var cursorPos = this.selectionStart;
                    var text = $(this).val();
                    var spacesToInsert = '    '; // Four spaces
        
                    // Insert spaces at the cursor position
                    var newText = text.substring(0, cursorPos) + spacesToInsert + text.substring(cursorPos);
        
                    // Update textarea value and cursor position
                    $(this).val(newText);
                    this.selectionStart = this.selectionEnd = cursorPos + spacesToInsert.length;
                }
            });
             // Event listener for Replace Tabs with Spaces button
            $('.ajax-replace-tabs').off('click').on('click', function(event) {
                
                event.preventDefault();
                var fields = [
                    { selector: '#text' },
                    { selector: '#spacesPerTab' }
                    
                ];
                
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
                var spacesPerTab = $('#spacesPerTab').val();

                var formData = {
                    action: 'replace_tabs_with_spaces',
                    inputText: text,
                    spacesPerTab: spacesPerTab
                };

                // Perform AJAX request
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while replacing tabs with spaces.');
                        console.error(xhr, status, error);
                    }
                });
            });


            // Event listener for Invert Case button
            $('.ajax-invert-case').off('click').on('click', function(event) {
                event.preventDefault();
                var fields = [
                    { selector: '#text' }
                    
                ];
                
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();

                var formData = {
                    action: 'invert_text_case',
                    inputText: text
                };

                // Perform AJAX request
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while inverting text case.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-change-case').off('click').on('click', function(event) {
                event.preventDefault();
                
                var fields = [
                    { selector: '#text' }
                    
                ];
                
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
                var caseOption = $('input[name="caseOption"]:checked').val();
        
                var formData = {
                    action: 'change_text_case',
                    inputText: text,
                    caseOption: caseOption
                };
        
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while changing the text case.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-uppercase-converter').off('click').on('click', function(event) {
                event.preventDefault();
                var fields = [
                    { selector: '#text' }
                    
                ];
                
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
        
                var formData = {
                    action: 'characters_to_uppercase',
                    inputText: text
                };
        
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while converting text to uppercase.');
                        console.error(xhr, status, error);
                    }
                });
            });
        
            $('.ajax-random-case-converter').off('click').on('click', function(event) {
                event.preventDefault();
                
                var fields = [
                    { selector: '#text' }
                    
                ];
                
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }

                var text = $('#text').val().trim();
        
                var formData = {
                    action: 'random_case_text_converter',
                    inputText: text
                };
        
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while converting text to random case.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-lowercase-converter').off('click').on('click', function(event) {
                event.preventDefault();
                var fields = [
                    { selector: '#text' }
                    
                ];
                
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
        
                var formData = {
                    action: 'lowercase_text_converter',
                    inputText: text
                };
        
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while converting text to lowercase.');
                        console.error(xhr, status, error);
                    }
                });
            });

            // JavaScript for AJAX request to filter text
            $('.ajax-filter-text').off('click').on('click', function(event) {
                event.preventDefault();
                
                var fields = [
                    { selector: '#text' },
                    { selector: '#filterKeyword' }
                ];
                
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                
                var text = $('#text').val().trim();
                var filterKeyword = $('#filterKeyword').val().trim();
                var reverseOrder = $('#reverseOrder').is(':checked') ? 1 : 0;
                
                var formData = {
                    action: 'filter_text',
                    inputText: text,
                    filterKeyword: filterKeyword,
                    reverseOrder: reverseOrder
                };
                
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while filtering text.');
                        console.error(xhr, status, error);
                    }
                });
            });
            

            $('.ajax-sort-words').off('click').on('click', function(event) {
                event.preventDefault();
                
                var fields = [
                    { selector: '#text' }
                    
                ];
                
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
                var sortOrder = $('input[name="sortOrder"]:checked').val();
                
                var formData = {
                    action: 'sort_words',
                    inputText: text,
                    sortOrder: sortOrder
                };
                
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while sorting words.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-sort-letters').off('click').on('click', function(event) {
                event.preventDefault();
                var fields = [
                    { selector: '#text' }
                    
                ];
                
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
                var sortOrder = $('input[name="sortOrder"]:checked').val();
                var separateWords = $('#separateWords').is(':checked') ? 1 : 0;
                var caseSensitive = $('#caseSensitive').is(':checked') ? 1 : 0;
                
                var formData = {
                    action: 'sort_letters',
                    inputText: text,
                    sortOrder: sortOrder,
                    separateWords: separateWords,
                    caseSensitive: caseSensitive
                };
                
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while sorting letters.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-sort-text-strings').off('click').on('click', function(event) {
                event.preventDefault();
                
                var fields = [
                    { selector: '#text' }
                    
                ];
                
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
                var sortOrder = $('input[name="sortOrder"]:checked').val();
                
                
                var formData = {
                    action: 'sort_text_strings',
                    inputText: text,
                    sortOrder: sortOrder
                    
                };
                
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while sorting text.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-sort-list').off('click').on('click', function(event) {
                event.preventDefault();
                var fields = [
                    { selector: '#text' }
                    
                ];
                
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
                var reverseOrder = $('#reverseOrder').is(':checked');
                var numericSort = $('#numericSort').is(':checked');
                var formData = {
                    action: 'sort_list',
                    inputText: text,
                    reverseOrder: reverseOrder.toString(),
                    numericSort: numericSort.toString()
                };
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    beforeSend: function() {
                        // Optionally, show a loading spinner or disable buttons
                        $('#downloadBtn, #copyBtn').prop('disabled', true);
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while sorting the list.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-extract-text-fragment').off('click').on('click', function(event) {
                event.preventDefault();
                
                var fields = [
                    { selector: '#text' },
                    { selector: '#startPos' },
                    { selector: '#fragmentLength' }
                ];
                
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }

                var text = $('#text').val().trim();
                var startPos = $('#startPos').val();
                var fragmentLength = $('#fragmentLength').val();
                var multiLineMode = $('#multiLineMode').is(':checked');
        
                var formData = {
                    action: 'extract_text_fragment',
                    inputText: text,
                    startPos: startPos,
                    fragmentLength: fragmentLength,
                    multiLineMode: multiLineMode.toString()
                };
        
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    beforeSend: function() {
                        // Optionally, show a loading spinner or disable buttons
                        $('#downloadBtn, #copyBtn').prop('disabled', true);
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while extracting text fragment.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-sort-words-by-separator').off('click').on('click', function(event) {
                event.preventDefault();
            
                var fields = [
                    { selector: '#text' },
                    { selector: 'input[name="separator"]:checked' }
                ];
                
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
            
                var text = $('#text').val().trim();
                var separator = $('input[name="separator"]:checked').val();
                var customSeparator = $('#customSeparator').val().trim();
                var sortingOption = $('input[name="sortingOption"]:checked').val();
                var removeDuplicates = $('#removeDuplicates').is(':checked');
                var removeSpaces = $('#removeSpaces').is(':checked');
                
                var formData = {
                    action: 'sort_words_by_separator',
                    inputText: text,
                    separator: separator,
                    customSeparator: customSeparator,
                    sortingOption: sortingOption,
                    removeDuplicates: removeDuplicates ? 'true' : 'false',
                    removeSpaces: removeSpaces ? 'true' : 'false'
                };
                
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    beforeSend: function() {
                        $('#downloadBtn, #copyBtn').prop('disabled', true);
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while sorting the words.');
                        console.error(xhr, status, error);
                    }
                });
            });
            
            
            // Function to enable/disable custom separator field based on radio button selection
            $('input[name="separator"]').on('change', function() {
                if ($(this).val() === 'custom') {
                    $('#customSeparator').prop('disabled', false);
                } else {
                    $('#customSeparator').prop('disabled', true);
                }
            });
            
            // Initial state of custom separator field
            $('#customSeparator').prop('disabled', true);
            
            
            
            $('.ajax-extract-regex-matches').off('click').on('click', function(event) {
                event.preventDefault();
                var fields = [
                    { selector: '#text' },
                    { selector: '#regex' },
                    { selector: '#separator' }
                    
                ];
            
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                
                var text = $('#text').val().trim();
                var regex = $('#regex').val().trim();
                var separator = $('#separator').val().trim();

                 

                var formData = {
                    action: 'extract_regex_matches',
                    inputText: text,
                    regex: regex,
                    separator: separator
                };

                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    beforeSend: function() {
                        $('#downloadBtn, #copyBtn').prop('disabled', true);
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('Error: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while extracting regex matches.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-remove-html-tags').off('click').on('click', function(event) {
                event.preventDefault();
                
                var fields = [
                    { selector: '#text' },
                    
                ];
            
                // Validate fields
                if (!checkAndHighlightEmptyFields(fields)) {
                    return; // Exit function early if validation fails
                }
                var text = $('#text').val().trim();
                
                var formData = {
                    action: 'remove_html_tags',
                    inputText: text
                };
                
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while removing HTML tags.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-extract-xml-text').off('click').on('click', function(event) {
                event.preventDefault();
                    var fields = [
                        { selector: '#text' },
                        
                    ];
                
                    // Validate fields
                    if (!checkAndHighlightEmptyFields(fields)) {
                        return; // Exit function early if validation fails
                    }
                
                var xmlText = $('#text').val().trim();
                var formData = new FormData();
                
                if (xmlText) {
                    formData.append('xmlText', xmlText);
                } else {
                    formData.append('xmlFile', $('#file')[0].files[0]);
                }
                
                formData.append('action', 'extract_xml_text');
                
                $.ajax({
                    url: textSplitterAjax.ajax_url,
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        if (response.success) {
                            $('#shuffledText').val(response.data);
                            $('#downloadBtn, #copyBtn').prop('disabled', false);
                        } else {
                            alert('An error occurred: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while extracting text from XML.');
                        console.error(xhr, status, error);
                    }
                });
            });

            $('.ajax-extract-bbcode-text').off('click').on('click', function(event) {
               
                    event.preventDefault();
                    var fields = [
                        { selector: '#text' },
                        
                    ];
                
                    // Validate fields
                    if (!checkAndHighlightEmptyFields(fields)) {
                        return; // Exit function early if validation fails
                    }
                    var bbcode = $('#text').val().trim();
                    
                    var formData = {
                        action: 'extract_bbcode_text',
                        inputBBCode: bbcode
                    };
                    
                    $.ajax({
                        url: textSplitterAjax.ajax_url,
                        type: 'POST',
                        data: formData,
                        success: function(response) {
                            if (response.success) {
                                $('#shuffledText').val(response.data);
                                $('#downloadBtn, #copyBtn').prop('disabled', false);
                            } else {
                                alert('An error occurred: ' + response.data);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('An error occurred while extracting BBCode text.');
                            console.error(xhr, status, error);
                        }
                    });
                });

                $('.ajax-extract-text-from-json').off('click').on('click', function(event) {
                    event.preventDefault();
                    var fields = [
                        { selector: '#text' },
                        
                    ];
                
                    // Validate fields
                    if (!checkAndHighlightEmptyFields(fields)) {
                        return; // Exit function early if validation fails
                    }
                    
                    var jsonText = $('#text').val().trim();
                    
                    var formData = {
                        action: 'extract_text_from_json',
                        jsonText: jsonText
                    };
                    
                    $.ajax({
                        url: textSplitterAjax.ajax_url,
                        type: 'POST',
                        data: formData,
                        success: function(response) {
                            if (response.success) {
                                $('#shuffledText').val(response.data);
                                $('#downloadBtn, #copyBtn').prop('disabled', false);
                            } else {
                                alert('An error occurred: ' + response.data);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('An error occurred while extracting text from JSON.');
                            console.error(xhr, status, error);
                        }
                    });
                });

                $('.ajax-extract-emails').off('click').on('click', function(event) {
                    event.preventDefault();
                    var fields = [
                        { selector: '#text' },
                        
                    ];
                
                    // Validate fields
                    if (!checkAndHighlightEmptyFields(fields)) {
                        return; // Exit function early if validation fails
                    }
                    var text = $('#text').val().trim();
                    
                    var formData = {
                        action: 'extract_emails',
                        inputText: text
                    };
                    
                    $.ajax({
                        url: textSplitterAjax.ajax_url,
                        type: 'POST',
                        data: formData,
                        success: function(response) {
                            if (response.success) {
                                $('#shuffledText').val(response.data);
                                $('#downloadBtn, #copyBtn').prop('disabled', false);
                            } else {
                                alert('An error occurred: ' + response.data);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('An error occurred while extracting emails.');
                            console.error(xhr, status, error);
                        }
                    });
                });

                $('.ajax-extract-urls').off('click').on('click', function(event) {
                    event.preventDefault();
                    var fields = [
                        { selector: '#text' },
                        
                    ];
                
                    // Validate fields
                    if (!checkAndHighlightEmptyFields(fields)) {
                        return; // Exit function early if validation fails
                    }
                    var text = $('#text').val().trim();
                    
                    var formData = {
                        action: 'extract_urls',
                        inputText: text
                    };
                    
                    $.ajax({
                        url: textSplitterAjax.ajax_url,
                        type: 'POST',
                        data: formData,
                        success: function(response) {
                            if (response.success) {
                                $('#shuffledText').val(response.data);
                                $('#downloadBtn, #copyBtn').prop('disabled', false);
                            } else {
                                alert('An error occurred: ' + response.data);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('An error occurred while extracting URLs.');
                            console.error(xhr, status, error);
                        }
                    });
                });

                $('.ajax-extract-numbers').off('click').on('click', function(event) {
                    event.preventDefault();
                    var fields = [
                        { selector: '#text' },
                        
                    ];
                
                    // Validate fields
                    if (!checkAndHighlightEmptyFields(fields)) {
                        return; // Exit function early if validation fails
                    }
                    var text = $('#text').val().trim();
                    
                    var formData = {
                        action: 'extract_numbers',
                        inputText: text
                    };
                    
                    $.ajax({
                        url: textSplitterAjax.ajax_url,
                        type: 'POST',
                        data: formData,
                        success: function(response) {
                            if (response.success) {
                                $('#shuffledText').val(response.data);
                                $('#downloadBtn, #copyBtn').prop('disabled', false);
                            } else {
                                alert('An error occurred: ' + response.data);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('An error occurred while extracting numbers.');
                            console.error(xhr, status, error);
                        }
                    });
                });

                $('.ajax-extract-phone-numbers').off('click').on('click', function(event) {
                    event.preventDefault();

                    var fields = [
                        { selector: '#text' },
                        
                    ];
                
                    // Validate fields
                    if (!checkAndHighlightEmptyFields(fields)) {
                        return; // Exit function early if validation fails
                    }
                    var text = $('#text').val().trim();
            
                    var formData = {
                        action: 'extract_phone_numbers',
                        inputText: text
                    };
            
                    $.ajax({
                        url: textSplitterAjax.ajax_url,
                        type: 'POST',
                        data: formData,
                        success: function(response) {
                            if (response.success) {
                                $('#shuffledText').val(response.data.join('\n'));
                                $('#downloadBtn, #copyBtn').prop('disabled', false);
                            } else {
                                alert('An error occurred: ' + response.data);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('An error occurred while extracting phone numbers.');
                            console.error(xhr, status, error);
                        }
                    });
                });

                $('.ajax-extract-full-name').off('click').on('click', function(event) {
                    event.preventDefault();
                    
                    var fields = [
                        { selector: '#text' },
                        
                    ];
                
                    // Validate fields
                    if (!checkAndHighlightEmptyFields(fields)) {
                        return; // Exit function early if validation fails
                    }
                    var text = $('#text').val().trim();
                    
                    var formData = {
                        action: 'extract_full_name',
                        inputText: text
                    };
                    
                    $.ajax({
                        url: textSplitterAjax.ajax_url,
                        type: 'POST',
                        data: formData,
                        success: function(response) {
                            if (response.success) {
                                $('#shuffledText').val(response.data);
                                $('#downloadBtn, #copyBtn').prop('disabled', false);
                            } else {
                                alert('An error occurred: ' + response.data);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('An error occurred while extracting full names.');
                            console.error(xhr, status, error);
                        }
                    });
                });

                
                $('.ajax-replace-words').off('click').on('click', function(event) {
                    event.preventDefault();
                
                    var fields = [
                        { selector: '#text' },
                        { selector: '#textTemplate' },
                        { selector: '#replaceText' }
                    ];
                
                    // Validate fields
                    if (!checkAndHighlightEmptyFields(fields)) {
                        return; // Exit function early if validation fails
                    }
                
                    // If validation passes, proceed with AJAX request
                    var text = $('#text').val().trim();
                    var textTemplate = $('#textTemplate').val().trim();
                    var replaceText = $('#replaceText').val().trim();
                
                    var formData = {
                        action: 'replace_words',
                        inputText: text,
                        textTemplate: textTemplate,
                        replaceText: replaceText
                    };
                
                    $.ajax({
                        url: textSplitterAjax.ajax_url,
                        type: 'POST',
                        data: formData,
                        success: function(response) {
                            if (response.success) {
                                $('#shuffledText').val(response.data);
                                $('#downloadBtn, #copyBtn').prop('disabled', false);
                            } else {
                                alert('An error occurred: ' + response.data);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('An error occurred while replacing words.');
                            console.error(xhr, status, error);
                        }
                    });
                });


                $('.ajax-text-to-number').off('click').on('click', function(event) {
                    event.preventDefault();

                    var fields = [
                        { selector: '#text' },
                        
                        
                    ];
                
                    // Validate fields
                    if (!checkAndHighlightEmptyFields(fields)) {
                        return; // Exit function early if validation fails
                    }
                    
                    var text = $('#text').val().trim();
                    
                    var formData = {
                        action: 'text_to_number',
                        inputText: text
                    };
                    
                    $.ajax({
                        url: textSplitterAjax.ajax_url,
                        type: 'POST',
                        data: formData,
                        success: function(response) {
                            if (response.success) {
                                $('#shuffledText').val(response.data);
                                $('#downloadBtn, #copyBtn').prop('disabled', false);
                            } else {
                                alert('An error occurred: ' + response.data);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('An error occurred while converting text to number.');
                            console.error(xhr, status, error);
                        }
                    });
                });

                $('.ajax-left-pad-text').off('click').on('click', function(event) {
                    event.preventDefault();
                    var fields = [
                        { selector: '#text' },
                        { selector: '#indentChar' },
                        { selector: '#textLength' }
                        
                    ];
                
                    // Validate fields
                    if (!checkAndHighlightEmptyFields(fields)) {
                        return; // Exit function early if validation fails
                    }
                    var text = $('#text').val().trim();
                    var textLength = $('#textLength').val();
                    var indentChar = $('#indentChar').val();
                    
                    var formData = {
                        action: 'fill_text_to_left',
                        inputText: text,
                        textLength: textLength,
                        indentChar: indentChar
                    };
                    
                    $.ajax({
                        url: textSplitterAjax.ajax_url,
                        type: 'POST',
                        data: formData,
                        success: function(response) {
                            if (response.success) {
                                $('#shuffledText').val(response.data);
                                $('#downloadBtn, #copyBtn').prop('disabled', false);
                            } else {
                                alert('An error occurred: ' + response.data);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('An error occurred while filling text to the left.');
                            console.error(xhr, status, error);
                        }
                    });
                });
 
                $('.ajax-right-align-text').off('click').on('click', function(event) {
                    event.preventDefault();

                    var fields = [
                        { selector: '#text' },
                        { selector: '#indentChar' },
                        { selector: '#textLength' }
                        
                    ];
                
                    // Validate fields
                    if (!checkAndHighlightEmptyFields(fields)) {
                        return; // Exit function early if validation fails
                    }
                    
                    var text = $('#text').val().trim();
                    var textLength = $('#textLength').val();
                    var indentChar = $('#indentChar').val();
                    
                    var formData = {
                        action: 'right_align_text',
                        inputText: text,
                        textLength: textLength,
                        indentChar: indentChar
                    };
                    
                    $.ajax({
                        url: textSplitterAjax.ajax_url,
                        type: 'POST',
                        data: formData,
                        success: function(response) {
                            if (response.success) {
                                $('#shuffledText').val(response.data);
                                $('#downloadBtn, #copyBtn').prop('disabled', false);
                            } else {
                                alert('An error occurred: ' + response.data);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('An error occurred while right aligning text.');
                            console.error(xhr, status, error);
                        }
                    });
                });

                $('.ajax-right-pad-text').off('click').on('click', function(event) {
                    event.preventDefault();
                    var fields = [
                        { selector: '#text' },
                        { selector: '#indentChar' },
                        { selector: '#textLength' }
                        
                    ];
                
                    // Validate fields
                    if (!checkAndHighlightEmptyFields(fields)) {
                        return; // Exit function early if validation fails
                    }
                    var text = $('#text').val().trim();
                    var textLength = $('#textLength').val();
                    var indentChar = $('#indentChar').val();
                    var formData = {
                        action: 'right_indent_text',
                        inputText: text,
                        textLength: textLength,
                        indentChar: indentChar
                    };
                    
                    $.ajax({
                        url: textSplitterAjax.ajax_url,
                        type: 'POST',
                        data: formData,
                        success: function(response) {
                            if (response.success) {
                                $('#shuffledText').val(response.data);
                                $('#downloadBtn, #copyBtn').prop('disabled', false);
                            } else {
                                alert('An error occurred: ' + response.data);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('An error occurred while right indenting text.');
                            console.error(xhr, status, error);
                        }
                    });
                });

                //Center ajax
                $('.ajax-center-text').off('click').on('click', function(event) {
                    event.preventDefault();
                    
                    var fields = [
                        { selector: '#text' },
                        { selector: '#indentChar' }
                        
                    ];
                
                    // Validate fields
                    if (!checkAndHighlightEmptyFields(fields)) {
                        return; // Exit function early if validation fails
                    }
                    var text = $('#text').val().trim();
                    var textWidth = $('#textWidth').val();
                    var indentChar = $('#indentChar').val();
                    var extraSpace = $('input[name=extraSpace]:checked').val();
                    
                    var formData = {
                        action: 'center_text',
                        inputText: text,
                        textWidth: textWidth,
                        indentChar: indentChar,
                        extraSpace: extraSpace
                    };
                    $.ajax({
                        url: textSplitterAjax.ajax_url,
                        type: 'POST',
                        data: formData,
                        success: function(response) {
                            if (response.success) {
                                $('#shuffledText').val(response.data);
                                $('#downloadBtn, #copyBtn').prop('disabled', false);
                            } else {
                                alert('An error occurred: ' + response.data);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('An error occurred while centering text.');
                            console.error(xhr, status, error);
                        }
                    });
                });
                
                




});
