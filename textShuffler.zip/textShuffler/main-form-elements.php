<?php
// common-form-parts.php

// Function to render common form structure
function render_common_form_structure($atts) {
    ob_start(); // Start output buffering to capture HTML
    ?>
    <div class="wrap">
        <h1 id="operationMessage" style="text-align: center;"><?php echo esc_html(get_the_title()); ?></h1>
       
        <form id="shufflerTextForm" method="post" enctype="multipart/form-data">
            <div class="text-area-container" style="margin-top: 60px;">
                <div class="text-area">
                          <label class="textLableBold">Input Text:</label>
                    <textarea id="text" name="inputText" rows="10" cols="40" placeholder="Enter the text"></textarea><br>
                  
                    <label class="upload-button">
                    <input type="file" id="file" name="file">Upload
                    
                </label><button type="button" id="clearBtn">Clear</button>
                    
                </div>
                <div class="text-area">
                    <label class="textLableBold">Result:</label>
                    <textarea id="shuffledText" rows="10" cols="40"></textarea><br>
                    <button type="button" id="downloadBtn" disabled>Download</button>
                    <button type="button" id="copyBtn" disabled>Copy</button>
                    
                </div>
            </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}

