<?php






/**************************************************************************************************/
//H1 Fill text to the left
/**************************************************************************************************/
// Function to render custom round box (may vary with different shortcodes)
function render_custom_left_align_text($atts) {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                       
                        <!-- Your specified code here -->
                        <label class="textLableBold">Length of all text:</label>
                        <input type="number" id="textLength" name="textLength" value="50"  class="custom-input"><br><br>

                        
                    </div>
                    <div class="custom-column">
                        <label class="textLableBold">Indent Character:</label>
                        <input type="text" id="indentChar" name="indentChar" value="@" maxlength="1" class="custom-input"><br><br>
                        </div>

                    <div class="custom-column">
                        <!-- Column 3 content -->
                    </div>

                </div>
            </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}
/**************************************************************************************************/
//H2 Right align-Text
/**************************************************************************************************/
// Function to render custom round box (may vary with different shortcodes)
function render_custom_right_align_text($atts) {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                       
                        <!-- Your specified code here -->
                        <label class="textLableBold">Length of all text:</label>
                        <input type="number" id="textLength" name="textLength" value="50"  class="custom-input"><br><br>

                        
                    </div>
                    <div class="custom-column">
                        <label class="textLableBold">Indent Character:</label>
                        <input type="text" id="indentChar" name="indentChar" value="@" maxlength="1" class="custom-input"><br><br>
                        </div>

                    <div class="custom-column">
                        <!-- Column 3 content -->
                    </div>

                </div>
            </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}
/**************************************************************************************************/
//H3 Fill the Text on the Right Side
/**************************************************************************************************/
// Function to render custom round box (may vary with different shortcodes)
function render_custom_right_pad_text($atts) {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                       
                        <!-- Your specified code here -->
                        <label class="textLableBold">Length of all text:</label>
                        <input type="number" id="textLength" name="textLength" value="50"  class="custom-input"><br><br>

                        
                    </div>
                    <div class="custom-column">
                        <label class="textLableBold">Indent Character:</label>
                        <input type="text" id="indentChar" name="indentChar" value="@" maxlength="1" class="custom-input"><br><br>
                        </div>

                    <div class="custom-column">
                        <!-- Column 3 content -->
                    </div>

                </div>
            </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}
/********************************************************************************************/ 
//H4 Center Text COMPILED
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box($atts) {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                        <!-- Your specified code here -->
                        <label class="textLableBold">Uniform Alignment</label>
                        <label class="custom-label">
                            <input type="radio" name="extraSpace" value="left" checked>
                            Add extra space to the left
                        </label>
                        <label class="custom-label">
                            <input type="radio" name="extraSpace" value="right">
                            Add extra space to the right
                        </label>
                    </div>
                    <div class="custom-column">
                        <label class="textLableBold">Indent Character:</label>
                        <input type="text" id="indentChar" name="indentChar" value="<?php echo isset($indent_char) ? esc_attr($indent_char) : '@'; ?>" maxlength="1" class="custom-input"><br><br>
                    </div>
                    <div class="custom-column">
                        <!-- Column 3 content -->
                    </div>
                </div>
            </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}

/********************************************************************************************/ 
//F13 Replacing Words, Spaces in the Text Online
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_replace_words() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                    <label class="textLableBold">Text Template 
                    </label>
                    <input type="text" id="textTemplate" name="textTemplate" class="custom-input">
                    <p><span class="min-font-style">Enter Text to Replace</span></p>
                    </div>
                    <div class="custom-column">
                        <label class="textLableBold">Replace  to text </label>
                        <input type="text" id="replaceText" name="replaceText" class="custom-input">
                        <p><span class="min-font-style">Enter text to replace with</span></p>
                          </div>
                    <div class="custom-column">
                        <!-- Column 3 content -->
                    </div>
                </div>
            </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}

/********************************************************************************************/ 
//F3 Extract regex matches from text
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_regex_matches() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                    <label class="textLableBold">Regular Expression
                    </label>
                    <input type="text" id="regex" name="regex" placeholder="Enter regular expression" value="[a-zA-Z0-9]+" class="custom-input">
                   
                    </div>
                    <div class="custom-column">
                        <label class="textLableBold">Separation Symbol
                        </label>
                        <input type="text" id="separator" name="separator" placeholder="Enter separator character" value="," class="custom-input">
               
                          </div>
                    <div class="custom-column">
                        <!-- Column 3 content -->
                    </div>
                </div>
            </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}

/********************************************************************************************/ 
//F2 sort-with-delimiter Sort words with seprator
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_sort_words_by_separator() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                    <label class="textLableBold">Separator
                    </label>

                        <label><input type="radio" name="separator" value="space" checked> Space</label>
                        <label><input type="radio" name="separator" value="custom"> Custom Character: </label>
                        <input type="text" id="customSeparator" name="customSeparator" class="custom-input">
                   
                    </div>
                    <div class="custom-column">
                        <label class="textLableBold">Sorting Options
                        </label>
                        <div class="radio-options">
                            <label class="custom-radio"><input type="radio"  name="sortingOption" value="alphabet" checked> In Alphabetical Order</label> 
                            <label class="custom-radio"><input type="radio"  name="sortingOption" value="reverse"> In Reverse Order</label> 
                            <label class="custom-radio"><input type="radio"  name="sortingOption" value="length_desc"> By Length (Highest to Lowest)</label> 
                            <label class="custom-radio"><input type="radio"  name="sortingOption" value="length_asc"> By Length (Smallest to Largest)</label>
                        </div>      
                    
                    </div>
                    <div class="custom-column">
                    <label class="textLableBold">Clean
                    </label>
                    <div class="radio-options">
                        <label><input type="checkbox" id="removeDuplicates" name="removeDuplicates"> Remove All Duplicate Words</label> 
                        <label><input type="checkbox" id="removeSpaces" name="removeSpaces"> Remove Spaces from Left to Right</label>
                    </div>
                    </div>
                </div>
            </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}



/********************************************************************************************/ 
//F1 Extract Text 
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_extract_text_fragment() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                    <label class="textLableBold">Starting Position
                    </label>
                    <input type="number" id="startPos" name="startPos" value="0" min="0" class="custom-input">


                   
                    </div>
                    <div class="custom-column">
                        <label class="textLableBold">Fragment Length
                        </label>
                        <input type="number" id="fragmentLength" name="fragmentLength" value="10" min="1" class="custom-input">
                    </div>
                    <div class="custom-column">
                    <label class="textLableBold">Multi-line mode
                    </label>
                    <div class="radio-options">
                        <label><input type="checkbox" id="multiLineMode" name="multiLineMode">
                       Apply to every line</label>
                    </div>
                    </div>
                </div>
            </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}




/********************************************************************************************/ 
//E5 Sort List Online
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_sort_list() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                    <label class="textLableBold">Sorting settings
                    </label>
                    <div class="radio-options">
                        <label><input type="checkbox" id="reverseOrder" name="reverseOrder">
                        In Reverse Order</label>
                        <label><input type="checkbox" id="numericSort" name="numericSort">
                        By Numerical Value</label>
                    </div>
                   
                    </div>
                    <div class="custom-column">
                       
                    </div>
                    <div class="custom-column">
                    
                    </div>
                </div>
            </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}

/********************************************************************************************/ 
//E4 Sort Text Strings Online
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_text_string() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                        <label class="textLableBold">Sorting Options
                        </label>
                    <div class="radio-options">
                       
                        <label class="custom-radio">
                            <input type="radio" id="alphabetical" name="sortOrder" value="alphabetical" checked>
                            Alphabetical Order (A to Z)
                        </label>
                        <label class="custom-radio">
                            <input type="radio" id="reverseAlphabetical" name="sortOrder" value="reverseAlphabetical">
                            Reverse Alphabetical Order (Z to A)
                        </label>
                        <label class="custom-radio">
                            <input type="radio" id="lengthHighToLow" name="sortOrder" value="lengthHighToLow">
                            Values by Length (Highest to Lowest)
                        </label>
                        <label class="custom-radio">
                            <input type="radio" id="lengthLowToHigh" name="sortOrder" value="lengthLowToHigh">
                            Values by Length (Smallest to Largest)
                        </label>
                        <label class="custom-radio">
                            <input type="radio" id="randomOrder" name="sortOrder" value="randomOrder">
                            Randomize Strings
                        </label>
                    </div>
                   
                </div>
                    
                    <div class="custom-column">
                    
                    </div>
                </div>
            </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}


/********************************************************************************************/ 
//E3 Sort Letters in Text
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_letter_string() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                        <label class="textLableBold">Sorting Types
                        </label>
                        <div class="radio-options">
                        
                            <label class="custom-radio">
                            <input type="radio" id="sortOrderAZ" name="sortOrder" value="az" checked>
                            Letters in alphabetical order (FROM A TO Z)
                            </label>
                            <label class="custom-radio">
                            <input type="radio" id="sortOrderZA" name="sortOrder" value="za">
                            Letters in reverse alphabetical order (FROM Z TO A)
                            </label>
                            <label class="custom-radio">
                            <input type="radio" id="sortOrderRandom" name="sortOrder" value="random">
                            Letters in random order
                            </label>
                            
                        </div>
                    </div>
                    
                    <div class="custom-column">
                            <label class="textLableBold">Customize sorting letters
                            </label>
                        
                            <label><input  type="checkbox" id="separateWords" name="separateWords"> Separate each word</label>
                            <label><input type="checkbox" id="caseSensitive" name="caseSensitive"> Case sensitive</label>
                       
                    </div>
                </div>
            </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}



/********************************************************************************************/ 
//E2 Sort Words in Alphabetical order
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_words_string() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                    <label class="textLableBold">Sorting settings
                    </label>
                    <div class="radio-options">
                        <label><input type="radio" id="sortOrderAZ" name="sortOrder" value="az" checked>
                        Words in alphabetical order (FROM A TO Z)</label>
                        <label><input type="radio" id="sortOrderZA" name="sortOrder" value="za">
                        Words in reverse alphabetical order (FROM Z TO A)</label>
                    </div>
                   
                    </div>
                    
                    <div class="custom-column">
                    
                    </div>
                </div>
            </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}


/********************************************************************************************/ 
//E1 Text Sorting, Online Text Filter
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_filter_text() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
    <label class="textLableBold">Types of Modes
    </label>
                <div class="custom-row">
                
                    <div class="custom-column">
                    
                       
                        <div class="radio-options">
                        
                            <label >
                            <input type="radio" id="lowercase" name="caseOption" value="lowercase" checked>
                                   Lowercase <br> (all characters to small case)
                            </label>
                            <label >
                            <input type="radio" id="uppercase" name="caseOption" value="uppercase">
                                     UPPERCASE  <br>(ALL CHARACTERS IN UPPERCASE)
                            </label>
                            <label >
                            <input type="radio" id="randomRegister" name="caseOption" value="randomRegister">
                                 Random Register <br>(Randomly selects for each letter)
                            </label>
                            <label >
                            <input type="radio" id="headerRegister" name="caseOption" value="headerRegister">
                                    Header Register <br>(First letter of each word capitalized)
                            </label>
                            
                        </div>
                    </div>
                    <div class="custom-column">
                            <label class="custom-radio">
                            <input type="radio" id="sentenceFormat" name="caseOption" value="sentenceFormat">
                            Sentence Format <br>(Each sentence starts with a capital letter)
                                    </label>
                                    <label class="custom-radio">
                                    <input type="radio" id="camelCase" name="caseOption" value="camelCase">
                        Camel Case <br>(Each word capitalized, no spaces)
                                    </label>
                                    <label class="custom-radio">
                                    <input type="radio" id="reverseRegister1" name="caseOption" value="reverseRegister1">
                        REVERSE REGISTER -1 <br>(StArTs WaVy CaPiTaL LeTtErS)
                                    </label>
                                    <label class="custom-radio">
                                    <input type="radio" id="reverseRegister2" name="caseOption" value="reverseRegister2">
                                    REVERSE REGISTER -2 <br>(sTaRtS wAvY uPpErCaSe LeTtErS)
                                    </label>
                    </div>
                    <div class="custom-column">
                            <label class="custom-radio">
                            <input type="radio" id="reverseCase" name="caseOption" value="reverseCase">
                            rEVERSE cASE <br>(Swaps lower and upper case)
                                    </label>
                                    <label class="custom-radio">
                                    <input type="radio" id="titleCase" name="caseOption" value="titleCase">
                                    Title Case <br>(First letter of each word capitalized, rest lowercase) 
                                    </label>
                                    <label class="custom-radio">
                                    <input type="radio" id="reverseRegisterR" name="caseOption" value="reverseRegisterR">
                        Reverse RegisterR <br>(Last letter of each word capitalized) 
                                    </label>
                    </div>
                </div>
            </div>
         
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}



/********************************************************************************************/ 
//C18 Replace Tabs with Spaces
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_replace_tabs() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                    <label class="textLableBold">Number of Spaces
                    </label>
                    <input type="number" id="spacesPerTab" name="spacesPerTab" value="4" min="1" class="custom-input">
                    </div>
                    <div class="custom-column">
                       
                          </div>
                    <div class="custom-column">
                        <!-- Column 3 content -->
                    </div>
                </div>
            </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}



/********************************************************************************************/ 
//C14 List Numbering Online
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_add_line_numbers() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                        <label class="textLableBold">Row Mode</label>
                        
                            <label  ><input type="radio" id="allLines" name="rowMode" value="all" checked > All Lines</label>
                            <label  ><input type="radio" id="notEmptyLines" name="rowMode" value="notEmpty" > Not Empty Lines</label>
                        
                    </div>
                    <div class="custom-column">
                        <label class="textLableBold">Line number format</label>
                        <div >
                            <label ><input type="radio" id="justNumber" name="lineNumberFormat" value="number" checked > Just a number: 1 2 3</label>
                            <label ><input type="radio" id="withBrackets" name="lineNumberFormat" value="brackets" > With brackets: 1) 2) 3)</label>
                            <label ><input type="radio" id="customNumbering" name="lineNumberFormat" value="custom" >  numbering <input type="text" id="customNumberingText" name="customNumberingText" placeholder="Enter custom format" class="custom-input"></label>
                        </div>
                    </div>
                    <div class="custom-column">
                       
                    </div>
            </div>
        </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}

/********************************************************************************************/ 
//C9 add-text-suffix
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_add_suffix() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                        <label class="textLableBold">Suffix</label>
                        
                        <input type="text" id="suffix" name="suffix" placeholder="Enter the suffix" class="custom-input"><br>
              
                        
                    </div>
                    <div class="custom-column">
                        <label class="textLableBold">Apply suffix to</label>
                       
                       
                
                <label><input type="radio" id="suffixWholeText" name="suffixType" value="whole" checked > Whole Text</label>
                
                <label ><input type="radio" id="suffixLineByLine" name="suffixType" value="line" > Line by Line</label>
                
                <label ><input type="radio" id="suffixParagraph" name="suffixType" value="paragraph"> Each Paragraph</label>
            </div>
                   
                    <div class="custom-column">
                       
                    </div>
            </div>
        </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}


/********************************************************************************************/ 
//C8 add-text-prefix
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_add_prefix() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                        <label class="textLableBold">Prefix</label>
                        
                        <input type="text" id="prefix" name="prefix" placeholder="Enter the prefix" class="custom-input">
                
                    </div>
                    <div class="custom-column">
                        <label class="textLableBold">Apply prefix to</label>
                       
                       
                
                <label><input type="radio" id="prefixWholeText" name="prefixType" value="whole" checked > Whole Text</label>
                
                <label ><input type="radio" id="prefixLineByLine" name="prefixType" value="line" > Line by Line</label>
                
                <label ><input type="radio" id="prefixParagraph" name="prefixType" value="paragraph"> Each Paragraph</label>
            </div>
                   
                    <div class="custom-column">
                       
                    </div>
            </div>
        </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}


/********************************************************************************************/ 
//C7 CUT TEXT
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_cut_text() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                        <label class="textLableBold">Cut Length</label>
                        <input type="number" id="cutLength" name="cutLength" placeholder="Enter the cut length" class="custom-input">
  
                 
                
                    </div>
                    <div class="custom-column">
                        <label class="textLableBold">Cut type</label>
                       
                       
                
                <label><input type="radio" id="cutTypeWord" name="cutType" value="word" checked style="margin-right: 10px;"> Words</label>
                
                <label ><input type="radio" id="cutTypeCharacter" name="cutType" value="character" > Character</label>
                
                <label ><input type="radio" id="cutTypeSentence" name="cutType" value="sentence"> Sentences</label>
            </div>
                   
                    <div class="custom-column">
                       
                    </div>
            </div>
        </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}

/********************************************************************************************/ 
//C5 Repeatition Text
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_repeat_text() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                        <label class="textLableBold">Symbol between repetitions</label>
                        <label><input type="radio" id="space" name="symbolType" value="space" checked > Space</label>
                
                        <label > <input type="radio" id="comma" name="symbolType" value="comma" > Comma</label>
                        
                        <label ><input type="radio" id="newline" name="symbolType" value="newline" > New Line</label>

                        <label ><input type="radio" id="custom" name="symbolType" value="custom" > Custom <input type="text" id="customSymbol" name="customSymbol" placeholder="Enter custom symbol"  class="custom-input"></label>
                
                    </div>
                    <div class="custom-column">
                        <label class="textLableBold">Number of repetititons</label>
                       
                       
                
                        <input type="number" id="numRepetitions" name="numRepetitions" value="100" class="custom-input">
    
            </div>
                   
                    <div class="custom-column">
                       
                    </div>
            </div>
        </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}

/********************************************************************************************/ 
//C3 JOIN TEXT
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_join_text_into_paragraph() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
                <div class="custom-row">
                    <div class="custom-column">
                        <label class="textLableBold">Joiner symbol</label>
                        <input type="text" id="joiner" name="joiner" placeholder=" " class="custom-input">  
                    </div>
                    <div class="custom-column">
                        
    
            </div>
                   
                    <div class="custom-column">
                       
                    </div>
            </div>
        </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}



/********************************************************************************************/ 
//C2 SPLIT TEXT INTO PARAGRAPH 
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_split_text_into_paragraph() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
        <div class="custom-row">
            <div class="custom-column">
                <label class="textLableBold">Separation Options</label>
                
                <label>
                    <input type="radio" id="numParagraphsRadio" name="symbolType" value="numParagraphs" checked>
                    Number of paragraphs
                </label>
                <input type="number" id="numParagraphs" name="numParagraphs" value="1" placeholder="5" class="custom-input">
                
                <label>
                    <input type="radio" id="numSentencesRadio" name="symbolType" value="numSentences">
                    Number of sentences in a paragraph
                </label>
                <input type="number" id="numSentences" name="numSentences" placeholder="5" class="custom-input">
                
                <label>
                    <input type="radio" id="chunkLengthRadio" name="symbolType" value="chunkLength">
                    Use chunk length
                </label>
                <input type="number" id="chunkLength" name="chunkLength" placeholder="5" class="custom-input">
            </div>
            
            <div class="custom-column">
                <label class="textLableBold">Setting the results</label>
                <label>Spaces between paragraphs</label>
                <input type="text" id="paragraphSpacing" name="paragraphSpacing" value="1" placeholder=" " class="custom-input">
            </div>
            
            <div class="custom-column">
                <label class="textLableBold">Remove punctuation marks</label>
                <label>
                    <input type="checkbox" id="removePunctuation" name="removePunctuation">
                    Remove all punctuation marks
                </label>
                <label>
                    <input type="checkbox" id="removeSpacesLeft" name="removeSpacesLeft">
                    Remove space left
                </label>
                <label>
                    <input type="checkbox" id="removeSpacesRight" name="removeSpacesRight">
                    Remove space right
                </label>
            </div>
       


            </div>
        </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}


/********************************************************************************************/ 
// C1 SPLIT TEXT
/********************************************************************************************/  
// Function to render custom round box (may vary with different shortcodes)
function render_custom_round_box_text_splitter() {
    ob_start(); // Start output buffering to capture HTML
    ?> 
    <div class="custom-round-box">
    <div class="custom-row">
    <div class="custom-column">
        <label class="textLableBold">Split Settings Options</label>

        <label>
            <input type="radio" id="splitSymbolRadio" name="symbolType" value="splitSymbol" checked>
            Split Symbol
        </label>
        <input type="text" id="splitSymbol" name="splitSymbol" placeholder="Enter symbol" value="@" class="custom-input">

        <label>
            <input type="radio" id="useRegexRadio" name="symbolType" value="useRegex">
            Use Regex
        </label>
        <input type="text" id="useRegex" name="useRegex" placeholder="Enter regex" class="custom-input">

        <label>
            <input type="radio" id="chunkLengthRadio" name="symbolType" value="chunkLength">
            Use Chunk Length
        </label>
        <input type="number" id="chunkLength" name="chunkLength" placeholder="Enter chunk length" class="custom-input">
    </div>

    <div class="custom-column">
        <label class="textLableBold">Spaces Between the Result Settings</label>

        <label>
            <input type="radio" id="newLineRadio" name="spaceType" value="newLine">
            New Line
        </label>

        <label>
            <input type="radio" id="characterRadio" name="spaceType" value="character">
            Character
        </label>
        <input type="text" id="charBetween" name="charBetween" placeholder="Enter character" class="custom-input">
    </div>
    </div>
    </div>
    <?php
    return ob_get_clean(); // Return the buffered HTML content
}
